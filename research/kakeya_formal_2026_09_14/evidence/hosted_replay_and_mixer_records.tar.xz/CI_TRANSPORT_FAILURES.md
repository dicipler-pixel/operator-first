# CI artifact transport failures

The first hosted proof gate passed at run34833739371, proof head4ae3fb92ac048f635243032813ed1ef3256b3526, tested merge d2a40eecdbf3ae4d3f69808943001bdcd2575ad2. The full decoded job log was recovered. Raw artifact transfer to this workspace failed: direct returned URL HTTP403; two authenticated materialization-helper attempts HTTP502. No downloaded artifact hash comparison was claimed. The artifact metadata reports37064bytes, sha256e8f53d41cc9400a39a3c5b7fda8b9705f978933d9e25ac5345631f0d0af68fe3.

A follow-up recording step now emits the verifier output as a checksummed TAR/XZ receipt in numbered base64 log chunks. This preserves complete evidence through the working decoded-job-log path and catches truncation. Proof sources and theorem statements are unchanged.
