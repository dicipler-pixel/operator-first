from pathlib import Path
import hashlib,json,sys
source=Path(__file__).resolve().parent
instrument=Path(sys.argv[1]).resolve()
for item in json.loads((source/'ledger_replay_manifest.json').read_text()).values():
 target=instrument/item['destination'];current=target.read_bytes();digest=hashlib.sha256(current).hexdigest()
 if digest==item['final_sha256']:
  print('Already replayed:',item['destination']);continue
 if digest!=item['base_sha256']:raise SystemExit('Unrecognized ledger base: '+str(target))
 delta=(source/item['delta']).read_bytes()
 assert hashlib.sha256(delta).hexdigest()==item['delta_sha256']
 assert hashlib.sha256(current+delta).hexdigest()==item['final_sha256']
 with target.open('ab') as f:f.write(delta)
 print('Replayed:',item['destination'])
