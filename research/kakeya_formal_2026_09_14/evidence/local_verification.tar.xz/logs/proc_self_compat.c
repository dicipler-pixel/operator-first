/* PID-namespace compatibility only. Lean's runtime asks for its own executable
 * via /proc/<getpid()>/exe. With host procfs and a nested PID namespace that
 * names another process. Resolve precisely that self request through procfs's
 * canonical /proc/self/exe. All other readlink calls remain unchanged. */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
ssize_t readlink(const char *path, char *buf, size_t size) {
  static ssize_t (*original)(const char *, char *, size_t);
  if (!original) original = dlsym(RTLD_NEXT, "readlink");
  char own_path[64];
  snprintf(own_path, sizeof own_path, "/proc/%ld/exe", (long)getpid());
  return original(strcmp(path, own_path) == 0 ? "/proc/self/exe" : path, buf, size);
}
