# Lean checker scope

Reviewed the exact official Lean 4.33.0 source `src/lean/LeanChecker.lean`, shipped in the authenticated release archive. Canonical source: https://github.com/leanprover/lean4/blob/v4.33.0/src/LeanChecker.lean .

`lake env leanchecker OperatorFirst.KakeyaDenominators` (and analogously each module) finds compiled `.olean` modules having that prefix and replays their declarations into the original imported environment through Lean's kernel. It reads exported/server/private module parts and takes declarations from the most-private available part. Exit zero confirms successful replay.

This is a Lean-kernel recheck designed to detect environment hacking, **not an independent external proof checker**. Standard mode assumes imported declarations. `--fresh` can replay the full imported closure into a fresh environment, only for one exact module at a time. The current finite-bridge verification gate intentionally uses standard per-module replay, with a separate transitive axiom inventory and definition audit.

Use `-v` to retain the explicit `replaying <module>` line. The CLI does not implement `--help`; that flag is ignored and the no-target default guesses a capitalized package name, which is inappropriate for a hyphenated project package. The investigative failed help invocation was retained in `leanchecker_help.log`; it does not indicate a failure of an explicitly named theorem module.
