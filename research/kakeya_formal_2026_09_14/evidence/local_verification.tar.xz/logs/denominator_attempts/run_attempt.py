#!/usr/bin/env python3
"""Record each local Lean attempt without overwriting earlier evidence."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

base = pathlib.Path(__file__).resolve().parents[2]
source = base / "OperatorFirst" / sys.argv[1]
attempts = pathlib.Path(__file__).resolve().parent
serial = 1 + max([0] + [int(p.name.split("_")[0]) for p in attempts.iterdir()
                        if p.is_dir() and p.name.split("_")[0].isdigit()])
folder = attempts / f"{serial:03d}_{source.stem}"
folder.mkdir()
payload = source.read_bytes()
(folder / source.name).write_bytes(payload)
command = [str(base / "run_lean.sh"), "-o", str(source.with_suffix(".olean")), str(source)]
metadata = {"source_sha256": hashlib.sha256(payload).hexdigest(), "command": command,
            "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (folder / "stdout.log").open("wb") as out, (folder / "stderr.log").open("wb") as err:
    process = subprocess.run(command, stdout=out, stderr=err)
metadata.update(exit_code=process.returncode,
                finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(folder / "attempt.json").write_text(json.dumps(metadata, indent=2) + "\n")
print(f"Attempt {serial:03d}: {source.name}, exit {process.returncode}")
print((folder / "stdout.log").read_text())
print((folder / "stderr.log").read_text())
sys.exit(process.returncode)
