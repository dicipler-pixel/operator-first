"""Record the exact source and full compiler event for each cut-module attempt."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

project = Path(__file__).resolve().parents[1]
name = sys.argv[1] if len(sys.argv) > 1 else "KakeyaCutCompletion"
source = project / "OperatorFirst" / f"{name}.lean"
root = project / "logs" / "cut_attempts"
root.mkdir(exist_ok=True)
indices = [int(p.name) for p in root.iterdir() if p.is_dir() and p.name.isdigit()]
event = root / f"{max(indices, default=-1) + 1:02d}"
event.mkdir()
shutil.copyfile(source, event / source.name)
command = [str(project / "run_lean.sh"), "-o", str(source.with_suffix(".olean")), str(source)]
metadata = {
    "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "command": command,
}
with (event / "compiler.log").open("w") as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
metadata["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
metadata["exit_code"] = result.returncode
metadata["compiler_log_sha256"] = hashlib.sha256((event / "compiler.log").read_bytes()).hexdigest()
(event / "manifest.json").write_text(json.dumps(metadata, indent=2) + "\n")
print(event)
print((event / "compiler.log").read_text())
sys.exit(result.returncode)
