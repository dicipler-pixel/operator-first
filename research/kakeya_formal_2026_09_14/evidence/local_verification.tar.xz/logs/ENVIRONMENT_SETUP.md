# Isolated Lean/mathlib environment — 2026-09-14

Project: `/workspace/scratch/38d2657f642a/kakeya_lean`.

## Pins and acquisition

- Official Lean 4.33.0 Linux release: `https://github.com/leanprover/lean4/releases/download/v4.33.0/lean-4.33.0-linux.tar.zst`.
- Exact archive byte count: 574882764. SHA-256 is in `toolchain_sha256.txt`.
- Lean binary reports release commit `d8b18978322de05a8f3dba51ef03cf5461676c17`.
- Mathlib source revision: `db584cd6d46c92f209a44c0f1c829460d327499d`.
- Dependency revisions: portable project `lake-manifest.json` and upstream mathlib manifest.
- Downloads used ordinary configured HTTPS proxy access. No approval escalation, firewall change, network bypass, or global toolchain default change was performed.

## Initial extraction correction

The first `tar --zstd -xf` attempted to restore archive owner uid/gid 1001, which the managed container cannot assign, producing ownership errors. Extraction was repeated with `--no-same-owner`; this does not modify file contents. Logs: `lean_extract.log`.

## Managed runtime compatibility

Official Lean 4.33.0 and the preexisting 4.34.0-rc2 both initially returned `error: failed to locate application` before compiling any input. Official `src/runtime/io.cpp`, function `lean_io_app_path`, reads `/proc/<getpid()>/exe`. This container runs a nested PID namespace with host procfs: a process reporting PID 5 has access to its own `/proc/self/exe`, but `/proc/5/exe` identifies another process and cannot be read.

A scoped dynamic-library compatibility adapter resolves **only the current process's own** `/proc/<getpid()>/exe` request through canonical `/proc/self/exe`. Every other `readlink` request is passed unchanged to libc. Source: `environment/proc_self_compat.c` (audit copy `logs/proc_self_compat.c`); SHA-256 of source and binary: `compatibility_sha256.txt`. It does not modify Lean binaries, theorem/kernel code, proofs, or access permissions. It is supplied only to local wrappers via `LD_PRELOAD` and is not needed in ordinary GitHub Actions environments.

A syscall-tracing attempt was refused by managed process permissions; it was not retried with escalation. Diagnosis instead used exact official runtime source and a read-only Python self-path check.

**Local results must disclose this adapter. Clean GitHub Actions execution without it is required as corroborating release evidence.**

## Commands

- `./run_lake.sh env lean --version`: official version output stored in `project_lean_version.txt`.
- `./run_lake.sh build`: normal Lake project build under the local adapter.
- `./run_lean.sh /absolute/path/to/source.lean`: isolated compilation command while authoring.
- Portable clean environment: ordinary `lake exe cache get` followed by `lake build`, using the pinned toolchain and dependencies, without local wrappers.

## Cache

The official mathlib cache executable was built from the exact source pin. It successfully contacts `https://lakecache.blob.core.windows.net/mathlib4-master`. Initial import union requested Tactic, Finset.Card, Dimension.Finite, and Determinant.Basic (2990 dependencies). Full progress and final status are recorded in `mathlib_cache.log`; do not infer cache completion merely from this note.

## Smoke result

A fresh core theorem `environment_smoke (n : Nat) : n + 0 = n` was checked from `Nat.add_zero`; Lean printed that it does not depend on any axioms. Evidence: `environment_smoke.log`. This establishes functioning elaboration, rather than relying on version output alone.

## Final acquisition status

Official cache command exited 0: 2990/2990 files downloaded and decompressed. The downloaded Lean archive matches the official GitHub release digest exactly: `4b3fb03c29a1e0a253fb1d11f9bae3725f19a0dc6fc09b3ea16d2c9df3349e2c`. Evidence: `toolchain_digest_comparison.json`, `mathlib_cache.log`.
