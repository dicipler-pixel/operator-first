# SCRIPT: COLOR-LEDGER-01  (diminishing returns of the log-det ledger metric vs the Riemannian transport metric on SPD rigidity operators)
import numpy as np
from scipy.linalg import fractional_matrix_power as fmp, sqrtm
rng = np.random.default_rng(2)
d = 5

def delta_R(A,B):     # affine-invariant Riemannian distance (length metric -- the control)
    Ai = fmp(A,-0.5)
    ev = np.linalg.eigvalsh(Ai@B@Ai)
    return np.sqrt(np.sum(np.log(ev)**2))
def dS(A,B):          # ledger metric: sqrt of Jensen-Bregman log-det divergence
    s = np.linalg.slogdet((A+B)/2)[1] - 0.5*np.linalg.slogdet(A)[1] - 0.5*np.linalg.slogdet(B)[1]
    return np.sqrt(max(s,0.0))

# relaxed side of the wall: near-identity SPD
Q = rng.standard_normal((d,d)); A0 = np.eye(d) + 0.05*(Q+Q.T) @ (Q+Q.T).T/ d
# loaded side: rigidity contrast kappa along a random anisotropy frame
U,_ = np.linalg.qr(rng.standard_normal((d,d)))

print(f"{'log kappa':>9} {'direct dR':>10} {'accum dR':>10} {'ratio dR':>9} | {'direct dS':>10} {'accum dS':>10} {'ratio dS':>9}")
for lk in [1,2,4,6,8]:
    spread = np.linspace(-lk/2, lk/2, d)
    A1 = U @ np.diag(np.exp(spread)) @ U.T          # SPD, condition number e^lk
    # geodesic path A(t) = A0^1/2 (A0^-1/2 A1 A0^-1/2)^t A0^1/2, fine discretization
    A0h = sqrtm(A0).real; A0hi = np.linalg.inv(A0h)
    Mid = A0hi @ A1 @ A0hi
    n = 400
    path = [A0h @ fmp(Mid, t).real @ A0h for t in np.linspace(0,1,n+1)]
    accR = sum(delta_R(path[k], path[k+1]) for k in range(n))
    accS = sum(dS(path[k], path[k+1]) for k in range(n))
    dirR = delta_R(A0, A1); dirS = dS(A0, A1)
    print(f"{lk:9d} {dirR:10.4f} {accR:10.4f} {accR/dirR:9.4f} | {dirS:10.4f} {accS:10.4f} {accS/dirS:9.4f}")

print()
print("local calibration (step size -> 0): dS/dR on one small step at three points along the path:")
for t in [0.1, 0.5, 0.9]:
    Aa = path[int(t*n)]; Ab = path[int(t*n)+1]
    print(f"  t={t}: dS/dR = {dS(Aa,Ab)/delta_R(Aa,Ab):.6f}   (1/(2*sqrt2) = {1/(2*np.sqrt(2)):.6f})")
