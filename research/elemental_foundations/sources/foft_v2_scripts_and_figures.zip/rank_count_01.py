# SCRIPT: RANK-COUNT-01  (boundary-trackable projector census: area law from the gap/trackability hypothesis)
import numpy as np

def band_projector(H, tol=0.0):
    ev, V = np.linalg.eigh(H)
    occ = ev < tol
    return V[:, occ] @ V[:, occ].conj().T, ev

def census(P, idx, eps=1e-3):
    C = P[np.ix_(idx, idx)]
    nu = np.linalg.eigvalsh(C)
    return int(np.sum((nu > eps) & (nu < 1-eps)))

print("=== 1D chain, N_track(eps=1e-3) vs region length L ===")
Ntot = 1200; th = 0.4
def H1d(m):
    H = np.zeros((Ntot, Ntot), complex)
    ph = np.exp(1j*th/Ntot)
    for j in range(Ntot):
        H[j,(j+1)%Ntot] = -ph; H[(j+1)%Ntot,j] = -np.conj(ph)
        H[j,j] = m*(-1)**j
    return H
for m, tag in [(0.5,"GAPPED m=0.5 (P1: expect flat)"), (0.0,"GAPLESS m=0 (P2: expect ~log L growth)")]:
    P,_ = band_projector(H1d(m))
    counts = [(L, census(P, np.arange(L))) for L in [50,100,200,400]]
    print(f"  {tag}: " + "  ".join(f"L={L}: N={N}" for L,N in counts))

print()
print("=== 1D gap dial at fixed L=200 (P5: N grows as gap shrinks) ===")
for m in [1.0, 0.5, 0.2, 0.1, 0.05]:
    P,_ = band_projector(H1d(m))
    print(f"  m={m:5.2f}  N={census(P, np.arange(200))}")

print()
print("=== 2D square lattice 44x44, region LxL (P3/P4) ===")
Lx = Ly = 44; Nsites = Lx*Ly
def idx2(x,y): return (x%Lx)*Ly + (y%Ly)
def H2d(m):
    H = np.zeros((Nsites, Nsites), complex)
    phx, phy = np.exp(1j*0.37/Lx), np.exp(1j*0.83/Ly)
    for x in range(Lx):
        for y in range(Ly):
            i = idx2(x,y)
            H[i, idx2(x+1,y)] += -phx; H[idx2(x+1,y), i] += -np.conj(phx)
            H[i, idx2(x,y+1)] += -phy; H[idx2(x,y+1), i] += -np.conj(phy)
            H[i,i] = m*(-1)**(x+y)
    return H
for m, tag in [(1.0,"GAPPED m=1.0"), (0.0,"GAPLESS m=0")]:
    P,_ = band_projector(H2d(m))
    Ls = [6,10,14,18,22]; Ns = []
    for L in Ls:
        region = [idx2(x,y) for x in range(L) for y in range(L)]
        Ns.append(census(P, np.array(region)))
    slope = np.polyfit(np.log(Ls), np.log(Ns), 1)[0]
    perim = ", ".join(f"L={L}: N={N} (N/4L={N/(4*L):.3f})" for L,N in zip(Ls,Ns))
    print(f"  {tag}:  {perim}")
    print(f"    log-log slope N vs L = {slope:.3f}   ({'area-law' if slope < 1.15 else 'violation'} territory)")
