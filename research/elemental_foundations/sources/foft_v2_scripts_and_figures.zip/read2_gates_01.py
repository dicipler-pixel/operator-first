# SCRIPT: READ2-GATES-01  (remaining read-#2 verification gates for the cosmology paper)
import numpy as np
rng = np.random.default_rng(9)
def comm(A,B): return A@B - B@A

print("G1: Theorem 6.1 zeta-ledger series (traceless dK, eta-Lam=2)")
M = 10
dK = rng.standard_normal((M,M)) + 1j*rng.standard_normal((M,M))
dK -= np.trace(dK)/M*np.eye(M)                       # traceless
dK *= 0.8/np.linalg.norm(dK,2)                       # ||X|| < 1
g = 2.0; X = dK/g
Z_true = np.linalg.slogdet(g*np.eye(M) + dK)[1]
Z_series = M*np.log(g) + sum(((-1)**(k-1)/k)*np.trace(np.linalg.matrix_power(X,k)).real for k in range(2,60))
print(f"   direct log|det| = {Z_true:.12f}   formula (6.3) = {Z_series:.12f}   diff = {abs(Z_true-Z_series):.1e}")

print("G2: chiral ledger repair -- anti-Hermitian X gives Z = (1/2)Tr ln(I+Y^2)")
m2 = 5
B = 0.3*(rng.standard_normal((m2,m2)) + 1j*rng.standard_normal((m2,m2)))
Y = np.block([[np.zeros((m2,m2)), B],[B.conj().T, np.zeros((m2,m2))]])   # Hermitian, chiral
X = 1j*Y                                                                  # anti-Hermitian, chiral
Z_true = np.linalg.slogdet(np.eye(2*m2) + X)[1]
lam = np.linalg.eigvalsh(Y)
Z_half = 0.5*np.sum(np.log(1+lam**2))
print(f"   log|det(I+X)| = {Z_true:.12f}   (1/2)Tr ln(I+Y^2) = {Z_half:.12f}   diff = {abs(Z_true-Z_half):.1e}")
print("   -> continuum value under the paper's own density: (1/2)*(pi^2/6) = pi^2/12; Catalan stays with the holonomy integral only")

print("G3: Theorem 7.1 Lipschitz bound, numeric (Riesz projectors by contour quadrature)")
n = 6
A = np.diag([1.0,1.2,2.6,3.1,3.7,4.3]) + 0.1*rng.standard_normal((n,n))
c0, r = 1.1+0j, 0.7
ths = np.linspace(0, 2*np.pi, 800, endpoint=False)
zs = c0 + r*np.exp(1j*ths)
sup_res = max(np.linalg.norm(np.linalg.inv(z*np.eye(n)-A), 2) for z in zs)
evs = np.linalg.eigvals(A)
outside = evs[np.abs(evs-c0) > r]
dgap = min(abs(ev-c0) for ev in outside) - r
C_G = sup_res*dgap
eps = 0.3*dgap/C_G
E = rng.standard_normal((n,n)); E *= eps/np.linalg.norm(E,2)
def riesz(Mt):
    S = np.zeros((n,n), complex)
    for z in zs: S += np.linalg.inv(z*np.eye(n)-Mt)*(1j*r*np.exp(1j*np.angle(z-c0)))
    return S*(2*np.pi/len(zs))/(2j*np.pi)
Pi, Pip = riesz(A), riesz(A+E)
lhs = np.linalg.norm(Pip-Pi, 2)
ell = 2*np.pi*r
K_G = ell*C_G**2/(2*np.pi*dgap*(dgap-eps*C_G))
print(f"   ||Pi'-Pi|| = {lhs:.4f}  <=  K_Gamma*eps = {K_G*eps:.4f}  -> {'BOUND HOLDS' if lhs <= K_G*eps else 'VIOLATED'}   (Tr Pi = {np.trace(Pi).real:.6f})")

print("G4: Appendix A conventions -- Q = g + (i/2)Omega with g=(1/2)Tr(VW), Omega=-i Tr(Pi[V,W]); and the metric-curvature inequality")
k, nn = 2, 6
Q0,_ = np.linalg.qr(rng.standard_normal((nn,nn)) + 1j*rng.standard_normal((nn,nn)))
Pi = Q0[:,:k] @ Q0[:,:k].conj().T
def tangent():
    Vr = rng.standard_normal((nn,nn)) + 1j*rng.standard_normal((nn,nn)); Vr = (Vr+Vr.conj().T)/2
    Qp = np.eye(nn)-Pi
    return Pi@Vr@Qp + Qp@Vr@Pi
V, W = tangent(), tangent()
Q_VW = np.trace(Pi@V@W)
gVW  = 0.5*np.trace(V@W).real
Om   = (-1j*np.trace(Pi@comm(V,W))).real
print(f"   Tr(PiVW) = {Q_VW:.6f}   g + (i/2)Om = {gVW + 0.5j*Om:.6f}   diff = {abs(Q_VW-(gVW+0.5j*Om)):.1e}")
gVV, gWW = 0.5*np.trace(V@V).real, 0.5*np.trace(W@W).real
rhs = 2*np.sqrt(max(gVV*gWW - gVW**2, 0))
print(f"   |Omega| = {abs(Om):.6f}  <=  2*sqrt(gg-g^2) = {rhs:.6f}  -> {'HOLDS' if abs(Om)<=rhs+1e-12 else 'VIOLATED'}")

print("G5: corrected back-reaction linearization (Sec 3 repair): dF[V] = -2([[V,K+]+[K,V+],K] + [[K,K+],V])")
K = rng.standard_normal((5,5)) + 1j*rng.standard_normal((5,5))
V = rng.standard_normal((5,5)) + 1j*rng.standard_normal((5,5))
def F(Kk): return -2*comm(comm(Kk,Kk.conj().T), Kk)
h = 1e-6
fd = (F(K+h*V) - F(K-h*V))/(2*h)
dC = comm(V,K.conj().T) + comm(K,V.conj().T)
formula = -2*(comm(dC,K) + comm(comm(K,K.conj().T), V))
print(f"   ||FD - formula|| / ||FD|| = {np.linalg.norm(fd-formula)/np.linalg.norm(fd):.1e}")

print("G6: Eq (4.9) SU(3) commutator, numeric")
# Gell-Mann matrices
l = np.zeros((8,3,3), complex)
l[0][0,1]=l[0][1,0]=1; l[1][0,1]=-1j; l[1][1,0]=1j; l[2][0,0]=1; l[2][1,1]=-1
l[3][0,2]=l[3][2,0]=1; l[4][0,2]=-1j; l[4][2,0]=1j; l[5][1,2]=l[5][2,1]=1
l[6][1,2]=-1j; l[6][2,1]=1j; l[7]=np.diag([1,1,-2])/np.sqrt(3)
f = np.zeros((8,8,8))
for a in range(8):
    for b in range(8):
        cab = comm(l[a],l[b])
        for c in range(8): f[a,b,c] = (np.trace(cab@l[c])/(4j)).real
psi = rng.standard_normal(8) + 1j*rng.standard_normal(8)
A49 = sum(psi[a]*l[a] for a in range(8))
lhs = comm(A49, A49.conj().T)
rhs = -2*sum(f[a,b,c]*np.imag(psi[a]*np.conj(psi[b]))*l[c] for a in range(8) for b in range(8) for c in range(8))
print(f"   ||[A,A+] - RHS(4.9)|| = {np.linalg.norm(lhs-rhs):.1e}   (traceless: {abs(np.trace(lhs)):.1e})")
