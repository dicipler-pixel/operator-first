# SCRIPT: COSMO-BIORTHO-02  (co-vector/vector alignment along the corrected flow; Henrici dissipation identity; paper-flow contrast)
import numpy as np
from scipy.linalg import eig
np.set_printoptions(precision=4, suppress=False)

def comm(A,B): return A@B - B@A
def C_of(K): return comm(K, K.conj().T)
def Phi(K):
    C = C_of(K); return 0.5*np.real(np.trace(C @ C.conj().T))
def kappas(K):
    w, vl, vr = eig(K, left=True, right=True)   # columns unit-norm
    idx = np.lexsort((w.imag, w.real))
    w, vl, vr = w[idx], vl[:,idx], vr[:,idx]
    kap = np.array([1.0/abs(vl[:,i].conj() @ vr[:,i]) for i in range(len(w))])
    return w, kap, vr

print("=== TEST 1: exact identity d/dt ||K||_F^2 = -8*Phi(K) along corrected flow (finite difference) ===")
for seed in range(5):
    r = np.random.default_rng(seed); n=6
    K = r.standard_normal((n,n)) + 1j*r.standard_normal((n,n))
    F = -2*comm(C_of(K), K)
    eps = 1e-7
    fd = (np.linalg.norm(K+eps*F)**2 - np.linalg.norm(K-eps*F)**2)/(2*eps)
    print(f"seed {seed}:  FD d||K||^2/dt = {fd:+.6f}    -8*Phi = {-8*Phi(K):+.6f}   ratio = {fd/(-8*Phi(K)):.9f}")

print()
print("=== TEST 2: trajectory -- eigenvalues frozen, kappas -> 1, Henrici budget closes ===")
r = np.random.default_rng(11); n=6
K0 = r.standard_normal((n,n)) + 1j*r.standard_normal((n,n))
w0, kap0, vr0 = kappas(K0)
S2 = np.sum(np.abs(w0)**2)                      # conserved spectral energy
henrici0 = np.linalg.norm(K0)**2 - S2
print(f"t=0: Henrici^2 = {henrici0:.6f}   Phi = {Phi(K0):.4f}")
print("t=0 kappas:", np.round(kap0,4))
lead0 = np.argmax(np.abs(w0))                   # leading = largest |lambda|
Kt = K0.copy(); h = 5e-5; t = 0.0
checkpoints = [0.001,0.005,0.02,0.1,0.5,2.0]
ci = 0; log = []
def f(M): return -2*comm(C_of(M), M)
while ci < len(checkpoints):
    k1=f(Kt); k2=f(Kt+0.5*h*k1); k3=f(Kt+0.5*h*k2); k4=f(Kt+h*k3)
    Kt = Kt + (h/6)*(k1+2*k2+2*k3+k4); t += h
    if t >= checkpoints[ci]:
        w, kap, vr = kappas(Kt)
        hen = np.linalg.norm(Kt)**2 - S2
        lead = np.argmax(np.abs(w))
        ang = np.degrees(np.arccos(min(1.0, abs(vr0[:,lead0].conj() @ vr[:,lead]))))
        log.append((t, np.max(np.abs(np.sort_complex(w)-np.sort_complex(w0))), hen, Phi(Kt), np.max(kap), kap[lead], ang))
        ci += 1
print(f"{'t':>7} {'eig drift':>10} {'Henrici^2':>10} {'Phi':>10} {'max kappa':>10} {'kappa_lead':>10} {'R1 rotation(deg)':>16}")
for row in log:
    print(f"{row[0]:7.3f} {row[1]:10.2e} {row[2]:10.4f} {row[3]:10.4f} {row[4]:10.5f} {row[5]:10.5f} {row[6]:16.2f}")
print("limit spectrum (should equal initial):", np.round(np.sort_complex(np.linalg.eigvals(Kt)),3))
print("initial spectrum                     :", np.round(np.sort_complex(w0),3))

print()
print("=== TEST 3: budget check -- integral of 8*Phi dt vs Henrici^2 dissipated ===")
Kt = K0.copy(); h=5e-5; acc=0.0
for step in range(int(2.0/h)):
    acc += 8*Phi(Kt)*h
    k1=f(Kt); k2=f(Kt+0.5*h*k1); k3=f(Kt+0.5*h*k2); k4=f(Kt+h*k3)
    Kt = Kt + (h/6)*(k1+2*k2+2*k3+k4)
print(f"integral 8*Phi dt over [0,2] = {acc:.6f}")
print(f"Henrici^2 drop ||K0||^2-||K(2)||^2 = {np.linalg.norm(K0)**2 - np.linalg.norm(Kt)**2:.6f}")

print()
print("=== TEST 4: the paper's flow dK/dt=-2[[C],K+] -- spectrum NOT preserved; where does it go? ===")
def fp(M): return -2*comm(C_of(M), M.conj().T)
Kt = K0.copy(); h=2e-5; t=0
for tstop in [0.01, 0.05, 0.2, 1.0]:
    while t < tstop:
        k1=fp(Kt); k2=fp(Kt+0.5*h*k1); k3=fp(Kt+0.5*h*k2); k4=fp(Kt+h*k3)
        Kt = Kt + (h/6)*(k1+2*k2+2*k3+k4); t += h
        if not np.isfinite(np.linalg.norm(Kt)) or np.linalg.norm(Kt) > 1e8:
            print(f"t={t:.4f}: BLOW-UP, ||K|| = {np.linalg.norm(Kt):.2e}"); break
    else:
        w = np.sort_complex(np.linalg.eigvals(Kt))
        print(f"t={t:.3f}: ||K||={np.linalg.norm(Kt):9.3f}  Phi={Phi(Kt):10.3f}  eig drift={np.max(np.abs(w-np.sort_complex(w0))):.3e}")
        continue
    break
