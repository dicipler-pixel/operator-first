# SCRIPT: COSMO-CATALAN-01  (chiral ledger identity 6.12 + Catalan integral 13.13 + density normalization)
import numpy as np
from mpmath import mp, quad, log, atan, pi, catalan, inf, mpf
mp.dps = 30

print("=== TEST A: algebraic identity (6.12) on an explicitly chiral matrix ===")
r = np.random.default_rng(3)
m = 5
B = 0.15*(r.standard_normal((m,m)) + 1j*r.standard_normal((m,m)))
X = np.block([[np.zeros((m,m)), B],[B.conj().T, np.zeros((m,m))]])   # anticommutes with diag(I,-I)
ev = np.linalg.eigvalsh(X)
print("spectrum symmetric? max|ev + reversed(ev)| =", np.max(np.abs(ev + ev[::-1])))
Z_true  = np.sum(np.log(1+ev))          # Tr ln(I+X) = the actual ledger from Thm 6.1's series
Z_paper = np.sum(np.log(1+ev**2))       # paper's (6.12): Tr ln(I+X^2)
Z_half  = 0.5*np.sum(np.log(1-ev**2))   # candidate correction: (1/2) Tr ln(I-X^2)
print(f"Tr ln(I+X)        = {Z_true:+.12f}   (ground truth)")
print(f"paper Tr ln(I+X^2)= {Z_paper:+.12f}")
print(f"1/2 Tr ln(I-X^2)  = {Z_half:+.12f}")

print()
print("=== TEST B: integral identity (13.13): (2/pi) * int_0^inf ln(1+l^2) arctan(1/l)/l dl  vs  G ===")
I = (2/pi)*quad(lambda l: log(1+l**2)*atan(1/l)/l, [0, 1, inf])
print("integral value =", I)
print("Catalan G      =", +catalan)
print("ratio I/G      =", I/catalan)
print("I/(pi) ? ", I/pi, "   I - pi*ln2 ?", I - pi*log(2))
# sanity: the clean identity the paper DOES have right:
print("int_0^1 arctan(x)/x dx =", quad(lambda x: atan(x)/x, [0,1]), " (should be G)")

print()
print("=== TEST C: is rho(l)=arctan(1/l)/(pi*l) a probability density? ===")
for L in [10, 100, 1000, 10000]:
    tot = (2/pi)*quad(lambda l: atan(1/l)/l, [mpf('1e-8'), 1, L])
    print(f"int_{{-{L}}}^{{{L}}} rho = {float(tot):.4f}")
