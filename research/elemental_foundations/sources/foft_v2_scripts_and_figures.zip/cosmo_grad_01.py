# SCRIPT: COSMO-GRAD-01  (gradient of Phi(K)=0.5*||[K,K+]||_F^2 : paper's [[C],K+] vs [[C],K])
import numpy as np
rng = np.random.default_rng(7)
def comm(A,B): return A@B - B@A
def C_of(K): return comm(K, K.conj().T)
def Phi(K):
    C = C_of(K); return 0.5*np.real(np.trace(C @ C.conj().T))

print("=== TEST A: which candidate matches the finite-difference directional derivative ===")
for seed in range(4):
    r = np.random.default_rng(seed)
    n = 6
    K = r.standard_normal((n,n)) + 1j*r.standard_normal((n,n))
    D = r.standard_normal((n,n)) + 1j*r.standard_normal((n,n))
    eps = 1e-6
    fd = (Phi(K+eps*D) - Phi(K-eps*D))/(2*eps)
    C = C_of(K)
    G_paper = comm(C, K.conj().T)   # [[K,K+],K+]
    G_mine  = comm(C, K)            # [[K,K+],K]
    pred_paper = 2*np.real(np.trace(G_paper.conj().T @ D))
    pred_mine  = 2*np.real(np.trace(G_mine.conj().T  @ D))
    print(f"seed {seed}:  FD={fd:+.6f}   pred[[C],K]={pred_mine:+.6f}   pred[[C],K+]={pred_paper:+.6f}")

print()
print("=== TEST B: paper's descent identity dPhi/dt = -4||[[C],K+]||^2 along the paper's own flow ===")
for seed in range(4):
    r = np.random.default_rng(100+seed)
    n = 6
    K = r.standard_normal((n,n)) + 1j*r.standard_normal((n,n))
    C = C_of(K)
    F = -2*comm(C, K.conj().T)                       # paper's flow direction
    G_true = comm(C, K)                              # true gradient (from Test A)
    actual = 2*np.real(np.trace(G_true.conj().T @ F))  # actual dPhi/dt along F
    eps = 1e-6
    fd_actual = (Phi(K+eps*F) - Phi(K-eps*F))/(2*eps) # same thing, pure finite difference
    claimed = -4*np.real(np.trace(comm(C,K.conj().T).conj().T @ comm(C,K.conj().T)))
    print(f"seed {100+seed}:  actual dPhi/dt = {fd_actual:+.4f}   paper's claimed value = {claimed:+.4f}")

print()
print("=== TEST C: 2x2 nilpotent K=[[0,1],[0,0]] -- clean counterexample ===")
K = np.array([[0,1],[0,0]], dtype=complex)
C = C_of(K)
F = -2*comm(C, K.conj().T)
eps=1e-6
fd = (Phi(K+eps*F)-Phi(K-eps*F))/(2*eps)
claimed = -4*np.real(np.trace(comm(C,K.conj().T).conj().T @ comm(C,K.conj().T)))
print(f"K nilpotent: actual dPhi/dt along paper flow = {fd:+.6f};  paper's formula predicts {claimed:+.6f}")

print()
print("=== TEST D: the TRUE gradient flow dK/dt=-2[[C],K] is isospectral (eigenvalues frozen) ===")
r = np.random.default_rng(42); n=5
K = r.standard_normal((n,n)) + 1j*r.standard_normal((n,n))
ev0 = np.sort_complex(np.linalg.eigvals(K))
h = 2e-4
Kt = K.copy()
for step in range(40000):
    # RK4 on dK/dt = -2[C(K),K]
    def f(M): return -2*comm(C_of(M), M)
    k1=f(Kt); k2=f(Kt+0.5*h*k1); k3=f(Kt+0.5*h*k2); k4=f(Kt+h*k3)
    Kt = Kt + (h/6)*(k1+2*k2+2*k3+k4)
ev1 = np.sort_complex(np.linalg.eigvals(Kt))
print("eigenvalue drift after long integration:", np.max(np.abs(ev1-ev0)))
print("residual non-normality ||[K,K+]|| :", np.linalg.norm(C_of(Kt)))
print("initial non-normality              :", np.linalg.norm(C_of(K)))
print("distance of final K from -Lam*I? final eigenvalues:", np.round(ev1,3))
