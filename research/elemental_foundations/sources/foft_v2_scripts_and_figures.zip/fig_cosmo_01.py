# SCRIPT: FIG-COSMO-01  (all v2 figures regenerated from the gated computations; plus V2 gate for corrected Eq (4.10))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.linalg import eig, fractional_matrix_power as fmp, sqrtm
rng = np.random.default_rng(11)
def comm(A,B): return A@B - B@A
def C_of(K): return comm(K, K.conj().T)
def Phi(K):
    C = C_of(K); return 0.5*np.real(np.trace(C @ C.conj().T))

# ---------- FIGURE 1: corrected relaxation flow ----------
n = 6
K0 = rng.standard_normal((n,n)) + 1j*rng.standard_normal((n,n))
w0 = np.sort_complex(np.linalg.eigvals(K0)); S2 = np.sum(np.abs(w0)**2)
def kap(K):
    w, vl, vr = eig(K, left=True, right=True)
    i = np.lexsort((w.imag, w.real))
    return np.array([1.0/abs(vl[:,j].conj()@vr[:,j]) for j in i[np.argsort(i)]]), w
def f(M): return -2*comm(C_of(M), M)
h = 5e-5; Kt = K0.copy(); t = 0.0
ts, phis, hens, drifts, kmax = [], [], [], [], []
next_rec = 0.0
while t < 2.0:
    if t >= next_rec:
        w = np.sort_complex(np.linalg.eigvals(Kt))
        kv,_ = kap(Kt)
        ts.append(t); phis.append(Phi(Kt)); hens.append(np.linalg.norm(Kt)**2 - S2)
        drifts.append(np.max(np.abs(w - w0))); kmax.append(np.max(kv))
        next_rec = max(1e-3, next_rec*1.35) if next_rec > 0 else 1e-3
    k1=f(Kt); k2=f(Kt+0.5*h*k1); k3=f(Kt+0.5*h*k2); k4=f(Kt+h*k3)
    Kt = Kt + (h/6)*(k1+2*k2+2*k3+k4); t += h
fig, ax = plt.subplots(1, 2, figsize=(9, 3.4))
ax[0].semilogy(ts, phis, 'b-', label=r'$\Phi(K)$ (spectral stress)')
ax[0].semilogy(ts, hens, 'r--', label=r'$\Delta_F^2$ (Henrici budget)')
ax[0].semilogy(ts, np.maximum(drifts, 1e-16), 'g:', label='eigenvalue drift')
ax[0].set_xlabel('t'); ax[0].set_title('Isospectral relaxation: stress dies, spectrum frozen')
ax[0].legend(fontsize=8); ax[0].set_ylim(1e-13, 1e3)
ax[1].plot(ts, kmax, 'k-')
ax[1].axhline(1.0, color='gray', lw=0.7)
ax[1].set_xlabel('t'); ax[1].set_ylabel(r'$\max_i \kappa_i$')
ax[1].set_title(r'Co-vector/vector alignment: $\kappa_i \to 1$')
plt.tight_layout(); plt.savefig('fig1_flow.pdf'); plt.close()
print("FIG1 done: final Phi", phis[-1] if phis else None, " final drift", drifts[-1])

# ---------- FIGURE 2: area law census ----------
def band_projector(H):
    ev, V = np.linalg.eigh(H); occ = ev < 0
    return V[:, occ] @ V[:, occ].conj().T
def census(P, idx, eps=1e-3):
    nu = np.linalg.eigvalsh(P[np.ix_(idx, idx)])
    return int(np.sum((nu > eps) & (nu < 1-eps)))
Ntot = 1200; th = 0.4
def H1d(m):
    H = np.zeros((Ntot, Ntot), complex); ph = np.exp(1j*th/Ntot)
    for j in range(Ntot):
        H[j,(j+1)%Ntot] = -ph; H[(j+1)%Ntot,j] = -np.conj(ph); H[j,j] = m*(-1)**j
    return H
Ls1 = [50,100,200,400]
N_gap  = [census(band_projector(H1d(0.5)), np.arange(L)) for L in Ls1]
N_free = [census(band_projector(H1d(0.0)), np.arange(L)) for L in Ls1]
Lx = Ly = 44; Ns = Lx*Ly
def idx2(x,y): return (x%Lx)*Ly + (y%Ly)
def H2d(m):
    H = np.zeros((Ns, Ns), complex); px, py = np.exp(1j*0.37/Lx), np.exp(1j*0.83/Ly)
    for x in range(Lx):
        for y in range(Ly):
            i = idx2(x,y)
            H[i, idx2(x+1,y)] += -px; H[idx2(x+1,y), i] += -np.conj(px)
            H[i, idx2(x,y+1)] += -py; H[idx2(x,y+1), i] += -np.conj(py)
            H[i,i] = m*(-1)**(x+y)
    return H
Ls2 = [6,10,14,18,22]
P2g = band_projector(H2d(1.0)); P2f = band_projector(H2d(0.0))
def reg(L): return np.array([idx2(4+x,4+y) for x in range(L) for y in range(L)])
N2g = [census(P2g, reg(L)) for L in Ls2]
N2f = [census(P2f, reg(L)) for L in Ls2]
fig, ax = plt.subplots(1, 2, figsize=(9, 3.4))
ax[0].plot(Ls1, N_gap, 'bo-', label='gapped m=0.5')
ax[0].plot(Ls1, N_free, 'rs--', label='gapless m=0')
ax[0].set_xlabel('region length L'); ax[0].set_ylabel(r'$N_{\rm track}$')
ax[0].set_title('1D census: area law = constant'); ax[0].legend(fontsize=8); ax[0].set_ylim(0, 14)
ax[1].plot(Ls2, N2g, 'bo-', label='gapped m=1')
ax[1].plot(Ls2, N2f, 'rs--', label='gapless m=0')
ax[1].plot(Ls2, [4*L for L in Ls2], 'k:', label=r'$N=4L$ (unit density)')
ax[1].set_xlabel('region size L'); ax[1].set_title(r'2D census: $N \to$ perimeter')
ax[1].legend(fontsize=8)
plt.tight_layout(); plt.savefig('fig2_arealaw.pdf'); plt.close()
print("FIG2 done:", N_gap, N_free, N2g, N2f)

# ---------- FIGURE 3: refraction dynamics ----------
eps_layer = 0.05
def traj(R1, R2, th1_deg, h=5e-5, tmax=6.0):
    Rf  = lambda w: (R1+R2)/2 + (R2-R1)/2*np.tanh(w/eps_layer)
    dRf = lambda w: (R2-R1)/2/np.cosh(w/eps_layer)**2/eps_layer
    th1 = np.radians(th1_deg)
    s = np.array([-1.0, np.sin(th1), np.cos(th1)]); t = 0.0
    xs, ys = [0.0], [-1.0]
    def g(s):
        w, vp, vq = s; R, dR = Rf(w), dRf(w)
        return np.array([vq, -dR*vq*vp/R, dR*(vp**2-vq**2)/(2*R)])
    x = 0.0
    while t < tmax:
        k1=g(s); k2=g(s+0.5*h*k1); k3=g(s+0.5*h*k2); k4=g(s+h*k3)
        s = s + (h/6)*(k1+2*k2+2*k3+k4); x += s[1]*h; t += h
        if len(xs) < 4000 and int(t/h) % 30 == 0: xs.append(x); ys.append(s[0])
        if s[0] > 1.0 or (s[0] < -1.0 and s[2] < 0): break
    return np.array(xs), np.array(ys)
fig, ax = plt.subplots(figsize=(6.4, 4))
for (R1,R2,th,lab,col) in [(1,4,50,'R 1->4, 50 deg (transmit)','b'),
                            (4,1,20,'R 4->1, 20 deg (transmit)','g'),
                            (4,1,45,'R 4->1, 45 deg (total reflection)','r')]:
    xs, ys = traj(R1,R2,th)
    ax.plot(xs, ys, col, label=lab)
ax.axhspan(-3*eps_layer, 3*eps_layer, color='gray', alpha=0.3)
ax.set_xlabel(r'$w_\parallel$'); ax.set_ylabel(r'$w_\perp$')
ax.set_title(r'EL dynamics through the rigidity layer: $R\sin^2\theta$ conserved to $10^{-13}$')
ax.legend(fontsize=8); plt.tight_layout(); plt.savefig('fig3_refract.pdf'); plt.close()
print("FIG3 done")

# ---------- FIGURE 4: ledger diminishing returns ----------
d = 5
Q = rng.standard_normal((d,d)); A0 = np.eye(d) + 0.05*(Q+Q.T)@(Q+Q.T).T/d
U,_ = np.linalg.qr(rng.standard_normal((d,d)))
def dR_aff(A,B):
    Ai = fmp(A,-0.5); ev = np.linalg.eigvalsh(Ai@B@Ai)
    return np.sqrt(np.sum(np.log(ev)**2))
def dS(A,B):
    s = np.linalg.slogdet((A+B)/2)[1] - 0.5*np.linalg.slogdet(A)[1] - 0.5*np.linalg.slogdet(B)[1]
    return np.sqrt(max(s,0))
lks, ratios = [1,2,4,6,8], []
for lk in lks:
    A1 = U @ np.diag(np.exp(np.linspace(-lk/2, lk/2, d))) @ U.T
    A0h = sqrtm(A0).real; A0hi = np.linalg.inv(A0h); Mid = A0hi@A1@A0hi
    npth = 300
    path = [A0h @ fmp(Mid, s).real @ A0h for s in np.linspace(0,1,npth+1)]
    accS = sum(dS(path[k], path[k+1]) for k in range(npth))
    ratios.append(accS/dS(A0, A1))
fig, ax = plt.subplots(figsize=(5.2, 3.4))
ax.plot(lks, ratios, 'mo-')
ax.axhline(1.0, color='gray', lw=0.7)
ax.set_xlabel(r'$\log \kappa$ (rigidity contrast)'); ax.set_ylabel('accumulated / direct')
ax.set_title('Ledger metric: diminishing returns grow with contrast')
plt.tight_layout(); plt.savefig('fig4_color.pdf'); plt.close()
print("FIG4 done:", [f"{r:.3f}" for r in ratios])

# ---------- V2 GATE: corrected Eq (4.10) ----------
l = np.zeros((8,3,3), complex)
l[0][0,1]=l[0][1,0]=1; l[1][0,1]=-1j; l[1][1,0]=1j; l[2][0,0]=1; l[2][1,1]=-1
l[3][0,2]=l[3][2,0]=1; l[4][0,2]=-1j; l[4][2,0]=1j; l[5][1,2]=l[5][2,1]=1
l[6][1,2]=-1j; l[6][2,1]=1j; l[7]=np.diag([1,1,-2])/np.sqrt(3)
fabc = np.zeros((8,8,8))
for a in range(8):
    for b in range(8):
        cab = comm(l[a],l[b])
        for c in range(8): fabc[a,b,c] = (np.trace(cab@l[c])/(4j)).real
psi = rng.standard_normal(8) + 1j*rng.standard_normal(8)
A = sum(psi[a]*l[a] for a in range(8))
direct = -2*comm(comm(A, A.conj().T), A)
formula = 8j*sum(fabc[a,b,c]*fabc[c,d,e]*np.imag(psi[a]*np.conj(psi[b]))*psi[d]*l[e]
                 for a in range(8) for b in range(8) for c in range(8) for d in range(8) for e in range(8))
print("V2-GATE corrected (4.10): ||direct - formula|| =", np.linalg.norm(direct - formula))
