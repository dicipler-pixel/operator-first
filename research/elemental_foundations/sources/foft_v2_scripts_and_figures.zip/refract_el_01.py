# SCRIPT: REFRACT-EL-01  (integrate the actual EL dynamics through the mollified rigidity layer; test R sin^2 vs R sin)
import numpy as np
eps_layer = 0.05
def make_R(R1, R2):
    Rf  = lambda w: (R1+R2)/2 + (R2-R1)/2*np.tanh(w/eps_layer)
    dRf = lambda w: (R2-R1)/2/np.cosh(w/eps_layer)**2/eps_layer
    return Rf, dRf

def run(R1, R2, th1_deg, tmax=6.0, h=2e-5):
    Rf, dRf = make_R(R1, R2)
    th1 = np.radians(th1_deg)
    w, vpar, vper = -1.0, np.sin(th1), np.cos(th1)
    p0 = Rf(w)*vpar; E0 = 0.5*Rf(w)*(vpar**2+vper**2)
    def f(s):
        w, vpar, vper = s
        R, dR = Rf(w), dRf(w)
        return np.array([vper, -dR*vper*vpar/R, dR*(vpar**2 - vper**2)/(2*R)])
    s = np.array([w, vpar, vper]); t = 0.0
    while t < tmax:
        k1=f(s); k2=f(s+0.5*h*k1); k3=f(s+0.5*h*k2); k4=f(s+h*k3)
        s = s + (h/6)*(k1+2*k2+2*k3+k4); t += h
        if s[0] > 1.0 or (s[0] < -1.0 and s[2] < 0): break
    w, vpar, vper = s
    R = Rf(w)
    th_out = np.degrees(np.arcsin(abs(vpar)/np.hypot(vpar,vper)))
    outcome = "TRANSMITTED" if w > 0 else "REFLECTED"
    p_err = abs(R*vpar - p0)/abs(p0)
    E_err = abs(0.5*R*(vpar**2+vper**2) - E0)/E0
    sin2_in, sin2_out = R1*np.sin(th1)**2, R*(abs(vpar)/np.hypot(vpar,vper))**2
    sin_in, sin_out   = R1*np.sin(th1),    R*(abs(vpar)/np.hypot(vpar,vper))
    print(f"R1={R1} -> R2={R2}, th1={th1_deg:5.1f}deg: {outcome}, th_out={th_out:6.2f}deg | "
          f"p_par drift {p_err:.1e}, E drift {E_err:.1e}")
    print(f"    R sin^2: in {sin2_in:.6f} out {sin2_out:.6f} (rel diff {abs(sin2_in-sin2_out)/sin2_in:.1e})"
          f" | R sin: in {sin_in:.4f} out {sin_out:.4f} (rel diff {abs(sin_in-sin_out)/sin_in:.2f})")

print("Case A: low -> high rigidity, transmit and bend toward normal")
run(1.0, 4.0, 50.0)
print("Case B: high -> low, SUB-critical (theta_crit = arcsin sqrt(1/4) = 30 deg)")
run(4.0, 1.0, 20.0)
print("Case C: high -> low, SUPER-critical -> total reflection expected")
run(4.0, 1.0, 45.0)
