# SCRIPT: CONTAINER-GROUND-01  (his hypothesis: the container subspace is a ground state on equal footing; shape-independence)
import numpy as np
Lx = Ly = 44; Nsites = Lx*Ly
def idx2(x,y): return (x%Lx)*Ly + (y%Ly)
H = np.zeros((Nsites, Nsites), complex)
phx, phy = np.exp(1j*0.37/Lx), np.exp(1j*0.83/Ly)
m = 1.0
for x in range(Lx):
    for y in range(Ly):
        i = idx2(x,y)
        H[i, idx2(x+1,y)] += -phx; H[idx2(x+1,y), i] += -np.conj(phx)
        H[i, idx2(x,y+1)] += -phy; H[idx2(x,y+1), i] += -np.conj(phy)
        H[i,i] = m*(-1)**(x+y)
ev, V = np.linalg.eigh(H)
Vocc = V[:, ev < 0]
P = Vocc @ Vocc.conj().T
eps = 1e-3

def region_square(L, x0=4, y0=4):
    return [idx2(x0+x, y0+y) for x in range(L) for y in range(L)]
def region_diamond(r, cx=22, cy=22):
    return [idx2(x,y) for x in range(Lx) for y in range(Ly) if abs(x-cx)+abs(y-cy) <= r]
def boundary_sites(A):
    S = set(A); cnt = 0
    for i in A:
        x, yy = divmod(i, Ly)
        nbrs = [idx2(x+1,yy), idx2(x-1,yy), idx2(x,yy+1), idx2(x,yy-1)]
        if any(nb not in S for nb in nbrs): cnt += 1
    return cnt
def mid_spectrum(Mat):
    nu = np.linalg.eigvalsh(Mat)
    return np.sort(nu[(nu > eps) & (nu < 1-eps)])

print("=== CLAIM 1: state/container swap symmetry (square L=14) ===")
A = np.array(region_square(14))
nu_state_in_container = mid_spectrum(P[np.ix_(A,A)])                 # 1_A P 1_A
D = np.zeros(Nsites); D[A] = 1.0
M2 = Vocc.conj().T @ (D[:,None]*Vocc)                                # P 1_A P in the band frame
nu_container_in_state = mid_spectrum(M2)
print(f"channels either way: {len(nu_state_in_container)} vs {len(nu_container_in_state)}")
print(f"max |difference| of matched spectra: {np.max(np.abs(nu_state_in_container - nu_container_in_state)):.2e}")
print("(H_A = I - 2*1_A: flat bands at +-1, gap 2 -- the container IS a gapped ground state.)")

print()
print("=== CLAIM 2: container-shape independence (N per boundary site) ===")
for name, A in [("square L=14", region_square(14)), ("square L=18", region_square(18)),
                ("diamond r=10", region_diamond(10)), ("diamond r=13", region_diamond(13))]:
    A = np.array(A)
    N = len(mid_spectrum(P[np.ix_(A,A)]))
    b = boundary_sites(A)
    print(f"  {name:14s}: |A|={len(A):4d}  boundary sites={b:3d}  N={N:3d}  N/boundary = {N/b:.3f}")
