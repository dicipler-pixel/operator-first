#!/usr/bin/env python3
# ============================================================================
# SCRIPT: SPAN-UNIVERSAL-01b   (corrects two defects in SPAN-UNIVERSAL-01)
#
# Defect 1: xi estimator sampled only EVEN separations. The SSH chain is
#           bipartite+chiral at half filling, so same-sublattice correlations
#           vanish identically -> every point filtered out. Fixed: try both
#           parities, use whichever carries amplitude.
# Defect 2: second-neighbour hopping connects SAME-sublattice sites, breaking
#           the bipartite structure and pushing the system off half filling
#           (observed as a saturating xi ~ 310 = gapless, not long-ranged).
#           Fixed: THIRD-neighbour hopping, which is odd-distance and so
#           preserves the bipartite structure and the Dirac point while
#           changing the UV dispersion.
#
# Model validity is now MEASURED, not assumed: filling and spectral gap are
# reported for every point, and points that are not half-filled-and-gapped
# are rejected explicitly rather than silently skipped.
# ============================================================================
import numpy as np
from numpy.linalg import eigh

EPS = np.array([1e-2, 1e-4, 1e-6, 1e-8, 1e-10, 1e-12])

def build(kind, L, p):
    H = np.zeros((L, L))
    if kind == 'stag':
        for j in range(L):
            H[j, (j+1) % L] += -1.0; H[(j+1) % L, j] += -1.0
            H[j, j] = p * (-1)**j
    elif kind == 'ssh':
        for j in range(L):
            t = 1.0 + p if j % 2 == 0 else 1.0 - p
            H[j, (j+1) % L] += -t; H[(j+1) % L, j] += -t
    elif kind == 'nnn3':
        t3 = 0.30
        for j in range(L):
            H[j, (j+1) % L] += -1.0; H[(j+1) % L, j] += -1.0
            H[j, (j+3) % L] += -t3;  H[(j+3) % L, j] += -t3
            H[j, j] = p * (-1)**j
    w, V = eigh(H)
    occ = V[:, w < 0]
    gap = np.min(w[w > 0]) - np.max(w[w < 0]) if (np.any(w > 0) and np.any(w < 0)) else 0.0
    return occ @ occ.conj().T, occ.shape[1], gap

def measure_xi(C):
    """try both separation parities; use the one carrying amplitude"""
    L = C.shape[0]; best = np.nan; bestn = 0
    for off in (2, 1):
        rs = np.arange(off if off > 1 else 1, L//4, 2)
        v = np.abs(C[0, rs]); good = v > 1e-12
        if good.sum() < 6: continue
        r, vv = rs[good], v[good]
        s, _ = np.polyfit(r, np.log(vv), 1)
        if s < 0 and good.sum() > bestn:
            best, bestn = -1.0/s, good.sum()
    return best

def surface(kind, params, Lfun, label):
    print(f"\n--- {label} ---")
    print(f"  {'param':>8} {'L':>6} {'fill':>7} {'gap':>8} {'xi':>9}  "
          + "".join(f"{('N(%.0e)' % e):>9}" for e in EPS))
    xis, rows = [], []
    for p in params:
        L = Lfun(p); L -= L % 4
        C, nocc, gap = build(kind, L, p)
        ok_fill = (nocc == L//2)
        xi = measure_xi(C)
        ok = ok_fill and gap > 1e-6 and np.isfinite(xi) and 1.0 < xi < L/8
        nu = eigh(C[:L//2, :L//2])[0]
        row = [int(np.sum((nu > e) & (nu < 1-e))) for e in EPS]
        flag = "" if ok else "   <-- REJECTED"
        print(f"  {p:>8.4f} {L:>6} {nocc/L:>7.3f} {gap:>8.4f} {xi:>9.3f}  "
              + "".join(f"{v:>9d}" for v in row) + flag)
        if ok:
            xis.append(xi); rows.append(row)
    xis = np.array(xis); N = np.array(rows, float)
    if len(xis) < 4:
        print("  ==> too few valid points"); return None
    X, E = np.meshgrid(np.log(xis), np.log(1/EPS), indexing='ij')
    M = np.column_stack([(X*E).ravel(), X.ravel(), E.ravel(), np.ones(X.size)])
    coef, *_ = np.linalg.lstsq(M, N.ravel(), rcond=None)
    rs = np.random.default_rng(11); b = []
    for _ in range(4000):
        i = rs.integers(0, N.size, N.size)
        c, *_ = np.linalg.lstsq(M[i], N.ravel()[i], rcond=None); b.append(c[0])
    b = np.array(b)
    rms = np.sqrt(((N.ravel() - M @ coef)**2).mean())
    print(f"  ==> A = {coef[0]:.4f} +/- {b.std():.4f}   B = {coef[1]:.3f}  "
          f"C = {coef[2]:.3f}  D = {coef[3]:.3f}   rms = {rms:.3f}   xi range "
          f"{xis.min():.1f}-{xis.max():.1f}  (n = {len(xis)})")
    return coef[0], b.std()

res = {}
res['M1 staggered mass'] = surface('stag',
    [1.2, 0.8, 0.5, 0.3, 0.18, 0.10, 0.06, 0.035, 0.02, 0.012],
    lambda m: int(min(3600, max(1200, 500/m))), "M1  staggered-mass chain")
res['M2 SSH dimerised'] = surface('ssh',
    [0.60, 0.40, 0.25, 0.15, 0.09, 0.055, 0.03, 0.018, 0.011, 0.007],
    lambda d: int(min(3600, max(1200, 400/d))), "M2  SSH dimerised chain")
res['M3 stag + t3 NNN'] = surface('nnn3',
    [1.2, 0.8, 0.5, 0.3, 0.18, 0.10, 0.06, 0.035, 0.02, 0.012],
    lambda m: int(min(3600, max(1200, 500/m))), "M3  staggered + third-neighbour t3=0.30")

print("\n" + "=" * 78)
print("VERDICT -- is the anomaly coefficient A universal?")
print("=" * 78)
res = {k: v for k, v in res.items() if v is not None}
As = np.array([v[0] for v in res.values()]); Es = np.array([v[1] for v in res.values()])
for k, (a, e) in res.items():
    print(f"  {k:>20}   A = {a:.4f} +/- {e:.4f}")
wm = np.sum(As/Es**2)/np.sum(1/Es**2); se = np.sqrt(1/np.sum(1/Es**2))
chi2 = np.sum((As-wm)**2/Es**2); dof = len(As)-1
pair = max(abs(As[i]-As[j])/np.hypot(Es[i], Es[j])
           for i in range(len(As)) for j in range(i+1, len(As)))
print(f"\n  weighted mean A = {wm:.4f} +/- {se:.4f}")
print(f"  chi^2 = {chi2:.2f} on {dof} dof;  max pairwise tension = {pair:.2f} sigma")
print(f"  -> {'CONSISTENT WITH UNIVERSAL' if chi2 < 6 else 'MODEL DEPENDENT'}")
for cand, nm in [(2/np.pi**2,'2/pi^2'), (0.2,'1/5'), (1/6,'1/6'), (np.log(2)/np.pi**2*3,'3ln2/pi^2')]:
    print(f"    vs {nm:>10} = {cand:.4f} : {(wm-cand)/se:+.2f} sigma")
print("\nDONE -- SPAN-UNIVERSAL-01b")
