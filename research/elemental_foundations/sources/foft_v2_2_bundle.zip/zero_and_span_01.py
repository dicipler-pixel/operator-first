#!/usr/bin/env python3
# ============================================================================
# SCRIPT: ZERO-AND-SPAN-01
# Purpose: does the operator-first framework have a SPAN (dilation) invariance
#          to match the Baseline Theorem's ZERO (tare) invariance K -> K + cI?
#
# Test A : global rescale K -> cK           -> projectors / principal angles
# Test B : IR direction  L/xi               -> census N vs region size
# Test C : UV direction  xi/a               -> census N vs correlation length
# Test D : threshold     epsilon            -> is N a plateau or a slider?
# Test E : flow homogeneity + Henrici       -> K_c(t) =?= c K_1(c^2 t)
# Test F : which observables are span-free  -> explicit invariant/covariant list
# ============================================================================
import numpy as np
from numpy.linalg import eigh, eig, norm

rng = np.random.default_rng(20260812)
np.set_printoptions(precision=6, suppress=True)

def banner(s):
    print("\n" + "=" * 74); print(s); print("=" * 74)

# ---------------------------------------------------------------- Test A ----
banner("TEST A -- global rescale K -> cK : Grassmannian data (anchor lemma)")

n = 8
K = rng.normal(size=(n, n)) + 1j * rng.normal(size=(n, n))
K = K + 0.6 * (rng.normal(size=(n, n)) + 1j * rng.normal(size=(n, n)))

def band_projector(M, k):
    """spectral projector onto the k eigenvalues of smallest real part (Riesz-equivalent)"""
    w, V = eig(M)
    idx = np.argsort(w.real)[:k]
    R = V[:, idx]
    # oblique projector via biorthogonal left vectors
    return R @ np.linalg.pinv(R)

for c in [1e-6, 0.5, 3.0, 1e6]:
    P1 = band_projector(K, 3)
    Pc = band_projector(c * K, 3)
    print(f"  c = {c:>10.1e}   ||P(cK) - P(K)||_F = {norm(Pc - P1):.3e}")

# principal angles between Ran(P) and a fixed random subspace
Q = np.linalg.qr(rng.normal(size=(n, 3)) + 1j * rng.normal(size=(n, 3)))[0]
def principal_angles(A, B):
    s = np.linalg.svd(A.conj().T @ B, compute_uv=False)
    return np.arccos(np.clip(s, -1, 1))
def ran_basis(M, k):
    w, V = eig(M); idx = np.argsort(w.real)[:k]
    return np.linalg.qr(V[:, idx])[0]
a1 = principal_angles(ran_basis(K, 3), Q)
ac = principal_angles(ran_basis(1e6 * K, 3), Q)
print(f"  principal angles  max |theta(cK) - theta(K)| = {np.max(np.abs(ac - a1)):.3e}")

# ---------------------------------------------------- lattice machinery ----
def staggered_chain(L, m, t=1.0):
    """periodic 1D chain, staggered mass m, half filling. returns correlation matrix C."""
    H = np.zeros((L, L))
    for j in range(L):
        H[j, (j + 1) % L] = -t
        H[(j + 1) % L, j] = -t
        H[j, j] = m * (-1) ** j
    w, V = eigh(H)
    occ = V[:, w < 0]
    return occ @ occ.conj().T

def measure_xi(C):
    """correlation length from exponential decay of |C_{0,r}| on the same sublattice"""
    L = C.shape[0]
    rs = np.arange(2, L // 4, 2)          # same sublattice, avoid r=0 and the far cut
    vals = np.abs(C[0, rs])
    good = vals > 1e-13
    rs, vals = rs[good], vals[good]
    if len(rs) < 4:
        return np.nan
    slope = np.polyfit(rs, np.log(vals), 1)[0]
    return -1.0 / slope

def census(C, L, ell, eps):
    """N = # eigenvalues of C_A in [eps, 1-eps] for A = contiguous block of ell sites"""
    CA = C[:ell, :ell]
    nu = eigh(CA)[0]
    return int(np.sum((nu > eps) & (nu < 1 - eps))), nu

# ---------------------------------------------------------------- Test B ----
banner("TEST B -- IR direction: does N depend on region size L_A at fixed xi?")

m_fix, eps = 0.30, 1e-3
L = 1600
C = staggered_chain(L, m_fix)
xi = measure_xi(C)
print(f"  m = {m_fix},  measured xi = {xi:.3f} lattice units,  eps = {eps}")
print(f"  {'L_A':>6} {'L_A/xi':>9} {'N':>5}")
for ell in [40, 80, 160, 320, 640, 800]:
    N, _ = census(C, L, ell, eps)
    print(f"  {ell:>6} {ell/xi:>9.1f} {N:>5}")

# ---------------------------------------------------------------- Test C ----
banner("TEST C -- UV direction: does N depend on xi/a ?  (a = lattice spacing = 1)")

print(f"  {'m':>8} {'xi':>9} {'N':>5} {'N/2 (per cut)':>15}")
ms = [1.2, 0.8, 0.5, 0.3, 0.18, 0.10, 0.06, 0.035, 0.02]
xis, Ns = [], []
for m in ms:
    L = int(min(4000, max(800, 400 / m)))
    L -= L % 4
    C = staggered_chain(L, m)
    xi = measure_xi(C)
    N, _ = census(C, L, L // 2, eps)
    xis.append(xi); Ns.append(N)
    print(f"  {m:>8.3f} {xi:>9.3f} {N:>5} {N/2:>15.1f}")

xis = np.array(xis); Ns = np.array(Ns, float)
lin = np.polyfit(xis, Ns, 1)
log = np.polyfit(np.log(xis), Ns, 1)
res_lin = np.std(Ns - np.polyval(lin, xis))
res_log = np.std(Ns - np.polyval(log, np.log(xis)))
print(f"\n  fit  N = a*xi + b        : a = {lin[0]:.4f}  b = {lin[1]:.3f}   resid = {res_lin:.3f}")
print(f"  fit  N = a*log(xi) + b   : a = {log[0]:.4f}  b = {log[1]:.3f}   resid = {res_log:.3f}")
print(f"  N * (a/xi)  (would be const if N ~ xi) : {np.round(Ns/xis, 4)}")

# ---------------------------------------------------------------- Test D ----
banner("TEST D -- threshold: is N(eps) a plateau or a slider?")

C = staggered_chain(1600, 0.30)
print(f"  {'eps':>10} {'N':>5}")
for e in [1e-1, 1e-2, 1e-3, 1e-4, 1e-6, 1e-8, 1e-10, 1e-12]:
    N, nu = census(C, 1600, 800, e)
    print(f"  {e:>10.0e} {N:>5}")
_, nu = census(C, 1600, 800, 1e-12)
mid = np.sort(np.minimum(nu, 1 - nu))[::-1][:10]
print(f"  top-10 margins min(nu,1-nu): {np.round(mid, 6)}")

# ---------------------------------------------------------------- Test E ----
banner("TEST E -- flow homogeneity  dK/dt = -2[[K,K+],K]  and Henrici budget")

def rhs(M):
    Cm = M @ M.conj().T - M.conj().T @ M
    return -2.0 * (Cm @ M - M @ Cm)

def rk4(M, dt, steps):
    for _ in range(steps):
        k1 = rhs(M); k2 = rhs(M + dt/2*k1); k3 = rhs(M + dt/2*k2); k4 = rhs(M + dt*k3)
        M = M + dt/6*(k1 + 2*k2 + 2*k3 + k4)
    return M

K0 = rng.normal(size=(6, 6)) + 1j * rng.normal(size=(6, 6))
K0 = K0 / norm(K0) * 2.0
for c in [0.5, 2.0, 5.0]:
    T, steps = 0.02, 400
    A = rk4(K0.copy(), T/steps, steps)                  # K_1 at time T
    B = rk4((c*K0).copy(), (T/c**2)/steps, steps)       # K_c at time T/c^2
    print(f"  c = {c:>4} : || K_c(T/c^2) - c*K_1(T) ||_F = {norm(B - c*A):.3e}"
          f"   (rel {norm(B - c*A)/norm(c*A):.2e})")

def Phi(M):
    Cm = M @ M.conj().T - M.conj().T @ M
    return 0.5 * norm(Cm)**2
print(f"\n  Henrici identity d||K||^2/dt = -8*Phi under K -> cK:")
for c in [1.0, 3.0]:
    M = c * K0
    dt = 1e-7
    lhs = (norm(rk4(M.copy(), dt, 1))**2 - norm(M)**2) / dt
    print(f"    c = {c:>4}  d||K||^2/dt = {lhs:>14.5f}   -8*Phi = {-8*Phi(M):>14.5f}"
          f"   ratio to c=1: {lhs/((norm(rk4((K0).copy(), dt,1))**2-norm(K0)**2)/dt):.4f}  (expect c^4 = {c**4:.1f})")

# ---------------------------------------------------------------- Test F ----
banner("TEST F -- which observables are span-free? (K -> cK, c = 7)")

c = 7.0
def kappas(M):
    w, R = eig(M); _, Lft = eig(M.conj().T)
    ks = []
    for i in range(M.shape[0]):
        j = np.argmax(np.abs(Lft.conj().T @ R[:, i]))
        ks.append(1.0 / abs(np.vdot(Lft[:, j], R[:, i])))
    return np.sort(ks)

def henrici2(M):
    w = eig(M)[0]
    return norm(M)**2 - np.sum(np.abs(w)**2)

rows = [
    ("||K||_F",            lambda M: norm(M)),
    ("Phi(K)",             lambda M: Phi(M)),
    ("Henrici Delta^2_F",  lambda M: henrici2(M)),
    ("Delta^2_F/||K||^2",  lambda M: henrici2(M)/norm(M)**2),
    ("max kappa_i",        lambda M: kappas(M)[-1]),
    ("spec radius",        lambda M: np.max(np.abs(eig(M)[0]))),
    ("|lam_max|/|lam_min|",lambda M: np.max(np.abs(eig(M)[0]))/np.min(np.abs(eig(M)[0]))),
]
print(f"  {'observable':>22} {'value(K)':>14} {'value(cK)':>14} {'ratio':>12} {'expect':>10}")
for name, f in rows:
    v1, v2 = f(K0), f(c*K0)
    print(f"  {name:>22} {v1:>14.6f} {v2:>14.6f} {v2/v1:>12.6f} {'':>10}")
print(f"\n  reference powers of c: c={c}, c^2={c**2}, c^4={c**4}")
print("\nDONE -- ZERO-AND-SPAN-01")
