#!/usr/bin/env python3
# ============================================================================
# SCRIPT: SPAN-CLOSE-A-01
# Closes the anomaly coefficient A analytically, with numerical confirmation
# of every link in the chain.
#
# CHAIN:
#   (i)   entanglement levels of a gapped free-fermion chain are equally
#         spaced  -- already MEASURED (gaps 3.001 nine times in a row)
#   (ii)  int_{-inf}^{inf} H(1/(1+e^eps)) d eps = pi^2/3  exactly
#         => S = (pi^2/3) * rho,  rho = level density per unit eps
#   (iii) N counts levels with |eps| < Lambda, so dN/dLambda = 2 rho
#         => S = (pi^2/6) * dN/dLambda
#   (iv)  Calabrese-Cardy: gapped, c=1, block with TWO boundary points
#         => S = (1/3) log(xi/a) + const
#   ==>   dN/dLambda = (6/pi^2)(1/3) log xi  =>  A = 2/pi^2 = 0.2026423...
#
# WHY THIS BEATS THE EARLIER ESTIMATORS: the window count reached |e| < 30,
# deep into the region where the ladder is no longer uniform -- that was the
# systematic. The entropy integrand is dominated by |eps| <~ 5, exactly where
# uniformity holds. S is the systematic-free version of the same measurement.
#
# DECISIVE TEST:  dS/dlog(xi) = 1/3 ?   If yes, A = 2/pi^2 and 1/5 is dead.
# ============================================================================
import numpy as np
from numpy.linalg import eigh
from scipy.integrate import quad

print("=" * 80)
print("(ii) the exact integral")
print("=" * 80)
def Hdens(e):
    nu = 1.0/(1.0+np.exp(e))
    nu = min(max(nu, 1e-300), 1-1e-16)
    return -(nu*np.log(nu) + (1-nu)*np.log(1-nu))
val, err = quad(Hdens, -60, 60, limit=400)
print(f"   int H d(eps)   = {val:.12f}   (err {err:.1e})")
print(f"   pi^2/3         = {np.pi**2/3:.12f}    diff = {abs(val-np.pi**2/3):.2e}")

NK = 1 << 14
def bloch_corr(M, m):
    k = 2*np.pi*np.arange(NK)/NK
    dx = -(1.0+np.cos(k)); dy = -np.sin(k); dz = m*np.ones_like(k)
    n = np.sqrt(dx*dx+dy*dy+dz*dz)
    p11 = 0.5*(1-dz/n); p22 = 0.5*(1+dz/n); p12 = -0.5*(dx-1j*dy)/n
    G11 = np.fft.ifft(p11); G22 = np.fft.ifft(p22)
    G12 = np.fft.ifft(p12); G21 = np.conj(np.fft.ifft(np.conj(p12)))
    C = np.zeros((2*M, 2*M), dtype=complex); idx = np.arange(M)
    R = (idx[:, None]-idx[None, :]) % NK
    C[0::2, 0::2] = G11[R]; C[1::2, 1::2] = G22[R]
    C[0::2, 1::2] = G12[R]; C[1::2, 0::2] = G21[R]
    return C
xi_exact = lambda m: 2.0/np.arccosh(1.0 + m*m/2.0)

print("\n" + "=" * 80)
print("(iv) DECISIVE TEST:  is  dS/dlog(xi) = 1/3 ?")
print("=" * 80)
print(f"   {'m':>8} {'xi':>10} {'sites':>7} {'S (block)':>12} {'S - (1/3)log xi':>17}")
xs, Ss = [], []
for m in [0.60, 0.40, 0.28, 0.18, 0.12, 0.075, 0.048, 0.030, 0.019, 0.012, 0.0075, 0.0048]:
    xi = xi_exact(m)
    Ms = int(min(4000, max(900, 8*xi))); Ms -= Ms % 2
    if Ms/xi < 5.5: continue
    nu = eigh(bloch_corr(Ms//2, m))[0]
    nu = np.clip(nu, 1e-300, 1-1e-16)
    S = float(-np.sum(nu*np.log(nu) + (1-nu)*np.log(1-nu)))
    xs.append(np.log(xi)); Ss.append(S)
    print(f"   {m:>8.4f} {xi:>10.3f} {Ms:>7} {S:>12.6f} {S-np.log(xi)/3:>17.6f}")
xs = np.array(xs); Ss = np.array(Ss)
slope, c0 = np.polyfit(xs, Ss, 1)
res = Ss - (slope*xs + c0)
rs = np.random.default_rng(9)
bt = np.array([np.polyfit(xs[i], Ss[i], 1)[0]
               for i in (rs.integers(0, len(xs), len(xs)) for _ in range(5000))])
print(f"\n   dS/dlog(xi) = {slope:.6f} +/- {bt.std():.6f}      intercept = {c0:.5f}")
print(f"   predicted    1/3 = {1/3:.6f}      deviation = {(slope-1/3)/bt.std():+.2f} sigma")
print(f"   rms residual = {np.sqrt((res**2).mean()):.5f}")

# window-window systematic check: refit dropping the smallest-xi points
for drop in (0, 2, 4):
    s2 = np.polyfit(xs[drop:], Ss[drop:], 1)[0]
    print(f"     dropping {drop} smallest-xi points: dS/dlog(xi) = {s2:.6f}")

A = (6/np.pi**2)*slope
Aerr = (6/np.pi**2)*bt.std()
print("\n" + "=" * 80)
print("(v) THE COEFFICIENT")
print("=" * 80)
print(f"   A = (6/pi^2) * dS/dlog(xi) = {A:.6f} +/- {Aerr:.6f}")
print(f"   2/pi^2                     = {2/np.pi**2:.6f}   -> {(A-2/np.pi**2)/Aerr:+.2f} sigma")
print(f"   1/5                        = {0.200000:.6f}   -> {(A-0.2)/Aerr:+.2f} sigma")
print(f"\n   prior direct measurements: 0.2018 +/- 0.0064, 0.1919 +/- 0.0078, 0.2056 +/- 0.0087")

print("\n" + "=" * 80)
print("(iii) cross-check the bridge  S = (pi^2/6) * dN/dLambda  at one point")
print("=" * 80)
m = 0.030; xi = xi_exact(m); Ms = int(min(4000, max(900, 8*xi))); Ms -= Ms % 2
nu = eigh(bloch_corr(Ms//2, m))[0]
nuc = np.clip(nu, 1e-300, 1-1e-16)
S = float(-np.sum(nuc*np.log(nuc) + (1-nuc)*np.log(1-nuc)))
e = np.abs(np.log((1-nu[(nu > 1e-15) & (nu < 1-1e-15)])/nu[(nu > 1e-15) & (nu < 1-1e-15)]))
dNdL = (np.sum(e < 28) - np.sum(e < 8))/20.0
print(f"   xi = {xi:.2f}:  S = {S:.5f}   (pi^2/6)*dN/dLambda = {np.pi**2/6*dNdL:.5f}"
      f"   ratio = {S/(np.pi**2/6*dNdL):.4f}")
print("   (ratio near 1 confirms the bridge; the window count is the noisier side)")
