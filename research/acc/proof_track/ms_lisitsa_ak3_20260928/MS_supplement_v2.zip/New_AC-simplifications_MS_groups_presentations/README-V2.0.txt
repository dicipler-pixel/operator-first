Version 2.0 
============

This folder  contains supplementary materials for the papers
"New Andrews-Curtis trivializations  for Miller-Schupp groups presentations"
and "Automated Theorem Proving Reveals a Lengthy Andrews-Curtis
Trivialization for a Miller-Schupp Trivial Group Presentation" (tentative, as of Jan 2025) 

The files *.txt contain extracted from proofs sequences of transformations to witness MS_{n}(w^[\ast}) =>*_ <ab^{-1}a^{-3},a^{-1}b^{-1}aba^{-1}> for n = 3...9 

Only first relators  of the presentations are shown. The second relator  a^{-1}b^{-1}aba^{-1} does not change.  

Each line represents a relator,  and a name of the transformation applied. The transformations are named as follows 

[INV]: <r1,r2> -> <r1^{-1},r2>
[MULT]: <r1,r2> -> <r1*r2,r2>
[CONJ]: <r1,r2> -> <z*r1*z^{-1},r2> for some z

We denote a^{-1} and b^{-1} by capital letters A and B, respectively. 