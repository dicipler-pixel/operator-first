# SCRIPT: BOB-XFER-LIB-01
# Library: pool, class-mates (autos <= 3, optional width 4-5), carry(A path -> B) via twin_transfer + block splice, official replay.
import json, sys, itertools
sys.path.insert(0, '/home/claude/kernel'); sys.path.insert(0, '/home/claude/bob_splice')
from ms_detect import sub, cyc_forms, autos, red, is_basis
from twin_transfer import transfer, SYMS
from ms_route import run, T
from load_bundle_v1 import lib
from block_splice_v1 import make_steps, splice_path
from verifier.core import free_reduce
def parse(desc):
    body = desc.split('|')[1].split('>')[0]; out = []
    for part in body.split(';'):
        w = []
        for t in part.replace('= 1', '').split():
            g = 1 if t[0] == 'x' else 2; w.append(-g if '^-1' in t else g)
        out.append(w)
    return out
def apply_sym(w, s):
    sw, sx, sy = s; o = []
    for a in w:
        g = abs(a); sg = 1 if a > 0 else -1
        o.append(((2 if sw else 1) * sg * sx) if g == 1 else ((1 if sw else 2) * sg * sy))
    return o
def key(R): return frozenset([min(cyc_forms(R[0])), min(cyc_forms(R[1]))])
pool = {}
for l in open('/home/claude/sair/competition/problems/ac.jsonl'):
    d = json.loads(l); pool[d['challenge_id']] = parse(d['description'])
bykey = {}
for cid, R in pool.items():
    for s in SYMS: bykey.setdefault(key([apply_sym(R[0], s), apply_sym(R[1], s)]), set()).add(cid)
def mates(A, au=autos):
    RA = pool[A]; out = {}
    for a, b in au:
        R2 = [sub(RA[0], {1: a, 2: b}), sub(RA[1], {1: a, 2: b})]
        if len(R2[0]) + len(R2[1]) > 44: continue
        for B in bykey.get(key(R2), ()):
            if B != A and B not in out: out[B] = (a, b)
    return out
steps = make_steps(lib)
def s0_of(B): R = pool[B]; return (free_reduce(tuple(R[0])), free_reduce(tuple(R[1])))
def carry(A, pA, B, au=autos):
    RA, RB = pool[A], pool[B]
    keysA = [key([apply_sym(RA[0], s), apply_sym(RA[1], s)]) for s in SYMS]
    psi = next(((a, b) for a, b in au if key([sub(RB[0], {1: a, 2: b}), sub(RB[1], {1: a, 2: b})]) in keysA), None)
    if psi is None: return None
    line = transfer(RB, psi, [tuple(RA[0]), tuple(RA[1])], pA)
    if line is None: return None
    s0 = s0_of(B)
    short = list(splice_path(s0, line, steps, max_len=40))
    return short if run(s0, short) == T else None
