# SCRIPT: BOB-CROSSROAD-ITER-01
# Compounding cross-road: every verified cross-road output becomes a new road; pairs involving a new road
# are crossed again, until a pass adds nothing new. Roads deduplicated by exact move list.
import json, sys, time, itertools
sys.path.insert(0, '.')
from crossroad_drive_v1 import cross
from bfs_drive_v1 import states, bfs_splice
from verifier.core import free_reduce
T = ((1,), (2,))
RF, RB, SL, MAXP = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
roads = json.load(open(sys.argv[5])); rows = sys.argv[6].split(',')
for f in sys.argv[7:]:
    for l in open(f):
        d = json.loads(l)
        if d.get('path') and d['id'] in roads: roads[d['id']]['roads']['cr_%s_%s' % (d['A'][:12], d['B'][:12])] = d['path']
out = open('crossroad_iter_R%d%d_S%d.jsonl' % (RF, RB, SL), 'a')
for t in rows:
    R = roads[t]; rel = R['start']; s0 = (free_reduce(tuple(rel[0])), free_reduce(tuple(rel[1])))
    pool = {}
    for n, p in R['roads'].items():
        if states(s0, p)[-1] == T and tuple(p) not in {tuple(q) for q in pool.values()}: pool[n] = p
    tried = set(); rnd = 0
    while True:
        rnd += 1; names = sorted(pool, key=lambda n: len(pool[n]))[:MAXP]; added = 0
        for a, b in itertools.permutations(names, 2):
            if (a, b) in tried: continue
            tried.add((a, b)); t0 = time.time()
            new = cross(rel, pool[a], pool[b], RF, RB, SL)
            if new is None: continue
            fin, _ = bfs_splice(rel, new, 5, 4, SL)
            if states(s0, fin)[-1] != T: fin = new
            if tuple(fin) in {tuple(q) for q in pool.values()}: continue
            nm = 'it%d_%d' % (rnd, len(pool)); pool[nm] = fin; added += 1
            rec = dict(id=t, round=rnd, A=a, B=b, new=len(fin), record=R['record'], hit=len(fin) <= R['record'], path=fin, sec=round(time.time() - t0, 1))
            out.write(json.dumps(rec) + '\n'); out.flush()
            print(t, 'round', rnd, a, len(pool[a]), '+', b, len(pool[b]), '->', len(fin), 'rec', R['record'], flush=True)
        if added == 0: break
    print(t, 'done, best', min(len(p) for p in pool.values()), 'roads', len(pool), flush=True)
