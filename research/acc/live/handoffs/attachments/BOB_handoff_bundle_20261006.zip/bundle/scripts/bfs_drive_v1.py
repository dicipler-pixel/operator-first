# SCRIPT: BOB-BFS-SPLICE-DRIVE-01
# Loop the exact meet-in-the-middle splice until no saving. The C++ side returns the forward half
# of the bridge and the backward depth d2; the backward half is re-found here by BFS under the
# official core, the bridge is checked to carry state_i exactly to state_k, and the line replayed.
import subprocess, sys
from collections import deque
sys.path.insert(0, '/home/claude/sair/competition/tools')
from verifier.core import apply_move, free_reduce
def states(s0, p):
    S = [s0]
    for m in p: S.append(apply_move(S[-1], m))
    return S
def bfs_to(a, b, d):
    q = deque([(a, [])]); seen = {a}
    while q:
        u, p = q.popleft()
        if u == b: return p
        if len(p) >= d: continue
        for m in range(14):
            v = apply_move(u, m)
            if v not in seen: seen.add(v); q.append((v, p + [m]))
    return None
def bfs_splice(rel, path, RF=5, RB=4, slack=2, timeout=1800):
    s0 = (free_reduce(tuple(rel[0])), free_reduce(tuple(rel[1])))
    path = list(path); log = []
    while True:
        inp = ' '.join(map(str, s0[0])) + '\n' + ' '.join(map(str, s0[1])) + '\n' + ' '.join(map(str, path)) + '\n'
        out = subprocess.run(['./bfs_splice', str(RF), str(RB), str(slack)], input=inp, capture_output=True, text=True, timeout=timeout).stdout.split()
        if not out or out[0] != 'BEST': return path, log
        sav, i, k, d2 = map(int, out[1:5]); fwd = list(map(int, out[5:]))
        S = states(s0, path)
        t = S[i]
        for m in fwd: t = apply_move(t, m)
        tail = bfs_to(t, S[k], d2)
        if tail is None: log.append(dict(reject=True)); return path, log
        new = path[:i] + fwd + tail + path[k:]
        if len(new) >= len(path): return path, log
        path = new; log.append(dict(i=i, k=k, saving=len(fwd) + len(tail), new_len=len(path)))
