# SCRIPT: BOB-SEEDED-COLLAPSE-01  collapse search seeded from points on a known road:
# for every k along the road, keep prefix road[:k], run collapse beam + finish from that state; keep shortest verified total.
import json,sys
sys.path.insert(0,'/home/claude/onex'); sys.path.insert(0,'/home/claude/kernel'); sys.path.insert(0,'/home/claude/bob_splice')
from onex_solve import stage1, stage2
from pool_lib import s0_of, ok
from drive import run
t=sys.argv[1]; road=json.load(open(sys.argv[2])); rec=int(sys.argv[3]); W=int(sys.argv[4]); step=int(sys.argv[5])
s0=s0_of(t); best=None
for k in range(0,len(road),step):
    s=run(s0,road[:k])
    L=len(s[0])+len(s[1])
    for A in (2,4):
        p1=stage1(s,60,L+30,W,A,1)
        if p1 is None: continue
        p2=stage2(run(s,p1))
        if p2 is None: continue
        tot=road[:k]+p1+p2
        if ok(t,tot) and (best is None or len(tot)<len(best)): best=tot
        print(t,'k',k,'A',A,'total',len(tot),'best',len(best) if best else None,'rec',rec,flush=True)
if best:
    print('BEST',t,len(best),json.dumps(best),flush=True)
