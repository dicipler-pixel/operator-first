# SCRIPT: BOB-PUSH-POOL-01
# Push every row's team-pool path (session 1 pool, 01 Oct 00:45Z) across its change-of-generators class onto
# every class-mate; compare with the team pool's own best on the mate and the 09-29 record. Official replay
# inside carry(). Resumable, sharded.
import json, sys, glob
sys.path.insert(0, '/home/claude/kernel'); sys.path.insert(0, '/home/claude/bob_splice')
from xfer_lib_v1 import mates, carry
from pool_lib import ok
shard, nsh = int(sys.argv[1]), int(sys.argv[2])
P = {}
for f in sorted(glob.glob('pool_s1_part*.txt')):
    for l in open(f):
        if l.startswith('ac-'):
            t, p = l.split(':', 1)
            try: p = json.loads(p)
            except Exception: continue
            if ok(t.strip(), p): P[t.strip()] = p
b = {r['id']: r for r in json.load(open('bundle5.json'))['rows']}
fn = 'push_pool_s%d.jsonl' % shard; done = set()
try:
    for l in open(fn): done.add(json.loads(l)['source'])
except FileNotFoundError: pass
out = open(fn, 'a')
for i, A in enumerate(sorted(P)):
    if i % nsh != shard or A in done: continue
    M = mates(A); res = []
    for B in sorted(M):
        try: p = carry(A, P[A], B)
        except Exception: p = None
        if not p: continue
        have = len(P[B]) if B in P else None
        rb = b.get(B); rec = rb and rb['record']
        res.append(dict(target=B, len=len(p), pool=have, rec0929=rec, path=p if (have is None or len(p) < have) else None))
    out.write(json.dumps(dict(source=A, src_len=len(P[A]), n_mates=len(M), res=res)) + '\n'); out.flush()
    for r in res:
        if r['path']: print(A, '->', r['target'], r['len'], 'pool', r['pool'], 'rec0929', r['rec0929'], flush=True)
print('done', flush=True)
