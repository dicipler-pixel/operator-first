import json,csv
from collections import Counter
D='/home/claude/sair/competition/'
ch=json.load(open(D+'tools/verifier/data/manifest.json'))['challenges']
def red(w):
    o=[]
    for a in w:
        if o and o[-1]==-a:o.pop()
        else:o.append(a)
    while len(o)>1 and o[0]==-o[-1]: o=o[1:-1]
    return o
def cyc(w):
    w=red(w); c=[]
    for v in (w,[-a for a in reversed(w)]):
        for i in range(len(v)): c.append(tuple(v[i:]+v[:i]))
    return min(c) if c else ()
SYM=[lambda a:a, lambda a:{1:2,2:1,-1:-2,-2:-1}[a], lambda a:-a if abs(a)==1 else a, lambda a:-a if abs(a)==2 else a]
def syms(w):
    out=[]
    for s1 in (0,1):
        for ix in (0,1):
            for iy in (0,1):
                def f(a):
                    if s1: a={1:2,2:1,-1:-2,-2:-1}[a]
                    if ix and abs(a)==1: a=-a
                    if iy and abs(a)==2: a=-a
                    return a
                out.append([f(a) for a in w])
    return out
def key(r0,r1,full=False):
    if not full: return tuple(sorted([cyc(r0),cyc(r1)]))
    ks=[]
    for i in range(8):
        a=syms(r0)[i];b=syms(r1)[i]; ks.append(tuple(sorted([cyc(a),cyc(b)])))
    return min(ks)
idxA={};idxB={}
for c in ch:
    if c['challenge_id'].startswith('ac-'):
        r0,r1=c['initial_relators']
        idxA[key(r0,r1)]=c['challenge_id']; idxB[key(r0,r1,True)]=c['challenge_id']
rows=[]
for r in csv.DictReader(open(D+'tools/verifier/data/ms1190_metadata.csv')):
    n=int(r['n']); w=list(map(int,r['w_vector'].split()))
    r0=[-1]+[2]*n+[1]+[-2]*(n+1); r1=[1]+[-a for a in reversed(w)]
    a=idxA.get(key(r0,r1)); b=idxB.get(key(r0,r1,True))
    rows.append(dict(seq=int(r['seq']),n=n,w=r['w_vector'],st=r['status_at_freeze'],tid=r['training_id'],plen=r['prototype_path_length'],cidA=a,cidB=b))
json.dump(rows,open('ms_map.json','w'))
print(Counter((x['st'],x['cidA'] is not None,x['cidB'] is not None) for x in rows))
