# SCRIPT: BOB-SONG2-PULSE-XW-01  "same pulse underneath": replay every training path skeleton (any w) on every scored MS row,
# re-pumping each run of a repeated move to length 0..L+4, canonical start; hits carried to scored id by xlate_v1.
import json,itertools,sys
from lift_v1 import start,run,T
from xlate_v1 import xlate
sys.path.insert(0,'/home/claude/bob_splice'); from pool_lib import ok
tr=json.load(open('/home/claude/sair/competition/examples/training_424.json'))['instances']
rows=json.load(open('ms_map2.json'))
def runs(p):
    out=[]
    for m,g in itertools.groupby(p): out.append((m,len(list(g))))
    return out
def variants(p):
    R=runs(p); idx=[i for i,(m,c) in enumerate(R) if c>=2]
    seen=set()
    for i in idx[:3]:
        for c in range(0,R[i][1]+5):
            q=[];
            for j,(m,k) in enumerate(R): q+= [m]*(c if j==i else k)
            t=tuple(q)
            if t not in seen: seen.add(t); yield q
    yield p
skel=[]; seen=set()
for t in tr:
    for q in variants(t['moves']):
        if tuple(q) not in seen: seen.add(tuple(q)); skel.append((t['training_id'],q))
print('skeletons',len(skel),flush=True)
out=open('pulse_xw_v1.jsonl','w'); done=set()
for x in rows:
    if not x['cidB'] or x['st']=='certified' or x['cidB'] in done: continue
    done.add(x['cidB']); w=[int(a) for a in x['w'].split()]; s0=start(x['n'],w); best=None
    for tid,q in skel:
        if (best is None or len(q)<len(best[1])) and run(s0,q,300)==T: best=(tid,q)
    if best:
        from pool_lib import s0_of
        p=xlate(s0,s0_of(x['cidB']),best[1])
        good=p is not None and ok(x['cidB'],p)
        out.write(json.dumps(dict(cid=x['cidB'],n=x['n'],w=x['w'],st=x['st'],src=best[0],canon_len=len(best[1]),path=p,ok=good))+'\n'); out.flush()
        print('HIT',x['cidB'],x['n'],x['st'],best[0],len(best[1]),p and len(p),good,flush=True)
print('done',len(done),flush=True)
