// SCRIPT: BOB-ONEX-BEAM-02 (adds length weight B: score = A*minletters + B*len)  beam toward the one-letter collapse (score = A*min letter count of one generator in one relator + total length)
// derived from BOB-ONEX-01  "x appears once" stage search (song2: same pulse underneath -> the x=y^k collapse seen in the MS(3) 14-move path)
// BFS (official ac-r2-v1 moves) from start; goal = a relator with exactly ONE letter of one generator g (cyclically),
// whose substitution into the other relator leaves exponent +-1 in the other generator (group-level collapse is trivial).
// argv: maxdepth lencap maxgoals ; stdin: r0 line, r1 line.  prints "GOAL d moves..." per goal found (shortest first).
#include <cstdio>
#include <vector>
#include <string>
#include <unordered_map>
#include <iostream>
#include <sstream>
#include <cstdint>
#include <cstdlib>
using namespace std;
typedef vector<int8_t> W;
struct St { W a, b; };
static void pushc(W &o, int8_t c) { if (!o.empty() && o.back() == -c) o.pop_back(); else o.push_back(c); }
static St ap(const St &s, int m) {
    St t = s;
    if (m == 0) { W o; for (int i = s.a.size() - 1; i >= 0; i--) o.push_back(-s.a[i]); t.a = o; return t; }
    if (m == 1) { W o; for (int i = s.b.size() - 1; i >= 0; i--) o.push_back(-s.b[i]); t.b = o; return t; }
    if (m >= 2 && m <= 5) {
        const W &X = (m <= 3) ? s.a : s.b; const W &Y = (m <= 3) ? s.b : s.a;
        W o; for (auto c : X) pushc(o, c);
        if (m == 2 || m == 4) { for (auto c : Y) pushc(o, c); } else { for (int i = Y.size() - 1; i >= 0; i--) pushc(o, -Y[i]); }
        if (m <= 3) t.a = o; else t.b = o; return t;
    }
    int k = (m <= 9) ? m - 6 : m - 10;
    int8_t g = (k == 0) ? 1 : (k == 1) ? -1 : (k == 2) ? 2 : -2;
    const W &X = (m <= 9) ? s.a : s.b;
    W o; pushc(o, g); for (auto c : X) pushc(o, c); pushc(o, -g);
    if (m <= 9) t.a = o; else t.b = o; return t;
}
static uint64_t H(const St &s) {
    uint64_t h = 1469598103934665603ULL;
    for (auto c : s.a) { h ^= (uint8_t)c; h *= 1099511628211ULL; }
    h ^= 0x77; h *= 1099511628211ULL;
    for (auto c : s.b) { h ^= (uint8_t)c; h *= 1099511628211ULL; }
    return h;
}
static W cycred(const W &w) { size_t i = 0, j = w.size(); while (j - i >= 2 && w[i] == -w[j - 1]) { i++; j--; } return W(w.begin() + i, w.begin() + j); }
// count letters of generator g, exponent sums
static bool goal(const St &s) {
    for (int r = 0; r < 2; r++) {
        W u = cycred(r == 0 ? s.a : s.b); const W &o = (r == 0 ? s.b : s.a);
        for (int g = 1; g <= 2; g++) {
            int cnt = 0, eg = 0, eh = 0;
            for (auto c : u) { if (abs(c) == g) { cnt++; eg += (c > 0 ? 1 : -1); } else eh += (c > 0 ? 1 : -1); }
            if (cnt != 1) continue;
            // u = g^eg * v(h): g = h^(-eh*eg)  (eg=+-1)
            int k = -eh * eg; int og = 0, oh = 0;
            for (auto c : o) { if (abs(c) == g) og += (c > 0 ? 1 : -1); else oh += (c > 0 ? 1 : -1); }
            int tot = oh + og * k;
            if (tot == 1 || tot == -1) return true;
        }
    }
    return false;
}
static vector<int> readints(const string &line) { vector<int> v; stringstream ss(line); int x; while (ss >> x) v.push_back(x); return v; }


static int Bw = 1;
static int score(const St &s, int A) {
    int best = 1000;
    for (int r = 0; r < 2; r++) { W u = cycred(r == 0 ? s.a : s.b);
        for (int g = 1; g <= 2; g++) { int c = 0; for (auto x : u) if (abs(x) == g) c++; if (c > 0 && c < best) best = c; } }
    return A * best + Bw * (int)(s.a.size() + s.b.size());
}
#include <algorithm>
#include <unordered_set>
struct N { St s; vector<int8_t> p; int sc; };
int main(int argc, char **argv) {
    int D = atoi(argv[1]); size_t cap = atoi(argv[2]); int Wd = atoi(argv[3]); int A = atoi(argv[4]); unsigned seed = atoi(argv[5]); if (argc > 6) Bw = atoi(argv[6]);
    string l; getline(cin, l); auto r0 = readints(l); getline(cin, l); auto r1 = readints(l);
    St s0; for (int c : r0) s0.a.push_back(c); for (int c : r1) s0.b.push_back(c);
    unordered_set<uint64_t> seen; vector<N> fr{ { s0, {}, 0 } }; seen.insert(H(s0));
    srand(seed);
    for (int d = 1; d <= D; d++) {
        vector<N> nx;
        for (auto &n : fr) for (int m = 0; m < 14; m++) {
            St t = ap(n.s, m); if (t.a.empty() || t.b.empty() || t.a.size() + t.b.size() > cap) continue;
            uint64_t h = H(t); if (!seen.insert(h).second) continue;
            N q{ t, n.p, 0 }; q.p.push_back(m);
            if (goal(t)) { printf("GOAL %d", d); for (auto x : q.p) printf(" %d", x); printf("\n"); return 0; }
            q.sc = score(t, A) * 1000 + (rand() % 1000); nx.push_back(q);
        }
        if (nx.size() > (size_t)Wd) { nth_element(nx.begin(), nx.begin() + Wd, nx.end(), [](const N &a, const N &b) { return a.sc < b.sc; }); nx.resize(Wd); }
        fr.swap(nx); if (fr.empty()) break;
    }
    printf("NONE\n"); return 0;
}
