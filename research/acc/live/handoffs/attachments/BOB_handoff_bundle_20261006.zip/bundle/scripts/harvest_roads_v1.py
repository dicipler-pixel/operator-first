# SCRIPT: BOB-HARVEST-ROADS-01
# Song idea "look in the glass": grow many DIFFERENT verified roads for one row, as fuel for cross-road.
# Beam (beam_traits, modes x seeds) is run on each of the 8 letter-symmetric mirror images of the start;
# the found path is mapped back through the mirror (conjugating letters permuted), finished, and replayed
# from the official start with the official core. Output: harvest_<row>.jsonl (one road per line).
import json, sys, subprocess, time
sys.path.insert(0, '.')
from drive import finish, run
from twin_transfer import SYMS
from verifier.core import free_reduce, apply_move
t, W, L, EX, TO = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
modes = list(map(int, sys.argv[6].split(','))); seeds = list(map(int, sys.argv[7].split(',')))
b = {r['id']: r for r in json.load(open('bundle5.json'))['rows']}
def parse(desc):
    body = desc.split('|')[1].split('>')[0]; out = []
    for part in body.split(';'):
        w = []
        for x in part.replace('= 1', '').split():
            g = 1 if x[0] == 'x' else 2; w.append(-g if '^-1' in x else g)
        out.append(w)
    return out
pool = {}
for l in open('/home/claude/sair/competition/problems/ac.jsonl'):
    d = json.loads(l); pool[d['challenge_id']] = parse(d['description'])
rel = pool[t]; rec = int(sys.argv[8]) if len(sys.argv) > 8 else (b[t]['record'] if t in b else 99)
def sym_letter(a, s):
    sw, sx, sy = s; g = abs(a); sg = 1 if a > 0 else -1
    return ((2 if sw else 1) * sg * sx) if g == 1 else ((1 if sw else 2) * sg * sy)
LET = {6: 1, 7: -1, 8: 2, 9: -2}
def map_back(p, s):
    # a move conjugating by letter g on the image corresponds to conjugating by sym^-1(g) on the original
    inv = {}
    for g in (1, -1, 2, -2): inv[sym_letter(g, s)] = g
    out = []
    for m in p:
        if m < 6: out.append(m); continue
        base = 6 if m <= 9 else 10; g = LET[m - base + 6]; h = inv[g]
        out.append(base + {1: 0, -1: 1, 2: 2, -2: 3}[h])
    return out
s0 = (free_reduce(tuple(rel[0])), free_reduce(tuple(rel[1])))
fn = 'harvest_%s.jsonl' % t; seen = set()
try:
    for l in open(fn): seen.add(tuple(json.loads(l)['path']))
except FileNotFoundError: pass
out = open(fn, 'a')
for si, s in enumerate(SYMS):
    img = [[sym_letter(a, s) for a in rel[0]], [sym_letter(a, s) for a in rel[1]]]
    for m in modes:
        for sd in seeds:
            try:
                o = subprocess.run(['./beam_traits', ','.join(map(str, img[0])), ','.join(map(str, img[1])), str(W), str(rec + EX), str(L), str(sd), str(m)], capture_output=True, text=True, timeout=TO).stdout.strip()
            except subprocess.TimeoutExpired: continue
            if not o.startswith('PATH'): continue
            q = map_back(list(map(int, o.split()[1:])), s)
            f = finish(run(s0, q))
            if f is None: continue
            p = q + f
            if run(s0, p) != ((1,), (2,)) or tuple(p) in seen: continue
            seen.add(tuple(p))
            out.write(json.dumps(dict(id=t, sym=si, mode=m, seed=sd, len=len(p), path=p)) + '\n'); out.flush()
            print(t, 'sym', si, 'mode', m, 'seed', sd, 'len', len(p), flush=True)
