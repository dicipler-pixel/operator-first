# SCRIPT: BOB-LIFT-FRAME-01  lift a held path from a lower ladder row onto an upper row in every frame
# (8 letter symmetries x relator swap), then single edits (pump/shrink a run by 1-2, insert 1 move, delete 1 move).
import json,sys,itertools
sys.path.insert(0,'/home/claude/bob_splice'); from pool_lib import s0_of, ok
from xlate_v1 import SY, map_move
from lift_v1 import run,T
team={}
for l in open('team_paths.txt'):
    t,p=l.split(':',1);t=t.strip()
    try:p=json.loads(p)
    except: continue
    if t not in team or len(p)<len(team[t]): team[t]=p
def runs(p): return [(m,len(list(g))) for m,g in itertools.groupby(p)]
def edits(p):
    yield p
    R=runs(p)
    for i,(m,c) in enumerate(R):
        for d in (-2,-1,1,2,3):
            if c+d<0: continue
            q=[]
            for j,(mm,k) in enumerate(R): q+=[mm]*(k+d if j==i else k)
            yield q
    for i in range(len(p)+1):
        for m in range(14): yield p[:i]+[m]+p[i:]
    for i in range(len(p)): yield p[:i]+p[i+1:]
def lift(up,low):
    s0=s0_of(up); p=team[low]; best=None
    for f in SY:
        for sw in (0,1):
            q0=[map_move(m,f,sw) for m in p]
            for q in edits(q0):
                if run(s0,q,300)==T and ok(up,q) and (best is None or len(q)<len(best)): best=q
    return best
if __name__=='__main__':
    for pair in sys.argv[1:]:
        up,low=pair.split(':'); b=lift(up,low)
        print(up,'from',low,len(team[low]),'->',b and len(b),json.dumps(b) if b else '',flush=True)
