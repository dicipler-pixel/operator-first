# SCRIPT: BOB-CROSSROAD-DRIVE-01
# For each row, every ordered pair of distinct verified roads (A, B): shortest A[:i] + exact bridge + B[k:].
# Bridge = forward half from the C++ + backward half re-found by BFS under the official core; the whole
# line is replayed from the official start. Result is then passed through the ordinary one-road splice.
import json, sys, subprocess, time, itertools
sys.path.insert(0, '.')
from bfs_drive_v1 import states, bfs_to, bfs_splice
from verifier.core import apply_move, free_reduce
T = ((1,), (2,))
def cross(rel, A, B, RF, RB, SL):
    s0 = (free_reduce(tuple(rel[0])), free_reduce(tuple(rel[1])))
    inp = '\n'.join(' '.join(map(str, x)) for x in (s0[0], s0[1], A, B)) + '\n'
    out = subprocess.run(['./crossroad', str(RF), str(RB), str(SL)], input=inp, capture_output=True, text=True, timeout=3000).stdout.split()
    if not out or out[0] != 'BEST': return None
    tot, i, k, d2 = map(int, out[1:5]); fwd = list(map(int, out[5:]))
    t = states(s0, A)[i]
    for m in fwd: t = apply_move(t, m)
    tail = bfs_to(t, states(s0, B)[k], d2)
    if tail is None: return None
    new = A[:i] + fwd + tail + B[k:]
    return new if states(s0, new)[-1] == T else None
if __name__ == '__main__':
    RF, RB, SL = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    roads = json.load(open(sys.argv[4]))   # {row: {"start":..., "record":..., "roads": {name: path}}}
    out = open('crossroad_R%d%d_S%d.jsonl' % (RF, RB, SL), 'a')
    for t, R in roads.items():
        rel = R['start']; s0 = (free_reduce(tuple(rel[0])), free_reduce(tuple(rel[1])))
        names = [n for n, p in R['roads'].items() if states(s0, p)[-1] == T]
        best = min(len(R['roads'][n]) for n in names)
        for a, b in itertools.permutations(names, 2):
            t0 = time.time(); A, B = R['roads'][a], R['roads'][b]
            new = cross(rel, A, B, RF, RB, SL); fin = None
            if new is not None:
                fin, _ = bfs_splice(rel, new, 5, 4, SL)
                if states(s0, fin)[-1] != T: fin = new
            rec = dict(id=t, A=a, lenA=len(A), B=b, lenB=len(B), record=R['record'], new=fin and len(fin), hit=bool(fin) and len(fin) <= R['record'], path=fin, sec=round(time.time() - t0, 1))
            out.write(json.dumps(rec) + '\n'); out.flush()
            print(t, a, len(A), '+', b, len(B), '->', rec['new'], 'rec', R['record'], rec['sec'], flush=True)
