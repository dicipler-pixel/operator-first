# SCRIPT: BOB-MS-LIFT-DOWN-01  opposite lift: take a path for MS(n+k,w) and SHORTEN it onto MS(n,w)
# (shorten one run of a repeated move by 1..k+2, or delete 1..2 single moves); also up-lift with run-pumping.
import json,sys,itertools
from lift_v1 import start,run,T,P
from xlate_v1 import xlate
sys.path.insert(0,'/home/claude/bob_splice'); from pool_lib import ok,s0_of
rows=json.load(open('ms_map2.json'))
TG=sys.argv[1].split(',')
extra={}  # scored-id -> path (team/push paths on higher-n rows)
for f in sys.argv[2:]:
    for l in open(f):
        if l.startswith(('ac-')):
            t,p=l.split(':',1); extra[t.strip()]=json.loads(p)
def runs(p): return [(m,len(list(g))) for m,g in itertools.groupby(p)]
def shorten(p,maxcut):
    R=runs(p)
    for i,(m,c) in enumerate(R):
        for d in range(1,min(c,maxcut)+1):
            q=[]
            for j,(mm,k) in enumerate(R): q+=[mm]*(k-d if j==i else k)
            yield q
    for i in range(len(p)): yield p[:i]+p[i+1:]
def pump(p,maxadd):
    R=runs(p)
    for i,(m,c) in enumerate(R):
        for d in range(1,maxadd+1):
            q=[]
            for j,(mm,k) in enumerate(R): q+=[mm]*(k+d if j==i else k)
            yield q
for tgt in TG:
    ws=[x for x in rows if x['cidB']==tgt]; best=None
    for x in ws:
        w=tuple(int(a) for a in x['w'].split()); n=x['n']; s0=start(n,list(w))
        srcs=[]
        for k,p in P[w].items(): srcs.append((k,p,'train'))
        for y in rows:
            if y['w']==x['w'] and y['cidB'] in extra and y['n']!=n:
                cp=xlate(s0_of(y['cidB']),start(y['n'],list(w)),extra[y['cidB']])
                if cp: srcs.append((y['n'],cp,'team:'+y['cidB']))
        for k,p,lab in srcs:
            cands=[]
            if k>n:
                for q in shorten(p,k-n+2): cands.append(q)
                for q in list(shorten(p,k-n+2)):
                    if len(q)<80:
                        for r in shorten(q,k-n+2): cands.append(r)
            elif k<n:
                cands=list(pump(p,n-k+2))
            for q in cands:
                if run(s0,q,300)==T and (best is None or len(q)<len(best[2])):
                    best=(x['w'],lab+f' n{k}',q,s0)
            print(tgt,'w',x['w'],'src',lab,'n',k,'len',len(p),'cands',len(cands),'best',best and len(best[2]),flush=True)
    if best:
        sp=xlate(best[3],s0_of(tgt),best[2])
        print('HIT',tgt,best[1],len(best[2]),'scored len',sp and len(sp), sp and ok(tgt,sp),flush=True)
        if sp and ok(tgt,sp): open(f'FIRST_{tgt}.txt','w').write(f'{tgt}: {json.dumps(sp)}\n')
