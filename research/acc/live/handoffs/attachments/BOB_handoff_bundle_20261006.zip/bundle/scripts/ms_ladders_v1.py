# SCRIPT: BOB-MS-LADDERS-01  find every scored row with an MS relator x^-1 y^n x y^-(n+1) (any rotation/inverse/x-y symmetry),
# group rows into ladders by the OTHER relator (normalized by the same symmetry), mark team-held rows.
import json,sys
from collections import defaultdict
sys.path.insert(0,'/home/claude/bob_splice'); from pool_lib import POOL
def cyc(w):
    w=list(w)
    while len(w)>=2 and w[0]==-w[-1]: w=w[1:-1]
    return w
def canon(w):
    w=cyc(w); c=[]
    for v in (w,[-a for a in reversed(w)]):
        for i in range(len(v)): c.append(tuple(v[i:]+v[:i]))
    return min(c) if c else ()
SYM=[]
for sw in (0,1):
  for ix in (0,1):
    for iy in (0,1):
      SYM.append((sw,ix,iy))
def ap(f,a):
    sw,ix,iy=f
    if sw: a={1:2,2:1,-1:-2,-2:-1}[a]
    if ix and abs(a)==1: a=-a
    if iy and abs(a)==2: a=-a
    return a
STD={canon([-1]+[2]*n+[1]+[-2]*(n+1)):n for n in range(1,15)}
team=set()
for l in open('team_paths.txt'): team.add(l.split(':')[0].strip())
lad=defaultdict(dict)
for t,R in POOL.items():
    for i in (0,1):
        for f in SYM:
            c=canon([ap(f,a) for a in R[i]])
            if c in STD:
                n=STD[c]; key=canon([ap(f,a) for a in R[1-i]])
                lad[key].setdefault(n,set()).add(t)
rows=[]
for key,d in lad.items():
    if len(d)<2: continue
    ns=sorted(d)
    for n in ns:
        for t in d[n]:
            held=t in team
            below=[u for m in ns if m<n for u in d[m] if u in team]
            above=[u for m in ns if m>n for u in d[m] if u in team]
            rows.append((t,n,len(key),held,below,above))
json.dump([dict(id=r[0],n=r[1],wlen=r[2],held=r[3],below=r[4],above=r[5]) for r in rows],open('ms_ladders_v1.json','w'))
lads=[k for k,d in lad.items() if len(d)>=2]
print('ladders with >=2 levels',len(lads),'rows on ladders',len(rows))
comb=[r for r in rows if not r[3] and r[4]]
print('unheld rows with a held lower rung',len(set(r[0] for r in comb)))
