# SCRIPT: BOB-MS-LIFT-01  insert-k-moves lift of MS(n,w) path onto MS(n+k',w) canonical start
import json,sys,itertools
sys.path.insert(0,'/home/claude/sair/competition/tools')
from verifier.core import free_reduce, apply_move
from collections import defaultdict
tr=json.load(open('/home/claude/sair/competition/examples/training_424.json'))['instances']
P=defaultdict(dict)
for t in tr: P[tuple(t['w_vector'])][t['n']]=t['moves']
def start(n,w):
    r0=[-1]+[2]*n+[1]+[-2]*(n+1); r1=[1]+[-a for a in reversed(w)]
    return (free_reduce(tuple(r0)),free_reduce(tuple(r1)))
T=((1,),(2,))
def run(s,p,cap=200):
    for m in p:
        s=apply_move(s,m)
        if len(s[0])+len(s[1])>cap: return None
    return s
def lift(n,w,src,maxins=2):
    s0=start(n,w); hits=[]
    if run(s0,src)==T: return [src]
    L=len(src)
    for i in range(L+1):
        for m in range(14):
            p=src[:i]+[m]+src[i:]
            if run(s0,p)==T: hits.append(p)
    if hits or maxins<2: return hits
    # prefix states cache for speed
    pref=[s0]
    for m in src: pref.append(apply_move(pref[-1],m))
    for i in range(L+1):
        for m1 in range(14):
            s1=apply_move(pref[i],m1)
            for j in range(i,L+1):
                s=run(s1,src[i:j])
                if s is None: break
                for m2 in range(14):
                    if run(apply_move(s,m2),src[j:])==T: hits.append(src[:i]+[m1]+src[i:j]+[m2]+src[j:])
                if len(hits)>20: return hits
    return hits
if __name__=='__main__':
    # self-test on training: n -> n+1 where both certified
    tot=ok=0
    for w,d in P.items():
        for n in d:
            if n+1 in d and n+1<=7:
                tot+=1; h=lift(n+1,list(w),d[n],1)
                if h: ok+=1
    print('training single-insert lift hit rate',ok,tot)
