# SCRIPT: BOB-ONEX-SOLVE-01  stage 1: onex_beam to the one-letter collapse; stage 2: beam_traits + finish to trivial; official replay.
import subprocess,sys,json
sys.path.insert(0,'/home/claude/kernel'); sys.path.insert(0,'/home/claude/bob_splice')
from pool_lib import s0_of, ok
from drive import finish, run
def stage1(s,D,cap,W,A,seed):
    o=subprocess.run(['/home/claude/onex/onex_beam',str(D),str(cap),str(W),str(A),str(seed)],input=' '.join(map(str,s[0]))+'\n'+' '.join(map(str,s[1]))+'\n',capture_output=True,text=True,timeout=600).stdout.split()
    return list(map(int,o[2:])) if o and o[0]=='GOAL' else None
def stage2(s,W=5000,D=40,L=44):
    for mode in (0,5,3):
        try: o=subprocess.run(['/home/claude/kernel/beam_traits',','.join(map(str,s[0])),','.join(map(str,s[1])),str(W),str(D),str(L),'1',str(mode)],capture_output=True,text=True,timeout=120).stdout.strip()
        except subprocess.TimeoutExpired: continue
        if o.startswith('PATH'):
            q=list(map(int,o.split()[1:])); f=finish(run(s,q))
            if f is not None: return q+f
    return None
if __name__=='__main__':
    rows=sys.argv[1].split(','); D,capx,W=int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4])
    for t in rows:
        s0=s0_of(t); best=None
        for A in (2,4,8):
            for seed in (1,2):
                p1=stage1(s0,D,len(s0[0])+len(s0[1])+capx,W,A,seed)
                if p1 is None: print(t,'A',A,'seed',seed,'stage1 NONE',flush=True); continue
                s=run(s0,p1); p2=stage2(s)
                tot=p1+p2 if p2 is not None else None
                good=tot is not None and ok(t,tot)
                print(t,'A',A,'seed',seed,'stage1',len(p1),'stage2',p2 and len(p2),'ok',good,flush=True)
                if good and (best is None or len(tot)<len(best)): best=tot
        if best: print('BEST',t,len(best),json.dumps(best),flush=True)
