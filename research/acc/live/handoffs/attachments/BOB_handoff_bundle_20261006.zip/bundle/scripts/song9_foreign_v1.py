# SCRIPT: BOB-SONG9-FOREIGN-01  song 9 "let something foreign touch the inside":
# carry roads from twin rows (change of generators) onto ac-06045, then cross each FOREIGN road with each TEAM road.
import json,sys,glob,time
sys.path.insert(0,'/home/claude/bob_splice')
import xfer_lib_v1 as X
from crossroad_drive_v1 import cross
from pool_lib import ok
t='ac-06045'; rec=36
team=json.load(open('/home/claude/bob_splice/roads_tie4_v1.json'))[t]['roads']
src={}
for l in open('/home/claude/comb/team_paths.txt'):
    a,p=l.split(':',1);a=a.strip()
    try:p=json.loads(p)
    except: continue
    src.setdefault(a,[]).append(p)
foreign={}
for B in X.mates(t):
    for i,p in enumerate(src.get(B,[])):
        try: q=X.carry(B,p,t)
        except Exception as e: q=None
        if q and ok(t,q): foreign[f'f_{B}_{i}']=q; print('foreign',B,len(p),'->',len(q),flush=True)
print('foreign roads',len(foreign),flush=True)
best=None; t0=time.time()
for fa,fp in sorted(foreign.items(),key=lambda z:len(z[1])):
    for ta,tp in sorted(team.items(),key=lambda z:len(z[1])):
        for A,B in ((fp,tp),(tp,fp)):
            if time.time()-t0>3000: break
            new=cross(X.pool[t],A,B,5,5,6)
            if new and ok(t,new):
                print('CROSS',fa,ta,len(new),'rec',rec,flush=True)
                if best is None or len(new)<len(best): best=new
print('BEST',best and len(best),json.dumps(best) if best else '',flush=True)
