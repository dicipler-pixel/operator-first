// SCRIPT: BOB-CROSSROAD-SPLICE-01 (from BOB-BFS-SPLICE-01)
// Cross-road splice: prefix of road A (line 3) + exact bridge + suffix of road B (line 4).
// Prints "BEST total i k d2 fwd..." for the shortest A[:i]+bridge+B[k:] found, or NONE if not shorter than both.
// Exact meet-in-the-middle splice with single moves (official ac-r2-v1 semantics, free reduction):
// backward balls (radius RB) around EVERY state S[k] of the path, forward ball (radius RF) from
// each S[i]; a meet with d1 + d2 < k - i is a shorter bridge. Length cap = path max + slack.
// Prints "BEST saving i k d2 f1 f2 ..." (forward moves; the last d2 moves are found by the caller) or "NONE". Caller re-verifies with the official core.
// stdin: r0 line, r1 line, path line.  argv: RF RB slack
#include <cstdio>
#include <vector>
#include <string>
#include <unordered_map>
#include <iostream>
#include <sstream>
#include <cstdint>
#include <cstdlib>
using namespace std;
typedef vector<int8_t> W;
struct St { W a, b; };
static void pushc(W &o, int8_t c) { if (!o.empty() && o.back() == -c) o.pop_back(); else o.push_back(c); }
static St ap(const St &s, int m) {
    St t = s;
    if (m == 0) { W o; for (int i = s.a.size() - 1; i >= 0; i--) o.push_back(-s.a[i]); t.a = o; return t; }
    if (m == 1) { W o; for (int i = s.b.size() - 1; i >= 0; i--) o.push_back(-s.b[i]); t.b = o; return t; }
    if (m >= 2 && m <= 5) {
        const W &X = (m <= 3) ? s.a : s.b; const W &Y = (m <= 3) ? s.b : s.a;
        W o; for (auto c : X) pushc(o, c);
        if (m == 2 || m == 4) { for (auto c : Y) pushc(o, c); } else { for (int i = Y.size() - 1; i >= 0; i--) pushc(o, -Y[i]); }
        if (m <= 3) t.a = o; else t.b = o; return t;
    }
    int k = (m <= 9) ? m - 6 : m - 10;
    int8_t g = (k == 0) ? 1 : (k == 1) ? -1 : (k == 2) ? 2 : -2;
    const W &X = (m <= 9) ? s.a : s.b;
    W o; pushc(o, g); for (auto c : X) pushc(o, c); pushc(o, -g);
    if (m <= 9) t.a = o; else t.b = o; return t;
}
static const int INV[14] = {0, 1, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12};
static uint64_t H(const St &s) {
    uint64_t h = 1469598103934665603ULL;
    for (auto c : s.a) { h ^= (uint8_t)c; h *= 1099511628211ULL; }
    h ^= 0x77; h *= 1099511628211ULL;
    for (auto c : s.b) { h ^= (uint8_t)c; h *= 1099511628211ULL; }
    return h;
}
static vector<int> readints(const string &line) { vector<int> v; stringstream ss(line); int x; while (ss >> x) v.push_back(x); return v; }
struct BE { int k; int d; uint64_t par; int8_t mv; };  // here: reaches SB[k] in d moves  // backward entry: state -> reaches S[k] in d moves
int main(int argc, char **argv) {
    int RF = atoi(argv[1]), RB = atoi(argv[2]), slack = atoi(argv[3]);
    string l; getline(cin, l); auto r0 = readints(l); getline(cin, l); auto r1 = readints(l);
    getline(cin, l); auto path = readints(l); getline(cin, l); auto pathB = readints(l);
    St s0; for (int c : r0) s0.a.push_back(c); for (int c : r1) s0.b.push_back(c);
    vector<St> S{ s0 }; for (int m : path) S.push_back(ap(S.back(), m));
    vector<St> SB{ s0 }; for (int m : pathB) SB.push_back(ap(SB.back(), m));
    int L = path.size(), LB = pathB.size(); size_t mx = 0;
    for (auto &s : S) mx = max(mx, s.a.size() + s.b.size());
    for (auto &s : SB) mx = max(mx, s.a.size() + s.b.size());
    size_t cap = mx + slack;
    // backward balls: for each k, BFS with inverse moves; store per state the best (max k - d)
    // and a parent pointer (hash of the state one step closer to S[k], and the forward move).
    unordered_map<uint64_t, BE> back; back.reserve(4000000);
    unordered_map<uint64_t, St> store; store.reserve(4000000);
    for (int k = LB; k >= 0; k--) {
        vector<St> fr{ SB[k] }; unordered_map<uint64_t, int> seen; seen[H(SB[k])] = 0;
        { uint64_t h = H(SB[k]); auto it = back.find(h); if (it == back.end() || k > it->second.k) { back[h] = {k, 0, 0, -1}; store[h] = SB[k]; } }
        for (int d = 1; d <= RB; d++) {
            vector<St> nf;
            for (auto &u : fr) {
                uint64_t hu = H(u);
                for (int m = 0; m < 14; m++) {
                    St v = ap(u, INV[m]);           // v --m--> u
                    if (v.a.empty() || v.b.empty() || v.a.size() + v.b.size() > cap) continue;
                    uint64_t hv = H(v);
                    if (seen.count(hv)) continue;
                    seen[hv] = d; nf.push_back(v);
                    auto it = back.find(hv);
                    if (it == back.end() || k - d > it->second.k - it->second.d) { back[hv] = {k, d, hu, (int8_t)m}; store[hv] = v; }
                }
            }
            fr.swap(nf);
        }
    }
    int best = (int)min(L, LB), bi = -1, bk = -1, bd2 = 0; vector<int> bridge;
    for (int i = 0; i < L; i++) {
        // forward BFS from S[i] with parents
        unordered_map<uint64_t, pair<uint64_t, int8_t>> par; par.reserve(1 << 20);
        unordered_map<uint64_t, St> fs;
        vector<St> fr{ S[i] }; uint64_t h0 = H(S[i]); par[h0] = {0, -1}; fs[h0] = S[i];
        for (int d = 0; d <= RF; d++) {
            vector<St> nf;
            for (auto &u : fr) {
                uint64_t hu = H(u);
                auto it = back.find(hu);
                if (it != back.end()) {
                    int tot = i + d + it->second.d + (LB - it->second.k);
                    if (tot < best) {
                        best = tot; bi = i; bk = it->second.k; bridge.clear();
                        vector<int> fwd; uint64_t x = hu;
                        while (par[x].second >= 0) { fwd.push_back(par[x].second); x = par[x].first; }
                        for (int t = fwd.size() - 1; t >= 0; t--) bridge.push_back(fwd[t]);
                        bd2 = it->second.d;
                    }
                }
                if (d == RF) continue;
                for (int m = 0; m < 14; m++) {
                    St v = ap(u, m);
                    if (v.a.empty() || v.b.empty() || v.a.size() + v.b.size() > cap) continue;
                    uint64_t hv = H(v);
                    if (par.count(hv)) continue;
                    par[hv] = {hu, (int8_t)m}; nf.push_back(v);
                }
            }
            fr.swap(nf);
        }
    }
    if (bi < 0) { printf("NONE\n"); return 0; }
    printf("BEST %d %d %d %d", best, bi, bk, bd2); for (int m : bridge) printf(" %d", m); printf("\n");
    return 0;
}
