# SCRIPT: BOB-MS-XLATE-01  carry a path from canonical MS start C to scored start S (rotation/inverse/order/letter symmetry)
import sys,itertools
sys.path.insert(0,'/home/claude/sair/competition/tools')
from verifier.core import free_reduce, apply_move
T=((1,),(2,))
CONJ={1:0,-1:1,2:2,-2:3}   # conj letter -> offset (x,X,y,Y)
def syms():
    out=[]
    for sw in (0,1):
        for ix in (0,1):
            for iy in (0,1):
                def f(a,sw=sw,ix=ix,iy=iy):
                    if sw: a={1:2,2:1,-1:-2,-2:-1}[a]
                    if ix and abs(a)==1: a=-a
                    if iy and abs(a)==2: a=-a
                    return a
                out.append(f)
    return out
SY=syms()
def map_move(m,f,swap):
    if m<6:
        if swap: m={0:1,1:0,2:4,4:2,3:5,5:3}[m]
        return m
    rel=0 if m<10 else 1; L=[1,-1,2,-2][(m-6)%4]
    if swap: rel=1-rel
    return 6+4*rel+CONJ[f(L)]
def inv(w): return tuple(-a for a in reversed(w))
def rot_moves(cur,tgt,ri):
    # moves turning relator cur into tgt by conjugation(rotation); None if not a rotation
    L=len(cur)
    if L!=len(tgt): return None
    for k in range(L):
        if cur[k:]+cur[:k]==tgt:
            if k<=L-k: return [6+4*ri+CONJ[-a] for a in cur[:k]]
            return [6+4*ri+CONJ[a] for a in reversed(cur[k:])]
    return None
def bfs_fix(s,tgt=T,depth=6):
    from collections import deque
    if s==tgt: return []
    seen={s:None}; q=deque([(s,[])])
    while q:
        st,p=q.popleft()
        if len(p)>=depth: continue
        for m in range(14):
            n=apply_move(st,m)
            if n in seen or len(n[0])+len(n[1])>len(st[0])+len(st[1])+4: continue
            if n==tgt: return p+[m]
            seen[n]=1; q.append((n,p+[m]))
    return None
def xlate(C,S,path):
    best=None
    for f in SY:
        for swap in (0,1):
            sc=[tuple(f(a) for a in C[0]),tuple(f(a) for a in C[1])]
            if swap: sc=sc[::-1]
            pre=[]; ok=True
            for ri in (0,1):
                cur=S[ri]; mv=rot_moves(cur,sc[ri],ri)
                if mv is None:
                    mv2=rot_moves(inv(cur),sc[ri],ri)
                    if mv2 is None: ok=False;break
                    mv=[ri]+mv2
                pre+=mv
            if not ok: continue
            s=S
            for m in pre: s=apply_move(s,m)
            if s!=tuple(sc): continue
            body=[map_move(m,f,swap) for m in path]
            for m in body: s=apply_move(s,m)
            suf=bfs_fix(s)
            if suf is None: continue
            p=pre+body+suf
            if best is None or len(p)<len(best): best=p
    return best
if __name__=='__main__':
    import json
    from lift_v1 import start,P
    sys.path.insert(0,'/home/claude/bob_splice'); from pool_lib import s0_of, ok
    rows=json.load(open('ms_map2.json')); n=0
    for x in rows:
        if x['st']=='certified' and x['cidB']:
            w=tuple(int(a) for a in x['w'].split()); C=start(x['n'],list(w))
            p=xlate(C,s0_of(x['cidB']),P[w][x['n']]); print(x['cidB'],len(P[w][x['n']]),p and len(p), p and ok(x['cidB'],p))
