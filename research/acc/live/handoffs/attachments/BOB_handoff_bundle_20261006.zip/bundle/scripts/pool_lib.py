# SCRIPT: BOB-POOL-LIB-01  official pool starts (free-reduced) by challenge id
import json, sys
sys.path.insert(0, '/home/claude/sair/competition/tools')
from verifier.core import free_reduce, apply_move
def _parse(desc):
    body = desc.split('|')[1].split('>')[0]; out = []
    for part in body.split(';'):
        w = []
        for x in part.replace('= 1', '').split():
            g = 1 if x[0] == 'x' else 2; w.append(-g if '^-1' in x else g)
        out.append(w)
    return out
POOL = {}
for _l in open('/home/claude/sair/competition/problems/ac.jsonl'):
    _d = json.loads(_l); POOL[_d['challenge_id']] = _parse(_d['description'])
def s0_of(t): R = POOL[t]; return (free_reduce(tuple(R[0])), free_reduce(tuple(R[1])))
def ok(t, p):
    s = s0_of(t)
    for m in p: s = apply_move(s, m)
    return s == ((1,), (2,))
def roads_entry(t, rec, roads):
    s0 = s0_of(t); return {t: dict(start=[list(s0[0]), list(s0[1])], record=rec, roads={n: p for n, p in roads.items() if ok(t, p)})}
