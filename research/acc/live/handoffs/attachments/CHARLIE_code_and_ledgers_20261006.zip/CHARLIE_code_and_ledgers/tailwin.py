# SCRIPT: CHARLIE_TAILWIN -- exact tail shortening of a route to ((y),(x)), using the prebuilt trivial ball.
# Route states s_0..s_n with s_n = ((y),(x)). For a tail of length L (state s_{n-L}), the shortest route
# s_{n-L} -> (y,x) under cap K equals the shortest route from swap(s_{n-L}) -> (x,y) (relator swap is a
# symmetry of the moves). acc_disk searches forward from swap(s_{n-L}) to depth L-1-9 and meets B36
# (every state within 9 moves of (x,y) under cap 36). First meeting layer a + smallest ball depth t is the
# exact shortest tail under cap min(K, 36) if a + t <= L - 1; no meet = certified: no tail of length <= L-1
# under that cap (any such path meets the ball at forward layer <= L-1-9). A shorter tail is spliced in,
# swapped back, and the full route is replayed with the official apply_move, then the Stable line
# route + [15, 15] goes through the official stable verifier.
# Usage: python3 tailwin.py ROW CAP LMIN LMAX 'ROUTE_JSON'
import json, os, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import charlie_run as cr
sys.path.insert(0, cr.SAIR)
from verifier import stable_core
from sac_yx import swap_move
BIN = cr.BIN; BALL = os.path.join(HERE, 'runs', 'B36'); UNION = os.path.join(BALL, 'union9.bin')
L = {1: 'x', -1: 'X', 2: 'y', -2: 'Y'}
def st(s): return ''.join(L[a] for a in s[0]) + ',' + ''.join(L[a] for a in s[1])

def main():
    cid, cap, lmin, lmax, route = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), json.loads(sys.argv[5])
    c, _ = cr.load_row(cid); S = [tuple(map(tuple, c['initial_relators']))]
    for m in route: S.append(cr.core.apply_move(S[-1], m))
    assert S[-1] == ((2,), (1,)), 'route does not end at (y,x)'
    n = len(route); out = []
    os.makedirs(os.path.join(HERE, 'runs', 'tail'), exist_ok=True)
    for Lt in range(max(lmin, 11), min(lmax, n) + 1):   # depth >= 1: acc_disk checks the meet set on generated layers only
        s = S[n - Lt]; sw = (s[1], s[0]); d = Lt - 1 - 9
        rdir = os.path.join(HERE, 'runs', 'tail', '%s_L%d' % (cid, Lt)); subprocess.run(['rm', '-rf', rdir])
        t0 = time.time()
        o = cr.run([BIN, 'bfs', rdir, st(sw), str(cap), '--mem', os.environ.get('MEM', '2500'), '--meet', UNION,
                    '--maxlayer', str(max(d, 0)), '--minfree', '3'])
        res = [l for l in o.splitlines() if l.startswith('RESULT')][-1]
        rec = {'row': cid, 'cap': cap, 'tail': Lt, 'from_index': n - Lt, 'forward_depth': d, 'result': res, 'secs': round(time.time() - t0, 1)}
        if 'MEET' in res or 'TARGET' in res:
            a = int(res.split('layer=')[1].split()[0]); La = os.path.join(rdir, 'L_%04d.bin' % a)
            for t in range(10):
                q = cr.run([BIN, 'intersect', La, os.path.join(BALL, 'L_%04d.bin' % t)])
                if not q.startswith('first'): continue
                key = q.split()[1]
                sw_tail = cr.moves_to(rdir, key) + [cr.INV[m] for m in reversed(cr.moves_to(BALL, key))]
                tail = [swap_move(m) for m in sw_tail]
                rec['new_tail'] = len(tail)
                if len(tail) < Lt:
                    new = route[:n - Lt] + tail; x = S[0]
                    for m in new: x = cr.core.apply_move(x, m)
                    M = json.load(open(os.path.join(cr.SAIR, 'verifier/data/manifest.json')))
                    sc = [z for z in M['challenges'] if z['challenge_id'] == 'sac-' + cid[3:]][0]
                    v = stable_core.verify(sc, new + [15, 15], 'sac-r8-v1', M['limits'])
                    rec.update(route=new, route_len=len(new), ends_yx=(x == ((2,), (1,))), sac_ok=v.get('ok'))
                    if v.get('ok'): rec['line'] = 'sac-%s: %s' % (cid[3:], json.dumps(new + [15, 15]))
                break
        elif 'MAXLAYER' in res or 'CLOSED' in res:
            rec['verdict'] = 'CERTIFIED: tail from index %d cannot be shortened below %d under cap %d' % (n - Lt, Lt, min(cap, 36))
        else:
            rec['verdict'] = 'INCOMPLETE'
        subprocess.run(['rm', '-rf', rdir])
        with open(os.path.join(HERE, 'runs', 'charlie_tailwin.jsonl'), 'a') as f: f.write(json.dumps(rec) + '\n')
        print(json.dumps({k: v for k, v in rec.items() if k != 'route'}), flush=True)
        if rec.get('line'): print(rec['line'], flush=True); break

if __name__ == '__main__':
    main()
