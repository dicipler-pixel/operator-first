# SCRIPT: CHARLIE_KERNEL_SWEEP -- exact capped two-sided search on relay rows 101-213 (targets_codex_oddeasyB.json)
# For each row and cap K (pass p: K = start + 2p), acc_disk runs an exact frontier BFS from the row under total
# relator length <= K, checking every new layer against B36 = all states within 9 moves of ((x),(y)) under cap 36.
#   MEET/TARGET at first layer a: path = start->meet (from the layers) + meet->trivial (inverse ball path),
#            with t = smallest ball depth among meeting states: a + t is the exact shortest length with peak <= K
#            (valid as an exact claim while K <= 36). The path is replayed by the official core before anything is written.
#   CLOSED:  the row's whole component under cap K was enumerated and never met B36, so ((x),(y)) is not in it:
#            certified, no AC path at all whose relator total stays <= K.
#   DISKFULL: incomplete; still certifies no path of length <= depth+9 with peak <= K.
# Usage: python3 kernel_sweep.py PASS_FROM PASS_TO [ROW_NUMBERS...]
import json, os, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__)); CH = os.path.dirname(HERE); sys.path.insert(0, CH)
import charlie_run as cr
BIN = cr.BIN; BALL = os.path.join(CH, 'runs', 'B36'); UNION = os.path.join(BALL, 'union9.bin')
LED = os.path.join(HERE, 'ledger', 'charlie_kernel_rows101-213.jsonl'); INB = os.path.join(HERE, 'inbox')
os.makedirs(os.path.dirname(LED), exist_ok=True); os.makedirs(INB, exist_ok=True)
WORK = os.path.join(CH, 'runs', 'kernel'); os.makedirs(WORK, exist_ok=True)

def done_state():
    st = {}
    if os.path.exists(LED):
        for l in open(LED):
            d = json.loads(l); r = st.setdefault(d['row'], {'solved': False, 'stopped': False, 'caps': set()})
            r['caps'].add(d['cap'])
            if d.get('line'): r['solved'] = True
            if d['status'] in ('INCOMPLETE', 'ENGINE FAILED'): r['stopped'] = True
    return st

def one(row, K):
    cid = row['id']; c, limits = cr.load_row(cid); start = cr.sstr(*c['initial_relators'])
    rdir = os.path.join(WORK, '%s_cap%d' % (cid, K)); subprocess.run(['rm', '-rf', rdir])
    t0 = time.time()
    out = cr.run([BIN, 'bfs', rdir, start, str(K), '--mem', os.environ.get('MEM', '3000'), '--meet', UNION, '--minfree', '4'])
    res = [l for l in out.splitlines() if l.startswith('RESULT')][-1]
    log = [l.split('\t') for l in open(os.path.join(rdir, 'LOG.tsv')) if l[0].isdigit()]
    depth = int(log[-1][0]) if log else 0
    if log and log[-1][1] == '0': depth -= 1
    states = int(res.split('states=')[1].split()[0])
    rec = {'row': cid, 'relay_row': row['n'], 'start_total': row['start'], 'cap': K, 'result': res, 'depth_done': depth,
           'states': states, 'secs': round(time.time() - t0, 1), 'engine': 'acc_disk two-sided vs B36 (radius 9, cap 36)',
           'by': 'charlie', 'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    if 'MEET' in res or 'TARGET' in res:
        a = int(res.split('layer=')[1].split()[0]); La = os.path.join(rdir, 'L_%04d.bin' % a)
        for t in range(10):
            o = cr.run([BIN, 'intersect', La, os.path.join(BALL, 'L_%04d.bin' % t)])
            if not o.startswith('first'): continue
            key = o.split()[1]
            path = cr.moves_to(rdir, key) + [cr.INV[m] for m in reversed(cr.moves_to(BALL, key))]
            v = cr.core.verify(c, path, 'ac-r2-v1', limits)
            rec.update(status='SOLVED' if v.get('ok') else 'VERIFY FAILED', length=len(path), forward_layer=a, ball_depth=t,
                       exact_shortest_under_cap=(K <= 36), path=path, verify=v)
            if v.get('ok'):
                rec['line'] = '%s: %s' % (cid, json.dumps(path))
                fn = os.path.join(INB, '%s_charlie_%s.txt' % (time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()), cid))
                open(fn, 'w').write(rec['line'] + '\n')
            break
    elif 'CLOSED' in res:
        rec.update(status='CERTIFIED', verdict='component under cap %d closed at %d states without meeting the trivial ball: no AC path with relator total <= %d' % (K, states, K))
    else:
        rec.update(status='INCOMPLETE', verdict='stopped (%s) at depth %d: no path of length <= %d with total <= %d' % (res.split()[1], depth, depth + 9, K))
    subprocess.run(['rm', '-rf', rdir])
    with open(LED, 'a') as f: f.write(json.dumps(rec) + '\n')
    print(cid, 'cap', K, rec['status'], rec.get('length', ''), 'states', states, '(%.0fs)' % rec['secs'], flush=True)
    if rec.get('line'): print(rec['line'], flush=True)

if __name__ == '__main__':
    p0, p1 = int(sys.argv[1]), int(sys.argv[2]); pick = set(map(int, sys.argv[3:]))
    rows = json.load(open(os.path.join(HERE, 'rows.json')))
    for p in range(p0, p1 + 1):
        for row in rows:
            if pick and row['n'] not in pick: continue
            st = done_state().get(row['id'], {'solved': False, 'stopped': False, 'caps': set()})
            K = row['start'] + 2 * p
            if st['solved'] or st['stopped'] or K in st['caps']: continue
            try:
                one(row, K)
            except SystemExit as e:
                subprocess.run('rm -rf %s/%s_cap%d' % (WORK, row['id'], K), shell=True)
                with open(LED, 'a') as f: f.write(json.dumps({'row': row['id'], 'cap': K, 'status': 'ENGINE FAILED', 'detail': str(e)[:300]}) + '\n')
                print(row['id'], 'ENGINE FAILED', str(e)[:200], flush=True)
        print('== pass', p, 'done', time.strftime('%H:%MZ', time.gmtime()), flush=True)
