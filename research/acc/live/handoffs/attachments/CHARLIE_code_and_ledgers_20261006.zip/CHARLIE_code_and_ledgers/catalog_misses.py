# SCRIPT: CHARLIE_CATALOG_MISSES -- every finished search with no shorter route, from Charlie's ledgers, deduped, with scope
import json, glob, os, re
import charlie_run as cr
start = {}
def st(row):
    if row not in start:
        c, _ = cr.load_row(row); start[row] = sum(len(r) for r in c['initial_relators'])
    return start[row]
exact, partial, incomplete = {}, {}, {}
for f in glob.glob('runs/*.jsonl'):
    if 'CONTROL' in f or 'pre_control' in f: continue
    for l in open(f):
        try: d = json.loads(l)
        except Exception: continue
        row = d.get('row', ''); v = d.get('verdict', ''); K = d.get('cap')
        if not row.startswith('ac-') or K is None or 'tail' in d: continue
        mode = 'yx' if ('yx' in f or 'route' in d.get('mode', '')) else 'AC'
        m = re.search(r'length <= (\d+)', v)
        states = d.get('states') or (int(re.search(r'states=(\d+)', d.get('result', '')).group(1)) if 'states=' in d.get('result', '') else None)
        if v.startswith('CERTIFIED') and m:
            L = int(m.group(1)); key = (row, mode, K)
            tgt = partial if K > 36 else exact
            if key not in tgt or tgt[key][0] < L: tgt[key] = (L, states, d.get('depth_done', ''), os.path.basename(f))
        elif 'CLOSED' in v:
            exact[(row, mode, K)] = ('ALL (component closed)', states, d.get('depth_done', ''), os.path.basename(f))
        elif v.startswith('PARTIAL') and m:
            partial[(row, mode, K)] = (int(m.group(1)), states, d.get('depth_done', ''), os.path.basename(f))
        elif 'INCOMPLETE' in v:
            dd = d.get('depth_done')
            if dd is not None:
                L = dd + 9; key = (row, mode, K)
                if key not in incomplete or incomplete[key][0] < L: incomplete[key] = (L, states, dd, os.path.basename(f))
# drop incompletes that a complete run at the same (row, mode, cap) superseded
for k in list(incomplete):
    if k in exact: del incomplete[k]
def dump(name, D):
    rows = []
    for (row, mode, K), (L, states, dd, src) in sorted(D.items()):
        rows.append({'row': row, 'finish': mode, 'start_total': st(row), 'cap': K, 'no_route_len_le': L, 'states': states, 'fwd_depth': dd, 'src': src})
    json.dump(rows, open('runs/CATALOG_%s.json' % name, 'w'))
    print('==', name, len(rows))
    for r in rows: print(r['row'], r['finish'], 'start', r['start_total'], 'cap', r['cap'], '<=', r['no_route_len_le'], 'states', r['states'], 'depth', r['fwd_depth'])
dump('exact', exact); dump('partial_above36', partial); dump('incomplete', incomplete)
