# SCRIPT: CHARLIE_HARVEST_ROADS -- collect every road in Charlie's ledgers and inbox, replay each through the official verifiers, dedupe
import json, glob, os, sys
sys.path.insert(0, '.')
import charlie_run as cr
sys.path.insert(0, cr.SAIR)
from verifier import stable_core
M = json.load(open(cr.SAIR + '/verifier/data/manifest.json'))
SC = {z['challenge_id']: z for z in M['challenges']}
FORBID = {'09839', '02257', '09311', '06403', '04718', '05378'}
cands = []
def add(rid, p, src):
    if isinstance(p, list) and p and all(isinstance(m, int) for m in p): cands.append((rid, tuple(p), src))
def parse_line(s, src):
    if s and ':' in s:
        rid, p = s.split(':', 1)
        try: add(rid.strip(), json.loads(p), src)
        except Exception: pass
for f in glob.glob('runs/*.jsonl'):
    for l in open(f):
        try: d = json.loads(l)
        except Exception: continue
        for k in ('line', 'sac_line', 'improved_line', 'sac_candidate'): parse_line(d.get(k), os.path.basename(f))
        row = d.get('row', '')
        if 'path' in d and row:
            p = d['path']
            if p[-2:] in ([16, 15], [15, 15]) and d.get('mode', '').startswith('route'): add('sac-' + row[3:], p, os.path.basename(f))
            else: add(row, p, os.path.basename(f))
        if 'route' in d and row and d.get('side') == 'AC' and d.get('ends') == 'x,y': add(row, d['route'], os.path.basename(f))
for f in glob.glob('runs/surgery_inbox/*.txt') + ['runs/STACK_charlie_for_lunch.txt']:
    for l in open(f): parse_line(l.strip(), 'inbox')
out = {}
for rid, p, src in cands:
    key = (rid, p)
    if key in out: continue
    p = list(p)
    if rid.startswith('ac-'):
        c, lim = cr.load_row(rid); ok = cr.core.verify(c, p, 'ac-r2-v1', lim).get('ok')
    else:
        ok = stable_core.verify(SC[rid], p, 'sac-r8-v1', M['limits']).get('ok')
    out[key] = (ok, src)
rows = sorted(out, key=lambda k: (k[0][4:], k[0], len(k[1])))
bad = [k for k in rows if not out[k][0]]
json.dump([{'id': k[0], 'len': len(k[1]), 'moves': list(k[1]), 'ok': out[k][0], 'src': out[k][1], 'forbidden': k[0][4:] in FORBID} for k in rows], open('runs/HARVEST_roads.json', 'w'))
print('candidates', len(cands), 'unique', len(rows), 'verifier-ok', len(rows) - len(bad), 'failed', len(bad))
for k in rows: print(k[0], len(k[1]), 'ok' if out[k][0] else 'FAIL', out[k][1], 'FORBIDDEN' if k[0][4:] in FORBID else '')
