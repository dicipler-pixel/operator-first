# SCRIPT: CHARLIE_RECOVER_V2 -- rebuild the start -> meet-state path after a lean run (older layers deleted)
# A lean run only proves that `key` lies at forward depth exactly a from `start` under cap K.
# Rebuild that segment by meeting in the middle: ball of radius b = a//2 around `key` (all layers kept),
# forward search from `start` to depth a - b (all layers kept) that meets the ball. Both halves are small.
# The first meeting layer f gives a path start -> m (f moves) and key -> m (<= b moves), total <= a;
# since key is at distance exactly a, the total is exactly a. The caller replays the full path through
# the official verifier, so any error here would be caught there.
import os, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import charlie_run as cr

def recover(start, key, a, K, tag):
    base = os.path.join(HERE, 'runs', 'recover', tag); subprocess.run(['rm', '-rf', base]); os.makedirs(base)
    b = int(os.environ.get('RECB', min(9, a // 2)))   # v2: radius of the ball around key (smaller when key's neighbourhood grows fast)
    kb = os.path.join(base, 'kball'); cr.run([cr.BIN, 'bfs', kb, key, str(K), '--notarget', '--maxlayer', str(b), '--mem', '1500'])
    cr.run([cr.BIN, 'union', kb, os.path.join(base, 'u.bin')])
    fw = os.path.join(base, 'fw')
    out = cr.run([cr.BIN, 'bfs', fw, start, str(K), '--notarget', '--meet', os.path.join(base, 'u.bin'), '--maxlayer', str(a - b), '--mem', '1500'])
    res = [l for l in out.splitlines() if l.startswith('RESULT')][-1]
    if 'MEET' not in res:
        raise SystemExit('recover failed: ' + res)
    f = int(res.split('layer=')[1].split()[0])
    La = os.path.join(fw, 'L_%04d.bin' % f)
    for t in range(b + 1):
        q = cr.run([cr.BIN, 'intersect', La, os.path.join(kb, 'L_%04d.bin' % t)])
        if q.startswith('first'):
            m = q.split()[1]
            path = cr.moves_to(fw, m) + [cr.INV[x] for x in reversed(cr.moves_to(kb, m))]
            subprocess.run(['rm', '-rf', base])
            return path
    raise SystemExit('recover: no intersection found')
