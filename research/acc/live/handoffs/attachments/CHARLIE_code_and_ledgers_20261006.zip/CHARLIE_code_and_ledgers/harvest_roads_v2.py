# SCRIPT: CHARLIE_HARVEST_ROADS_V2 -- v1 plus Stable-side surgery routes and the record each row had in Charlie's orders
import json, glob, os, sys
sys.path.insert(0, '.')
import charlie_run as cr
sys.path.insert(0, cr.SAIR)
from verifier import stable_core
M = json.load(open(cr.SAIR + '/verifier/data/manifest.json'))
SC = {z['challenge_id']: z for z in M['challenges']}
FORBID = {'09839', '02257', '09311', '06403', '04718', '05378'}
H = {(d['id'], tuple(d['moves'])): d for d in json.load(open('runs/HARVEST_roads.json'))}
rec = {}
def setrec(rid, v):
    if v is None: return
    v = int(v); rec[rid] = min(rec.get(rid, 999), v)
for f in glob.glob('runs/*.jsonl'):
    for l in open(f):
        try: d = json.loads(l)
        except Exception: continue
        row = d.get('row', '')
        if not row.startswith('ac-'): continue
        setrec(row, d.get('ac_record')); setrec('sac-' + row[3:], d.get('sac_record'))
        if d.get('side') == 'AC': setrec(row, d.get('target'))
        if d.get('side') == 'Stable': setrec('sac-' + row[3:], d.get('target'))
        if d.get('route') and d.get('side') in ('AC', 'Stable'):
            r = d['route']; sid = 'sac-' + row[3:]
            p = r + ([16, 15] if d.get('ends') == 'x,y' else [15, 15])
            if d['side'] == 'Stable' or True:
                key = (sid, tuple(p))
                if key not in H:
                    ok = stable_core.verify(SC[sid], p, 'sac-r8-v1', M['limits']).get('ok')
                    H[key] = {'id': sid, 'len': len(p), 'moves': p, 'ok': ok, 'src': os.path.basename(f) + ' (surgery route + finish)', 'forbidden': row[3:] in FORBID}
for f in glob.glob('*.json') + glob.glob('*.jsonl') + glob.glob('*.txt'):
    for l in open(f, errors='ignore'):
        l = l.strip()
        if l.startswith('{') and '"id"' in l:
            try: d = json.loads(l)
            except Exception: continue
            if 'id' in d: setrec(d['id'], d.get('ac_record')); setrec('sac-' + d['id'][3:], d.get('sac_record'))
for f in glob.glob('*.txt'):
    for l in open(f, errors='ignore'):
        p = l.split()
        if len(p) > 5 and p[0].startswith('ac-') and p[1] in ('AC', 'Stable') and p[4].isdigit():
            setrec(p[0] if p[1] == 'AC' else 'sac-' + p[0][3:], p[4])
for f in glob.glob('*.json'):
    try: J = json.load(open(f))
    except Exception: continue
    if isinstance(J, list):
        for d in J:
            if isinstance(d, dict) and 'id' in d: setrec(d['id'], d.get('ac_record')); setrec('sac-' + d['id'][3:], d.get('sac_record'))
rows = sorted(H.values(), key=lambda d: (d['id'][4:] if d['id'].startswith('sac') else d['id'][3:], d['id'], d['len']))
for d in rows:
    r = rec.get(d['id']); d['record_in_orders'] = r
    d['label'] = 'no record in my orders' if r is None else ('BEAT' if d['len'] < r else 'TIE' if d['len'] == r else '+%d' % (d['len'] - r))
json.dump(rows, open('runs/HARVEST_roads_v2.json', 'w'))
print('unique', len(rows), 'ok', sum(d['ok'] for d in rows))
for d in rows: print(d['id'], d['len'], 'ok' if d['ok'] else 'FAIL', d['label'], 'FORBIDDEN' if d['forbidden'] else '', d['src'])
