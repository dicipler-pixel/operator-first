# SCRIPT: CHARLIE_WINDOW -- exact window shortening of a verified path (AC moves, official kernel).
# For every window (i, j) of the path's state sequence s_0..s_n with 2 <= j - i <= W, compute the exact
# shortest connection s_i -> s_j under the total-length cap K by bidirectional BFS (radius a from s_i,
# radius b from s_j, a + b = j - i - 1, both in memory with the official apply_move). If it is shorter,
# splice it in and restart. The result is replayed by the official verifier against the row's target
# (AC: ((x),(y)); for a (y,x) route give --end yx and the check is that the path ends at ((y),(x))).
# A window reported "no shorter" is exact within the cap: the two balls cover every path of length < j - i.
# Usage: python3 window.py ROW_ID CAP W 'PATH_JSON' [--end yx]
import json, os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import charlie_run as cr
core = cr.core
INV = cr.INV

def ball(s, r, cap):
    """dict state -> (parent_state, move taking parent to state), BFS radius r under cap."""
    par = {s: None}; fr = [s]
    for _ in range(r):
        nf = []
        for u in fr:
            for m in range(14):
                t = core.apply_move(u, m)
                if len(t[0]) + len(t[1]) > cap or t in par: continue
                par[t] = (u, m); nf.append(t)
        fr = nf
        if not fr: break
    return par

def trace(par, s):
    moves = []
    while par[s] is not None:
        u, m = par[s]; moves.append(m); s = u
    return moves[::-1]          # moves from the ball's root to s

def shortest(si, sj, budget, cap):
    """shortest path si -> sj of length <= budget, or None"""
    a = (budget + 1) // 2; b = budget - a
    A = ball(si, a, cap); B = ball(sj, b, cap)
    best = None
    for s in (A if len(A) < len(B) else B):
        if s in A and s in B:
            p = trace(A, s) + [INV[m] for m in reversed(trace(B, s))]
            if best is None or len(p) < len(best): best = p
    return best

def states(s0, path):
    out = [s0]
    for m in path: out.append(core.apply_move(out[-1], m))
    return out

def shorten(s0, path, cap, W, log=print):
    changed = True
    while changed:
        changed = False
        S = states(s0, path)
        for w in range(2, W + 1):
            for i in range(0, len(path) - w + 1):
                j = i + w
                p = shortest(S[i], S[j], w - 1, cap)
                if p is not None and len(p) < w:
                    log('window %d..%d: %d moves -> %d' % (i, j, w, len(p)))
                    path = path[:i] + p + path[j:]; changed = True; break
            if changed: break
    return path

def main():
    cid, cap, W, path = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), json.loads(sys.argv[4])
    end = sys.argv[sys.argv.index('--end') + 1] if '--end' in sys.argv else 'xy'
    c, limits = cr.load_row(cid); s0 = tuple(map(tuple, c['initial_relators']))
    t0 = time.time(); new = shorten(s0, path, cap, W)
    fin = states(s0, new)[-1]
    target = ((1,), (2,)) if end == 'xy' else ((2,), (1,))
    ok = fin == target
    v = core.verify(c, new, 'ac-r2-v1', limits) if end == 'xy' else {'ok': ok, 'ends_at': 'y,x' if ok else str(fin)}
    print(json.dumps({'row': cid, 'cap': cap, 'W': W, 'before': len(path), 'after': len(new), 'ends_ok': ok, 'verify': v.get('ok'), 'secs': round(time.time() - t0, 1)}))
    print('%s: %s' % (cid, json.dumps(new)))

if __name__ == '__main__':
    main()
