# SCRIPT: CHARLIE_PASSES_V3 -- breadth-first cap passes over a row list, restart-safe
# For offset o = O0, O0+2, ..., O1: run every row still open at cap start+o (one cap per call), cheapest rows first.
# A row is closed once the ledger shows a tie at any cap, an INCOMPLETE, or a run over STOPST states.
# A (row, cap) already in the ledger is skipped, so after a machine restart the same command resumes where it stopped.
# mode ac: easy_exact.py rows ROW:REC:SACREC ; mode yx: easy_yx.py rows ROW:SACREC
# Usage: python3 passes.py MODE O0 O1 ROWSPEC ...
import json, os, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import charlie_run as cr
mode, o0, o1, specs = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4:]
LED = os.path.join(HERE, 'runs', 'charlie_easy_exact.jsonl' if mode == 'ac' else 'charlie_easy_yx.jsonl')
OTHER = os.path.join(HERE, 'runs', 'charlie_easy_yx.jsonl' if mode == 'ac' else 'charlie_easy_exact.jsonl')
TOOL = 'easy_exact_v2.py' if mode == 'ac' else 'easy_yx_v2.py'
STOP = int(os.environ.get('STOPST', '300000000'))
def ledger():
    done, closed = set(), set()
    if os.path.exists(LED):
        for l in open(LED):
            try: d = json.loads(l)
            except Exception: continue
            r, K = d.get('row'), d.get('cap'); done.add((r, K)); v = d.get('verdict', '')
            if d.get('line') or d.get('sac_line') or 'INCOMPLETE' in v or d.get('states', 0) > STOP or 'ENGINE' in v: closed.add(r)
    # v2: the relator swap is a symmetry of the moves, so the swapped component under a cap has the same size
    # (checked: ac-00259 cap 32 and ac-08945 cap 32 gave identical state counts on both finishes).
    # A run that filled the disk in the other mode fills it here too, so that row is closed for this mode as well.
    if os.path.exists(OTHER):
        for l in open(OTHER):
            try: d = json.loads(l)
            except Exception: continue
            if 'INCOMPLETE' in d.get('verdict', '') or 'ENGINE' in d.get('verdict', ''): closed.add(d.get('row'))
    return done, closed
start = {}
for s in specs:
    cid = s.split(':')[0]; c, _ = cr.load_row(cid); start[cid] = sum(len(r) for r in c['initial_relators'])
for o in range(o0, o1 + 1, 2):
    for s in sorted(specs, key=lambda x: start[x.split(':')[0]]):
        cid = s.split(':')[0]; K = start[cid] + o
        done, closed = ledger()
        if cid in closed or (cid, K) in done: continue
        base = ':'.join(s.split(':')[:3 if mode == 'ac' else 2])
        env = dict(os.environ, TO=str(o), MEM=os.environ.get('MEM', '2500'))
        arg = base + ((':' if mode == 'ac' and base.count(':') == 2 else ':') + str(o))
        subprocess.run(['python3', os.path.join(HERE, TOOL), arg], env=env)
    print('== pass offset %d done' % o, flush=True)
