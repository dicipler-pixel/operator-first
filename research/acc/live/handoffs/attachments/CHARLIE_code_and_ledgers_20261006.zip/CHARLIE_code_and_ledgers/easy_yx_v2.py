# SCRIPT: CHARLIE_EASY_YX_V2 -- exact capped search for a route to ((y),(x)), Stable line = route + [15, 15]
# Swapping the two relators is a symmetry of the ac-r2-v1 moves (0<->1, 2<->4, 3<->5, 6..9<->10..13) that sends
# ((y),(x)) to ((x),(y)). So: forward frontier BFS from the SWAPPED row under cap K (acc_disk), every new layer checked
# against B36 (all states within 9 moves of ((x),(y)) under cap 36), to depth max(R - 9, 1) with R = SAC record - 2.
#   MEET at first layer a, smallest ball depth t: a + t = exact shortest route to (y,x) under cap K (K <= 36).
#   Route is swapped back move by move, [15, 15] appended, and the Stable line is checked by the official sac-r8-v1 verifier.
#   MAXLAYER: certified, no route to (y,x) of length <= R under cap K.  CLOSED: none at all under cap K.
# Usage: FROM=4 TO=16 python3 easy_yx.py ROW:SACRECORD ...   (caps start+FROM .. start+TO step 2)
import json, os, shutil, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import charlie_run as cr
sys.path.insert(0, cr.SAIR)
from verifier import stable_core
from sac_yx import swap_move
BIN = cr.BIN; BALL = os.path.join(HERE, 'runs', 'B36'); UNION = os.path.join(BALL, 'union9.bin')
WORK = os.path.join(HERE, 'runs', 'easyyx'); os.makedirs(WORK, exist_ok=True)
OUT = os.path.join(HERE, 'runs', 'charlie_easy_yx.jsonl'); INB = os.path.join(HERE, 'runs', 'surgery_inbox')
MANI = json.load(open(os.path.join(cr.SAIR, 'verifier/data/manifest.json')))

def one(cid, SR, K):
    waited = 0
    while shutil.disk_usage(HERE).free / 1e9 < 8 and waited < 3600: time.sleep(30); waited += 30
    R = SR - 2
    c, _ = cr.load_row(cid); r0, r1 = c['initial_relators']; start_sw = cr.sstr(r1, r0)
    rdir = os.path.join(WORK, '%s_cap%d' % (cid, K)); subprocess.run(['rm', '-rf', rdir]); t0 = time.time()
    out = cr.run([BIN, 'bfs', rdir, start_sw, str(K), '--mem', os.environ.get('MEM', '2500'), '--meet', UNION,
                  '--maxlayer', str(max(R - 9, 1)), '--minfree', '4'] + (['--lean'] if os.environ.get('LEAN') == '1' else []) + (['--safety', os.environ['SAFETY']] if os.environ.get('SAFETY') else []))
    res = [l for l in out.splitlines() if l.startswith('RESULT')][-1]
    log = [l.split('\t') for l in open(os.path.join(rdir, 'LOG.tsv')) if l[0].isdigit()]
    depth = int(log[-1][0]) if log else 0
    if log and log[-1][1] == '0': depth -= 1
    states = int(res.split('states=')[1].split()[0])
    rec = {'row': cid, 'mode': 'route to (y,x)', 'sac_record': SR, 'route_needed': R, 'cap': K, 'result': res, 'depth_done': depth, 'states': states, 'by': 'charlie'}
    if 'MEET' in res or 'TARGET' in res:
        a = int(res.split('layer=')[1].split()[0]); La = os.path.join(rdir, 'L_%04d.bin' % a)
        for t in range(10):
            q = cr.run([BIN, 'intersect', La, os.path.join(BALL, 'L_%04d.bin' % t)])
            if not q.startswith('first'): continue
            key = q.split()[1]
            if os.environ.get('LEAN') == '1':
                # v2: free the main run's disk before rebuilding the path; only the key and layer a are needed
                open(os.path.join(HERE, 'runs', 'meetkeys.txt'), 'a').write('%s yx cap %d layer %d t %d key %s\n' % (cid, K, a, t, key))
                subprocess.run(['rm', '-rf', rdir])
            sw = (__import__('recover_v2').recover(start_sw, key, a, K, cid) if os.environ.get('LEAN') == '1' else cr.moves_to(rdir, key)) + [cr.INV[m] for m in reversed(cr.moves_to(BALL, key))]
            route = [swap_move(m) for m in sw]
            sid = 'sac-' + cid[3:]; sc = [z for z in MANI['challenges'] if z['challenge_id'] == sid][0]
            sp = route + [15, 15]; ok = stable_core.verify(sc, sp, 'sac-r8-v1', MANI['limits']).get('ok')
            rec.update(route_len=len(route), sac_len=len(sp), sac_ok=ok, path=sp,
                       verdict='BEAT' if len(sp) < SR else 'TIE' if len(sp) == SR else 'LONGER')
            if ok and len(sp) <= SR:
                rec['sac_line'] = '%s: %s' % (sid, json.dumps(sp))
                open(os.path.join(INB, '%s_charlie_%s_yx.txt' % (time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()), sid)), 'w').write(rec['sac_line'] + '\n')
            break
    elif 'CLOSED' in res:
        rec['verdict'] = 'CERTIFIED: swapped component under cap %d closed, no route to (y,x) at all' % K
    elif 'MAXLAYER' in res:
        rec['verdict'] = 'CERTIFIED: no route to (y,x) of length <= %d under cap %d' % (R, K)
        if K > 36: rec['verdict'] = 'PARTIAL (end ball built under cap 36): ' + rec['verdict'][11:] + ' among paths whose last 9 moves stay at total <= 36'
    else:
        rec['verdict'] = 'INCOMPLETE: depth %d; no route to (y,x) of length <= %d under cap %d' % (depth, depth + 9, K)
    rec['secs'] = round(time.time() - t0, 1)
    subprocess.run(['rm', '-rf', rdir])
    with open(OUT, 'a') as f: f.write(json.dumps(rec) + '\n')
    print(cid, 'yx cap', K, rec.get('verdict'), rec.get('sac_len', ''), 'states', states, '(%.0fs)' % rec['secs'], flush=True)
    if rec.get('sac_line'): print(rec['sac_line'], flush=True)
    return rec

if __name__ == '__main__':
    for arg in sys.argv[1:]:
        p = arg.split(':'); cid, SR = p[0], int(p[1]); fr = int(p[2]) if len(p) > 2 else int(os.environ.get('FROM', '4'))
        c, _ = cr.load_row(cid); s = sum(len(r) for r in c['initial_relators'])
        for K in range(s + fr, s + int(os.environ.get('TO', '16')) + 1, 2):
            try:
                rec = one(cid, SR, K)
                if rec.get('sac_line') or 'INCOMPLETE' in rec.get('verdict', '') or rec['states'] > int(os.environ.get('STOPST', '300000000')):
                    break
            except SystemExit as e:
                subprocess.run('rm -rf %s/%s_cap%d' % (WORK, cid, K), shell=True)
                print(cid, K, 'ENGINE FAILED', str(e)[:200], flush=True); break
