# SCRIPT: KERNEL-COMB-01  MS(n,w) comb from ac.jsonl + team pool. A row is MS(n,w) if, after a signed generator swap
#   (8 maps) and relator swap, one relator is a rotation (or inverse rotation) of X y^n x y^-(n+1) and the other is a
#   rotation of x w^-1 (or its inverse). wkey = lexicographic min over every valid (map, rotation) choice, so two rows
#   with the same w get the same key whatever n is. Control: the training MS rows must come back with their own n and
#   one key per training w.
import sys,json,re,collections; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from load import pool
def red(w):
    o=[]
    for c in w:
        if o and o[-1]==-c: o.pop()
        else: o.append(c)
    while len(o)>1 and o[0]==-o[-1]: o=o[1:-1]
    return o
def inv(w): return [-c for c in reversed(w)]
def rots(w): return [w[i:]+w[:i] for i in range(len(w))]
MAPS=[]
for sw in (0,1):
    for sx in (1,-1):
        for sy in (1,-1):
            def f(w,sw=sw,sx=sx,sy=sy):
                o=[]
                for c in w:
                    g=abs(c); s=1 if c>0 else -1
                    if sw: g=3-g
                    o.append(s*(sx if g==1 else sy)*g)
                return o
            MAPS.append(f)
def pump_n(r):
    L=len(r)
    if L<5 or (L-3)%2: return None
    n=(L-3)//2
    P=[-1]+[2]*n+[1]+[-2]*(n+1)
    for v in (r,inv(r)):
        if any(x==P for x in rots(v)): return n
    return None
def classify(r0,r1):
    best=None
    for f in MAPS:
        a,b=red(f(r0)),red(f(r1))
        for p,q in ((a,b),(b,a)):
            n=pump_n(p)
            if n is None: continue
            for v in (q,inv(q)):
                for x in rots(v):
                    if x and x[0]==1:
                        w=tuple(inv(x[1:]))
                        if best is None or (w,n)<best[::-1]: best=(n,w)
    return best
if __name__=='__main__':
    T=json.load(open('../acc/competition/examples/training_424.json'))['instances']
    ok=bad=0; keys=collections.defaultdict(set)
    for t in T:
        if t['family']!='miller-schupp': continue
        c=classify(*t['initial_relators'])
        if c and c[0]==t['n']: ok+=1; keys[tuple(t['w_vector'])].add(c[1])
        else: bad+=1
    print('CONTROL training MS rows: n recovered',ok,'missed',bad,'| training w with >1 key:',sum(len(v)>1 for v in keys.values()),'of',len(keys))
    P=pool()
    held={}
    for l in open('teampool.txt'):
        m=re.match(r'(ac-\d+): \[(.*?)\]',l); held[m.group(1)]=len(m.group(2).split(','))
    cls={cid:classify(r0,r1) for cid,(r0,r1) in P.items()}
    ms={c:v for c,v in cls.items() if v}
    print('pool rows',len(P),'MS rows',len(ms),'held MS rows',sum(c in held for c in ms))
    byw=collections.defaultdict(dict)
    for c,(n,w) in ms.items(): byw[w].setdefault(n,[]).append(c)
    comb=[]
    for w,d in byw.items():
        for n,ids in d.items():
            for c in ids:
                if c in held: continue
                for dn in (-1,1):
                    for c2 in d.get(n+dn,[]):
                        if c2 in held: comb.append((c,n,c2,n+dn,held[c2],len(w),list(w)))
    comb.sort(key=lambda x:(x[4],x[1]))
    json.dump(comb,open('comb.json','w'))
    unheld=set(x[0] for x in comb)
    print('comb pairs',len(comb),'unheld rows with a held neighbour',len(unheld),'| n-1 held:',len(set(x[0] for x in comb if x[3]==x[1]-1)))
    for x in comb[:15]: print(x[:6])
    for want in ('ac-02842','ac-01083','ac-09310'):
        print(want, cls.get(want), [x[2:5] for x in comb if x[0]==want])
