# SCRIPT: KERNEL-CROSSGRAPH-01
import sys,glob,re,json,time
sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from load import pool
P=pool(); GOAL=((1,),(2,))
cid=sys.argv[1]; R=int(sys.argv[2]); CAP=int(sys.argv[3]) if len(sys.argv)>3 else 6000000
start=(tuple(P[cid][0]),tuple(P[cid][1]))
pat=re.compile(r'^'+cid+r': \[([0-9, ]+)\]')
roads=set()
for f in glob.glob('*.txt')+glob.glob('hub/*.txt'):
    for line in open(f,errors='ignore'):
        m=pat.match(line.strip())
        if m: roads.add(tuple(int(v) for v in m.group(1).split(',')))
nodes=set(); good=[]
for mv in roads:
    st=start; seq=[st]
    for m in mv: st=core.apply_move(st,m); seq.append(st)
    if st==GOAL: good.append(mv); nodes.update(seq)
print(cid,'roads verified',len(good),'of',len(roads),'lengths',sorted(len(g) for g in good)[:12],'nodes',len(nodes),flush=True)
t0=time.time()
tube=set(nodes); front=set(nodes)
for d in range(R):
    nf=set()
    for s in front:
        for m in range(14):
            t=core.apply_move(s,m)
            if t not in tube: nf.add(t)
    tube|=nf; front=nf
    print(' radius',d+1,'tube',len(tube),f'{time.time()-t0:.0f}s',flush=True)
    if len(tube)>CAP: print(' CAP hit, stopping at radius',d+1); break
par={start:None}; fr=[start]; depth=0
while fr and GOAL not in par:
    nx=[]
    for s in fr:
        for m in range(14):
            t=core.apply_move(s,m)
            if t in tube and t not in par: par[t]=(s,m); nx.append(t)
    fr=nx; depth+=1
path=[]; s=GOAL
while par[s] is not None: s,m=par[s]; path.append(m)
path.reverse()
st=start
for m in path: st=core.apply_move(st,m)
best=min(len(g) for g in good)
print(cid,'TUBE-R',R,'shortest',len(path),'(best road',best,')','replay_ok',st==GOAL,f'{time.time()-t0:.0f}s',flush=True)
print(f'LINE {cid}: {path}',flush=True)
