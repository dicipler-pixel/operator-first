# SCRIPT: KERNEL-LADDER-01  ladder h=4,8,12 (total cap start+h), length ranking, W=2000, D=300, on rows 101-213
import json,sys,time,re; sys.path.insert(0,'.')
import drive2 as D
from load import relay
from concurrent.futures import ThreadPoolExecutor
items=[(cid,r[0],r[1],n) for n,cid,r in relay()]
allres=[]
for h in (4,8,12):
    t0=time.time()
    def one(it):
        cid,a,b,n=it; o=D.run_one((cid,a,b,2000,300,len(a)+len(b)+h,0,1)); o['row']=n; o['h']=h; o['start']=len(a)+len(b); return o
    with ThreadPoolExecutor(2) as ex: out=list(ex.map(one,items))
    sol=[o for o in out if o['moves']]
    newlow=sum(1 for o in out if int(re.search(r'best (\d+)',o['out']).group(1))<o['start'])
    print(f"h={h}: solved {len(sol)}/113 (official ok {sum(o['official_ok'] for o in sol)}), rows with a new low {newlow}, {time.time()-t0:.0f}s", [(o['id'],len(o['moves'])) for o in sol], flush=True)
    allres+=out
json.dump(allres,open('ladder_ours_results.json','w'))
