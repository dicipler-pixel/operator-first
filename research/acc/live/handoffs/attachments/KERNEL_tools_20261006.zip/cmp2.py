# SCRIPT: KERNEL-CMP-02  old kbeam2 vs hash-fixed kbeam2b, same args, Bob rows + part B rows
import sys,subprocess,json,re; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from load import pool
S={1:'x',-1:'X',2:'y',-2:'Y'}; P=pool(); REC=json.load(open('rec_bob.json'))
def run(b,cid,W,H,seed):
    r0,r1=P[cid]; o=subprocess.run([b,str(W),str(REC[cid]+40),'60',str(H),str(seed),''.join(S[c] for c in r0),''.join(S[c] for c in r1)],capture_output=True,text=True).stdout
    m=re.search(r'SOLVED depth (\d+) : \[(.*)\]',o)
    if not m: return None
    mv=[int(x) for x in m.group(2).split(',')]; st=(tuple(r0),tuple(r1))
    for x in mv: st=core.apply_move(st,x)
    return (len(mv),mv) if st==((1,),(2,)) else ('FAIL',mv)
out={}
for cid in REC:
    for W in (2000,8000):
        for H in (0,1):
            a=run('./kbeam2',cid,W,H,1); b=run('./kbeam2b',cid,W,H,1)
            print(cid,W,H,'old',a and a[0],'fixed',b and b[0],flush=True)
            if b and b[0]!='FAIL': out.setdefault(cid,[]).append(b[1])
json.dump(out,open('cmp2.json','w'))
