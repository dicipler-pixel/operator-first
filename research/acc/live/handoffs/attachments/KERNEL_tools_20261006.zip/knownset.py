# SCRIPT: KERNEL-KNOWNSET-01  canonical keys of every state on every known solved path (training 424 + verified cross paths)
import sys,json,re; sys.path.insert(0,'.')
sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from classes import key
from load import pool
def khash(k):
    # FNV-1a 64 over: relator0 letters (c+3) , 0 , relator1 letters , 0
    h=1469598103934665603
    for w in k:
        for c in w: h^=(c+3); h=(h*1099511628211)&0xFFFFFFFFFFFFFFFF
        h^=0; h=(h*1099511628211)&0xFFFFFFFFFFFFFFFF
    return h or 1
def paths():
    T=json.load(open('../acc/competition/examples/training_424.json'))['instances']
    for t in T: yield t['training_id'], t['initial_relators'][0], t['initial_relators'][1], t['moves']
    P=pool()
    for line in open('hub/cross.txt'):
        m=re.match(r'(ac-\d+): \[(.*)\]',line)
        if m: cid=m.group(1); yield cid, P[cid][0], P[cid][1], [int(v) for v in m.group(2).split(',')]
if __name__=='__main__':
    table={}
    for pid,r0,r1,mv in paths():
        st=(tuple(r0),tuple(r1))
        for i in range(len(mv)+1):
            if len(st[0])+len(st[1])>2:
                h=khash(key(list(st[0]),list(st[1])))
                if h not in table or table[h][2]>len(mv)-i: table[h]=(pid,i,len(mv)-i)
            if i<len(mv): st=core.apply_move(st,mv[i])
    json.dump({str(h):v for h,v in table.items()},open('known_table.json','w'))
    open('known_hashes.txt','w').write("\n".join(str(h) for h in table)+"\n")
    print("known solvable canonical states:",len(table))
