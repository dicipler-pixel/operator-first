# SCRIPT: KERNEL-SHJOIN-01  shorten joined roads (exact radius 4), replay, dedupe, keep <= record+40
import sys,json,re; sys.argv=['x']; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from shortcut import shorten
from verifier import core
from load import pool
P=pool(); REC=json.load(open('rec_bob.json')); out=[]
d=json.load(open('join_ac-09464.json'))
for cid,dd in d.items():
    keep=set()
    for k,tag in dd.items():
        r=list(map(int,k.split()))
        if len(r)>REC[cid]+40: continue
        st0=(tuple(P[cid][0]),tuple(P[cid][1])); s=shorten(st0,r); st=st0
        for x in s: st=core.apply_move(st,x)
        if st==((1,),(2,)): keep.add(tuple(s))
    for s in sorted(keep,key=len): out.append(f"{cid}: {list(s)}")
    print(cid,sorted(len(s) for s in keep),flush=True)
open('batch9.txt','w').write('\n'.join(out)+'\n')
