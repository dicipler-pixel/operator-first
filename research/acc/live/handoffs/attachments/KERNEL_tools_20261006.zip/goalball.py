# SCRIPT: KERNEL-GOALBALL-01  "the echo from the back": opposite of starting near roads.
#   Exact BFS ball of radius R around the goal ((1,),(2,)); kbeam5 runs forward from the official start and
#   records the best (depth + exact distance) over every state it touches inside the ball. The suffix is the
#   exact BFS path back to the goal. Every route is replayed on verifier.core before it is kept.
import sys,subprocess,json,time,re; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from load import pool
from hsh2 import hs
INV={0:0,1:1,2:3,3:2,4:5,5:4,6:7,7:6,8:9,9:8,10:11,11:10,12:13,13:12}
GOAL=((1,),(2,)); S={1:'x',-1:'X',2:'y',-2:'Y'}
R=int(sys.argv[2]) if len(sys.argv)>2 else 7
t=time.time(); B={GOAL:(0,None)}; fr=[GOAL]
for d in range(1,R+1):
    nx=[]
    for u in fr:
        for m in range(14):
            v=core.apply_move(u,m)
            if v not in B: B[v]=(d,m); nx.append(v)
    fr=nx
with open(f'goal2_R{R}.txt','w') as f:
    for v,(d,_) in B.items(): f.write(f"{hs(v)} {d}\n")
print('ball',R,len(B),round(time.time()-t),'s',flush=True)
def suffix(v):
    out=[]
    while v!=GOAL:
        d,m=B[v]; im=INV[m]; out.append(im); v=core.apply_move(v,im)
    return out
P=pool(); REC=json.load(open('rec_bob.json'))
res={}
for cid in sys.argv[1].split(','):
    r0,r1=P[cid]; st0=(tuple(r0),tuple(r1)); rec=REC.get(cid,60); routes=set()
    for W in (2000,8000):
        for H in (0,1,2):
            for seed in (1,2):
                o=subprocess.run(['./kbeam5',str(W),str(rec+20),'60',str(H),str(seed),''.join(S[c] for c in r0),''.join(S[c] for c in r1),str(rec+12)],
                                 capture_output=True,text=True,env={'GOALFILE':f'goal2_R{R}.txt'}).stdout.strip()
                m=re.match(r'GOALTOUCH total (\d+) prefix (\d+) dist (\d+) : \[(.*)\]',o)
                if not m: print(cid,W,H,seed,o[:60],flush=True); continue
                pre=[int(x) for x in m.group(4).split(',')]
                st=st0
                for x in pre: st=core.apply_move(st,x)
                if st not in B: print(cid,'hash collision, skipped',flush=True); continue
                mv=pre+suffix(st); chk=st0
                for x in mv: chk=core.apply_move(chk,x)
                print(cid,W,H,seed,'len',len(mv),'(prefix',len(pre),'+ exact',len(mv)-len(pre),') ok' if chk==GOAL else 'FAIL','record',rec,flush=True)
                if chk==GOAL: routes.add(tuple(mv))
    res[cid]=sorted([list(x) for x in routes],key=len)
    json.dump(res,open(f"goalball_{sys.argv[1].split(',')[0]}_R{R}.json",'w'))
