# SCRIPT: KERNEL-WSTAR-BEAM-01  own beam on the 92 MS_n(w*) pool rows; path length vs n (records double per n)
import sys,json,re,time,collections; sys.path.insert(0,'.')
import drive2 as D
from load import pool
from concurrent.futures import ThreadPoolExecutor
P=pool()
from wstar_ids import IDS
rows=[(c,n,P[c]) for c,n in IDS]
W=int(sys.argv[1]); t0=time.time()
def one(x):
    cid,n,r=x; o=D.run_one((cid,r[0],r[1],W,1500,len(r[0])+len(r[1])+60,0,1)); o['n']=n; return o
with ThreadPoolExecutor(2) as ex: out=list(ex.map(one,rows))
by=collections.defaultdict(list)
for o in out: by[o['n']].append(len(o['moves']) if o['moves'] else None)
for n in sorted(by): print(f"n={n}: solved {sum(v is not None for v in by[n])}/{len(by[n])}, lengths {sorted(v for v in by[n] if v)}")
print(f"W={W}, {time.time()-t0:.0f}s; official ok on all found: {all(o['official_ok'] for o in out if o['moves'])}")
json.dump(out,open(f'wstar_beam_W{W}.json','w'))
