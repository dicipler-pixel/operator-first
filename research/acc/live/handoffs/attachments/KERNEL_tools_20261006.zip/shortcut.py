# SCRIPT: KERNEL-SHORTCUT-01  exact local shortening: for states S_i, S_j on a path, join them in < j-i moves
#   using radius-R balls (forward from S_i, backward from S_j; moves are invertible). Repeat until no gain. Official replay.
import sys,re,json,time; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from load import pool
INV={0:0,1:1,2:3,3:2,4:5,5:4,6:7,7:6,8:9,9:8,10:11,11:10,12:13,13:12}
MAXSPAN=30
R=int(sys.argv[1]) if len(sys.argv)>1 and sys.argv[1].isdigit() else 4
def ball(s,r):
    D={s:(0,None,None)}; fr=[s]
    for d in range(1,r+1):
        nx=[]
        for u in fr:
            for m in range(14):
                t=core.apply_move(u,m)
                if t not in D: D[t]=(d,u,m); nx.append(t)
        fr=nx
    return D
def trace(D,u):          # moves from ball centre to u
    p=[]
    while D[u][1] is not None: p.append(D[u][2]); u=D[u][1]
    return p[::-1]
def improve(start,path):
    S=[start]
    for m in path: S.append(core.apply_move(S[-1],m))
    balls=[ball(s,R) for s in S]
    best=None
    for i in range(len(S)):
        for j in range(min(len(S)-1,i+MAXSPAN),i+1,-1):
            if j-i<=1: continue
            A,B=balls[i],balls[j]
            small,big=(A,B) if len(A)<=len(B) else (B,A)
            for u,(d1,_,_) in small.items():
                v=big.get(u)
                if v is None: continue
                tot=d1+v[0]
                if tot<j-i:
                    gain=j-i-tot
                    if best is None or gain>best[0]:
                        da=trace(A,u); db=trace(B,u)     # S_i->u , S_j->u
                        mid=da+[INV[m] for m in reversed(db)]
                        best=(gain,i,j,mid)
    if not best: return None
    g,i,j,mid=best
    return path[:i]+mid+path[j:]
def shorten(start,path):
    cur=list(path)
    while True:
        nw=improve(start,cur)
        if nw is None or len(nw)>=len(cur): return cur
        st=start
        for m in nw: st=core.apply_move(st,m)
        assert st==((1,),(2,)), "replay failed"
        cur=nw
if __name__=='__main__':
    P=pool(); items=[]
    for line in open(sys.argv[2]):
        m=re.match(r'(ac-\d+): \[(.*?)\](.*)',line)
        if m: items.append((m.group(1),[int(v) for v in m.group(2).split(',')],m.group(3).strip()))
    lo,hi=int(sys.argv[3]),int(sys.argv[4])
    for cid,mv,note in items[lo:hi]:
        t0=time.time(); st=(tuple(P[cid][0]),tuple(P[cid][1]))
        chk=st
        for m in mv: chk=core.apply_move(chk,m)
        if chk!=((1,),(2,)): print(cid,"INPUT PATH DOES NOT VERIFY",flush=True); continue
        new=shorten(st,mv)
        print(f"{cid} {len(mv)} -> {len(new)} {note} ({time.time()-t0:.0f}s)" + (f"  NEW: {cid}: {new}" if len(new)<len(mv) else ""),flush=True)
