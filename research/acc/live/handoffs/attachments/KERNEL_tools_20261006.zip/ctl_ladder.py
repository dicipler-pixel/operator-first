# SCRIPT: KERNEL-LADDER-CONTROL-01  ladder (total cap start+h) vs uncapped, on 44 verified climbing pool rows
import json,sys,time; sys.path.insert(0,'.')
import drive2 as D
from load import pool
P=pool(); rows=json.load(open('control_cross_rows.json'))
res=[]
for h in (None,4,8,12):
    for H in (0,1):
        t0=time.time()
        items=[(cid,P[cid][0],P[cid][1]) for cid,_,_,_ in rows]
        out=[]
        from concurrent.futures import ThreadPoolExecutor
        def one(it):
            cid,a,b=it; L=len(a)+len(b); cap= L+h if h else L+60
            return D.run_one((cid,a,b,2000,300,cap,H,1))
        with ThreadPoolExecutor(2) as ex: out=list(ex.map(one,items))
        sol=[o for o in out if o['moves']]; bad=[o for o in sol if not o['official_ok']]
        print(f"h={h} H={H}: solved {len(sol)}/44 (official rejects {len(bad)}) in {time.time()-t0:.0f}s ->", sorted(o['id'] for o in sol)[:12], flush=True)
        res.append(dict(h=h,H=H,out=out))
json.dump(res,open('control_ladder_results.json','w'))
