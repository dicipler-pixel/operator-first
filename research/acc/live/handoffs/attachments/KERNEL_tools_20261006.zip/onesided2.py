# SCRIPT: KERNEL-ONESIDED-01  exact shortest ONE-SIDED distance (r1 fixed, only r0 moves 0,2,3,6,7,8,9) from MS_n(w*) r0 to the cyclic class of a b^-1 a^-3
import sys,collections,time; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from msid import ms
def cls(w):
    w=list(w)
    while len(w)>1 and w[0]==-w[-1]: w=w[1:-1]
    iv=[-c for c in reversed(w)]
    return min(tuple(v[i:]+v[:i]) for v in (w,iv) for i in range(max(1,len(v))))
TGT=cls([1,-2,-1,-1,-1])
MOVES=(0,2,3,6,7,8,9)
def bfs(n,cap,limit=8_000_000):
    r0,r1=ms(n,[-2,1,2,-1]); r0=tuple(r0); r1=tuple(r1)
    seen={r0}; fr=[r0]; d=0; t0=time.time()
    while fr:
        d+=1; nx=[]
        for w in fr:
            for m in MOVES:
                t=core.apply_move((w,r1),m)[0]
                if len(t)>cap or t in seen: continue
                if cls(t)==TGT: return d,len(seen),time.time()-t0
                seen.add(t); nx.append(t)
        fr=nx
        if len(seen)>limit: return None,len(seen),time.time()-t0
    return 'closed',len(seen),time.time()-t0
for n in (3,):
    for cap in (16,18):
        r=bfs(n,cap); print(f"n={n} cap={cap}: one-sided distance {r[0]}  (states {r[1]}, {r[2]:.0f}s)",flush=True)

