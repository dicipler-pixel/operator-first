# SCRIPT: KERNEL-LEVELSTEP-01  meet-in-the-middle search for the Conjecture-2 level step P_m -> P_(m-1) in official moves (a=x, b=y)
import sys, collections; sys.path.insert(0,'../acc/competition/tools')
from verifier import core
X,x_,Y,y_=-1,1,-2,2
def red(w):
    o=[]
    for c in w:
        if o and o[-1]==-c: o.pop()
        else: o.append(c)
    return tuple(o)
W1=red([-1,-2,1,2,-1])      # a^-1 b^-1 a b a^-1
W2=red([1,-2,-1,2,1])       # a b^-1 a^-1 b a
def P(m,w): return (red([-2]*m+[-1]*4+[2,1]), w)
INV={0:0,1:1,2:3,3:2,4:5,5:4,6:7,7:6,8:9,9:8,10:11,11:10,12:13,13:12}
def expand(frontier_map, cap):
    new={}
    for s in frontier_map:
        for m in range(14):
            t=core.apply_move(s,m)
            if len(t[0])+len(t[1])>cap: continue
            yield s,m,t
def mitm(start, targets, cap, maxd=14, limit=3_000_000):
    F={start:None}; B={t:None for t in targets}; fr=[start]; br=list(targets)
    for d in range(maxd):
        grow_f = len(fr)<=len(br)
        src,dst,front = (F,B,fr) if grow_f else (B,F,br)
        nxt=[]
        for s in front:
            for m in range(14):
                t=core.apply_move(s,m)
                if len(t[0])+len(t[1])>cap or t in src: continue
                src[t]=(s,m); nxt.append(t)
                if t in dst:
                    # rebuild path start->t->target
                    def back(M,u):
                        p=[]
                        while M[u] is not None: u,mm=M[u]; p.append(mm)
                        return p
                    pf=back(F,t)[::-1]; pb=back(B,t)            # pb: moves applied from target side, reversed & inverted
                    return pf+[INV[mm] for mm in pb]
        if grow_f: fr=nxt
        else: br=nxt
        if len(F)+len(B)>limit: return None
    return None
def replay(st,mv):
    for m in mv: st=core.apply_move(st,m)
    return st
if __name__=='__main__':
    for m in (4,5,6):
        s=P(m,W1); tg=[P(m-1,W1),P(m-1,W2)]
        cap=len(s[0])+len(s[1])+int(sys.argv[1]) if len(sys.argv)>1 else len(s[0])+len(s[1])+4
        path=mitm(s,tg,cap)
        print("m=%d start %s cap %d -> step %s"%(m,s,cap,path), "len",None if path is None else len(path), flush=True)
        if path: print("   replay lands on target:", replay(s,path) in tg)

def variants(p):
    def rots(w):
        w=list(w); out=set()
        for i in range(len(w)):
            r=red(w[i:]+w[:i]); out.add(r); out.add(tuple(-c for c in reversed(r)))
        return out
    A=rots(p[0]); B=rots(p[1]); V=set()
    for a in A:
        for b in B: V.add((a,b)); V.add((b,a))
    return V
