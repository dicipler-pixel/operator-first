# SCRIPT: KERNEL-PRIOGOAL-01  priority rows: every node u on every known road (incl. the prio web best path),
#   radius-3 ball around u, then look each state w up in the radius-7 ball around the goal (goal2_R7.txt, fixed hash).
#   Length = (steps to u along its road) + d(u,w) + g(w). The YX goal uses the relator-swap symmetry: d(w,YX) = g(swap w).
#   Why it proves what it claims: a hit is rebuilt into a concrete move list (descent through the goal ball, swap-relabelled
#   for YX) and replayed on verifier.core; hash look-ups only propose, the replay decides. Hits go to the official CLI.
import sys,json,time,os
src=open('web2.py').read().split("if __name__=='__main__':")[0].replace("'teampool.txt']","'teampool.txt','scan_ac.txt','scan4_ac.txt','scan4b_ac.txt','scan5_ac.txt']")
exec(src)
exec(open('hsh2.py').read())
G={}
for line in open('goal2_R7.txt'):
    a,b=line.split(); G[int(a)]=int(b)
print('goal ball',len(G),flush=True)
SW={0:1,1:0,2:4,3:5,4:2,5:3,6:10,7:11,8:12,9:13,10:6,11:7,12:8,13:9}
def sw(s): return (s[1],s[0])
def gdist(s): return G.get(hs(s))
def descend(s):
    p=[]; d=gdist(s)
    while d and d>0:
        for m in range(14):
            t=core.apply_move(s,m); dt=gdist(t)
            if dt==d-1: p.append(m); s=t; d=dt; break
        else: return None
    return p if s==GOAL else None
rows=json.load(open('prio_rows.json'))
need={}
for name,ours,rec in rows:
    ac='ac-'+name.split('-')[1]; need.setdefault(ac,{})['sac' if name.startswith('s') else 'ac']=int(rec)
fn='prio_goal.json'
try: out=json.load(open(fn))
except Exception: out={}
for ac,tg in need.items():
    if ac in out: continue
    while True:
        try: pw=json.load(open('prio_R4.json'))
        except Exception: pw={}
        if ac in pw: break
        time.sleep(20)
    st0,roads=roads_for(ac)
    if pw[ac].get('xy_moves'): roads=roads+[pw[ac]['xy_moves']]
    D={}
    for r in roads:
        s=st0; D[s]=min(D.get(s,99),0)
        for i,m in enumerate(r):
            s=core.apply_move(s,m)
            if D.get(s,999)>i+1: D[s]=i+1
    bx=(999,None); by=(999,None)
    for u,du in D.items():
        B=ball(u,3)
        for w,(dw,_,_) in B.items():
            g=gdist(w)
            if g is not None and du+dw+g<bx[0]: bx=(du+dw+g,(u,w))
            g2=gdist(sw(w))
            if g2 is not None and du+dw+g2<by[0]: by=(du+dw+g2,(u,w))
    def build(best,yx):
        if best[1] is None: return None
        u,w=best[1]
        # path start->u: shortest road prefix
        pre=None
        for r in roads:
            s=st0
            if s==u: pre=[]; break
            for i,m in enumerate(r):
                s=core.apply_move(s,m)
                if s==u and (pre is None or i+1<len(pre)): pre=r[:i+1]
        B=ball(u,3); mid=trace(B,w)
        if yx:
            tail=descend(sw(w))
            if tail is None: return None
            tail=[SW[m] for m in tail]
        else:
            tail=descend(w)
            if tail is None: return None
        p=list(pre)+mid+tail
        s=st0
        for m in p: s=core.apply_move(s,m)
        return p if s==(YX if yx else GOAL) else None
    px=build(bx,False); py=build(by,True)
    out[ac]={'need':tg,'xy':len(px) if px else None,'yx':len(py) if py else None,'xy_moves':px,'yx_moves':py,'est':(bx[0],by[0])}
    hit=[]
    if 'ac' in tg and px and len(px)<=tg['ac']: hit.append(f"{ac}: {px}")
    if 'sac' in tg:
        c=[m+[16,15] for m in [px] if m]+[m+[15,15] for m in [py] if m]
        if c:
            b=min(c,key=len)
            if len(b)<=tg['sac']: hit.append(f"s{ac}: {b}")
    print(ac,'need',tg,'goalball xy',out[ac]['xy'],'yx',out[ac]['yx'],'est',bx[0],by[0],'| web',pw[ac].get('xy'),pw[ac].get('yx'),'HIT' if hit else '',flush=True)
    if hit: open('prio_hits.txt','a').write('\n'.join(hit)+'\n')
    json.dump(out,open(fn,'w'))
print('done',len(out))
