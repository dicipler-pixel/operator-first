# SCRIPT: KERNEL-SHORTCUT-02  asymmetric reach: radius-5 ball from S_i (built one at a time) vs stored radius-4 balls of all S_j; shortcuts up to 9 moves
import sys,re,time; sys.path.insert(0,'.'); sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from shortcut import ball, trace, INV, shorten
from load import pool
def improve5(start,path):
    S=[start]
    for m in path: S.append(core.apply_move(S[-1],m))
    B4=[ball(s,4) for s in S]; best=None
    for i in range(len(S)-2):
        A=ball(S[i],5)
        for j in range(len(S)-1,i+1,-1):
            B=B4[j]
            for u,(d2,_,_) in B.items():
                a=A.get(u)
                if a is None: continue
                tot=a[0]+d2
                if tot<j-i and (best is None or j-i-tot>best[0]):
                    best=(j-i-tot,i,j,trace(A,u)+[INV[m] for m in reversed(trace(B,u))])
        if best: break           # take the first gain found, then restart (keeps memory/time bounded)
    if not best: return None
    g,i,j,mid=best; return path[:i]+mid+path[j:]
if __name__=='__main__':
    P=pool(); items=[]
    for line in open(sys.argv[1]):
        m=re.match(r'(ac-\d+): \[(.*?)\](.*)',line)
        if m: items.append((m.group(1),[int(v) for v in m.group(2).split(',')],m.group(3).strip()))
    lo,hi=int(sys.argv[2]),int(sys.argv[3])
    for cid,mv,note in items[lo:hi]:
        t0=time.time(); st=(tuple(P[cid][0]),tuple(P[cid][1])); cur=mv
        while True:
            nw=improve5(st,cur)
            if nw is None or len(nw)>=len(cur): break
            nw=shorten(st,nw)
            chk=st
            for m in nw: chk=core.apply_move(chk,m)
            assert chk==((1,),(2,))
            cur=nw
        print(f"{cid} {len(mv)} -> {len(cur)} {note} ({time.time()-t0:.0f}s)"+(f"  NEW: {cid}: {cur}" if len(cur)<len(mv) else ""),flush=True)
