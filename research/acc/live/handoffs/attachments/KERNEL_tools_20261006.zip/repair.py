# SCRIPT: KERNEL-REPAIR-01  Grok's "replay until it breaks, then bridge" lift.
#   Walk the mapped sibling path on the target. Offset = target length - sibling length at the same step.
#   When the offset exceeds base+2, try every bridge b of 0..3 moves at that point; score b by the worst offset over the
#   next 8 sibling moves after b; keep the best if it beats doing nothing; continue. At the end, beam-finish (kbeam2b W).
#   Route = all moves actually applied + finish; replayed on verifier.core. Prints only lengths, never states.
import sys,json,itertools,time; sys.argv=['x','0','1']
exec(open('lift.py').read().split("if __name__=='__main__':")[0])
BR=[()]+[(a,) for a in range(14)]+[(a,b) for a in range(14) for b in range(14)]+[(a,b,c) for a in range(14) for b in range(14) for c in range(14)]
def L(s): return len(s[0])+len(s[1])
def look(s,mp,i,dL,k=8):
    w=0
    for j in range(i,min(i+k,len(mp))):
        s=core.apply_move(s,mp[j]); w=max(w,L(s)-dL[j+1])
    return w
def repair(tid,did,v,W=4000,maxrep=12):
    st0=(tuple(P[tid][0]),tuple(P[tid][1])); dp=held[did]; dst=(tuple(P[did][0]),tuple(P[did][1])); dL=traj(dst,dp)
    mp=[mmap(m,*v) for m in dp]; base=L(st0)-dL[0]
    s=st0; route=[]; i=0; reps=0
    while i<len(mp):
        nxt=core.apply_move(s,mp[i])
        if L(nxt)-dL[i+1]<=base+2 or reps>=maxrep:
            s=nxt; route.append(mp[i]); i+=1; continue
        best=None
        for b in BR:
            t=s
            for m in b: t=core.apply_move(t,m)
            sc=(look(t,mp,i,dL),len(b))
            if best is None or sc<best[0]: best=(sc,b,t)
        reps+=1
        if best[1]==():                      # no bridge helps: accept the drift
            s=nxt; route.append(mp[i]); i+=1; continue
        s=best[2]; route+=list(best[1])
    fin=beam(s,W,60)
    out=None
    if fin is not None:
        r=route+fin; chk=st0
        for m in r: chk=core.apply_move(chk,m)
        if chk==GOAL: out=r
    return dict(end_len=L(s),walk=len(route),reps=reps,route=out)
def best_variants(tid,did,n=2):
    st0=(tuple(P[tid][0]),tuple(P[tid][1])); dp=held[did]; dst=(tuple(P[did][0]),tuple(P[did][1])); dL=traj(dst,dp)
    sc=[]
    for v in VARS:
        tL=traj(st0,[mmap(m,*v) for m in dp]); k=0
        while k<len(dL) and tL[k]-dL[k]<=(tL[0]-dL[0])+2: k+=1
        sc.append((-k,v))
    sc.sort(); return [v for _,v in sc[:n]]
if __name__=='__main__':
    pairs=json.loads(sys.stdin.read())
    for tid,did in pairs:
        t0=time.time(); res=[]
        for v in best_variants(tid,did):
            r=repair(tid,did,v); res.append(r)
        ok=[r for r in res if r['route']]
        b=min(ok,key=lambda r:len(r['route'])) if ok else None
        print(tid,'<-',did,f'(donor {len(held[did])}, team {len(held.get(tid,[])) or "-"})','RESULT',len(b['route']) if b else None,
              '| ends',[ (r['end_len'],r['walk'],r['reps']) for r in res],f'{time.time()-t0:.0f}s',flush=True)
