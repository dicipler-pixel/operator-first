# SCRIPT: KERNEL-HS-01  python copy of kbeam's exact-state hash hs()
def hs(st):
    h=1469598103934665603; M=0xFFFFFFFFFFFFFFFF
    for c in st[0]: h^=(c & 0xff); h=(h*1099511628211)&M
    h^=0xff; h=(h*1099511628211)&M
    for c in st[1]: h^=(c & 0xff); h=(h*1099511628211)&M
    return h or 1
