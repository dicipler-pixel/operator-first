# SCRIPT: KERNEL-OPPOSITE-01  opposite ranking (prefer longest under cap start+12), same W=2000 D=300; control rows then our rows
import json,sys,time,re; sys.path.insert(0,'.')
import drive2 as D
from load import relay, pool
from concurrent.futures import ThreadPoolExecutor
P=pool()
ctl=[(cid,P[cid][0],P[cid][1],0) for cid,_,_,_ in json.load(open('control_cross_rows.json'))]
ours=[(cid,r[0],r[1],n) for n,cid,r in relay()]
out_all={}
for name,items in (('control44',ctl),('ours113',ours)):
    t0=time.time()
    def one(it):
        cid,a,b,n=it; o=D.run_one((cid,a,b,2000,300,len(a)+len(b)+12,2,1)); o['row']=n; o['start']=len(a)+len(b); return o
    with ThreadPoolExecutor(2) as ex: out=list(ex.map(one,items))
    sol=[o for o in out if o['moves']]
    print(f"{name}: opposite ranking solved {len(sol)}/{len(items)} (official ok {sum(bool(o['official_ok']) for o in sol)}) in {time.time()-t0:.0f}s", [(o['id'],len(o['moves'])) for o in sol][:10], flush=True)
    out_all[name]=out
json.dump(out_all,open('opposite_results.json','w'))
