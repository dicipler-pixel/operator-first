# SCRIPT: KERNEL-MSPIPE-01  basis search -> kbeam2 in the basis -> translate to letter moves -> finish -> official replay
import sys, subprocess, re; sys.path.insert(0,'.')
from basis import *
S={1:'x',-1:'X',2:'y',-2:'Y'}
def solve(r0,r1,W=2000,D=300,h=None,nbases=3,H=0):
    tried=[]
    for tot,s,w0,w1 in best_bases(r0,r1,keep=nbases):
        cap = tot+h if h is not None else tot+60
        out=subprocess.run(['./kbeam2',str(W),str(D),str(cap),str(H),'1',''.join(S[c] for c in w0),''.join(S[c] for c in w1)],capture_output=True,text=True).stdout.strip()
        m=re.search(r'\[(.*)\]',out); b=re.search(r'best (\d+)',out)
        tried.append(dict(basis_len=tot,U=[list(s[0]),list(s[1])],out=out.split(' PROFILE')[0], best=int(b.group(1)) if b else 2))
        if not m: continue
        bpath=[int(v) for v in m.group(1).split(',')]
        lp=translate(bpath,(s[0],s[1])); st=replay(r0,r1,lp)
        fin=finish(st)
        if fin is None: tried[-1]['note']='finish failed from '+str(st); continue
        full=lp+fin
        ok = replay(r0,r1,full)==((1,),(2,))
        return dict(moves=full,official_ok=ok,basis=[list(s[0]),list(s[1])],basis_path_len=len(bpath),tried=tried)
    return dict(moves=None,tried=tried)
