# SCRIPT: KERNEL-PRIO-01 (rerun 2: + UPG-H 11:18Z priority roads, 429 roads all replayed)  UPG-H 10:25Z redirect: radius-R road-web fixpoint on the priority rows, in list order.
#   Target per row: AC needs XY route <= record; sac needs min(XY,YX) route <= record-2 (line = route + [16,15] or [15,15]).
#   Every path is replayed on verifier.core by back(); any hit goes to prio2_hits.txt for the official CLI before posting.
import sys,json
src=open('web2.py').read().split("if __name__=='__main__':")[0].replace("'teampool.txt']","'teampool.txt','scan_ac.txt','scan4_ac.txt','scan4b_ac.txt','scan5_ac.txt','prio_roads.txt']")
exec(src)
EXTRA={}
_rf=roads_for
def roads_for(cid):
    st0,good=_rf(cid)
    return st0,good+[list(r) for r in EXTRA.get(cid,[])]
Rb=int(sys.argv[1]) if len(sys.argv)>1 else 4
rows=json.load(open('prio_rows.json'))
need={}
for name,ours,rec in rows:
    ac='ac-'+name.split('-')[1]
    need.setdefault(ac,{})['sac' if name.startswith('s') else 'ac']=int(rec)
fn=f'prio2_R{Rb}.json'
try: out=json.load(open(fn))
except Exception: out={}
for ac,tg in need.items():
    if ac in out: continue
    try:
        hist=[];bx=None;by=None
        for it in range(6):
            r=web(ac,Rb)
            if r is None: break
            hist.append((r['web'],r['yx']))
            imp=False
            if r['moves'] and (bx is None or len(r['moves'])<len(bx)): bx=r['moves']; imp=True; EXTRA.setdefault(ac,set()).add(tuple(bx))
            if r['yx_moves'] and (by is None or len(r['yx_moves'])<len(by)): by=r['yx_moves']; imp=True
            if not imp: break
    except Exception as e:
        out[ac]={'err':str(e)}; json.dump(out,open(fn,'w')); print(ac,'ERR',e,flush=True); continue
    out[ac]={'need':tg,'xy':len(bx) if bx else None,'yx':len(by) if by else None,'xy_moves':bx,'yx_moves':by,'hist':hist,'roads':len(roads_for(ac)[1])}
    hit=[]
    if 'ac' in tg and bx and len(bx)<=tg['ac']: hit.append(f"{ac}: {bx}")
    if 'sac' in tg:
        c=[m+[16,15] for m in [bx] if m]+[m+[15,15] for m in [by] if m]
        if c:
            b=min(c,key=len)
            if len(b)<=tg['sac']: hit.append(f"s{ac}: {b}")
    print(ac,'need',tg,'got xy',out[ac]['xy'],'yx',out[ac]['yx'],'roads',out[ac]['roads'],'HIT' if hit else '',flush=True)
    if hit: open('prio2_hits.txt','a').write('\n'.join(hit)+'\n')
    json.dump(out,open(fn,'w'))
print('done',len(out))
