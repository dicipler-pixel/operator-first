# SCRIPT: KERNEL-LIFT-02 (resumable; W from argv[3])  was KERNEL-LIFT-01  comb lift: carry a held MS(n+-1,w) path onto an unheld MS(n,w) row.
#   1) map the donor's moves through each of 16 symmetries (8 signed generator swaps x relator swap);
#   2) replay each mapped path on the TARGET start; keep the 2 variants whose length profile tracks the donor's own
#      profile longest ("replay until it breaks");
#   3) from every 2nd prefix state of those variants run the hash-fixed beam (kbeam2b) to the trivial pair;
#   route = prefix + beam finish; every route replayed on verifier.core before it is kept. First solves count at any length.
import sys,json,re,subprocess,time; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from load import pool
P=pool(); S={1:'x',-1:'X',2:'y',-2:'Y'}; GOAL=((1,),(2,))
held={}
for l in open('teampool.txt'):
    m=re.match(r'(ac-\d+): \[(.*?)\]',l); held[m.group(1)]=[int(v) for v in m.group(2).split(',')]
GENS=(1,-1,2,-2)
def lmap(c,sw,sx,sy):
    g=abs(c); s=1 if c>0 else -1
    if sw: g=3-g
    return s*(sx if g==1 else sy)*g
def mmap(m,sw,sx,sy,rs):
    if m<=1: base=m; return 1-base if rs else base
    if m<=5:
        if rs: return {2:4,3:5,4:2,5:3}[m]
        return m
    r=0 if m<=9 else 1; k=(m-6)%4; g=lmap(GENS[k],sw,sx,sy); k2=GENS.index(g)
    if rs: r=1-r
    return 6+4*r+k2
VARS=[(sw,sx,sy,rs) for sw in (0,1) for sx in (1,-1) for sy in (1,-1) for rs in (0,1)]
def traj(st,path):
    L=[sum(map(len,st))]; 
    for m in path: st=core.apply_move(st,m); L.append(sum(map(len,st)))
    return L
def beam(st,W,D):
    o=subprocess.run(['./kbeam2b',str(W),str(D),'80','0','1',''.join(S[c] for c in st[0]),''.join(S[c] for c in st[1])],capture_output=True,text=True,timeout=300).stdout
    m=re.search(r'SOLVED depth (\d+) : \[(.*)\]',o)
    return [int(x) for x in m.group(2).split(',')] if m else None
def lift(tid,did,W=2000):
    t0=time.time(); st0=(tuple(P[tid][0]),tuple(P[tid][1])); dp=held[did]
    dst=(tuple(P[did][0]),tuple(P[did][1])); dL=traj(dst,dp)
    sc=[]
    for v in VARS:
        mp=[mmap(m,*v) for m in dp]; tL=traj(st0,mp)
        k=0
        while k<len(dL) and abs(tL[k]-dL[k])<=2+k//4: k+=1      # how long the target tracks the donor's shape
        sc.append((-k,sum(abs(a-b) for a,b in zip(tL,dL)),v,mp))
    sc.sort(key=lambda x:(x[0],x[1]))
    best=None; tried=0
    for negk,_,v,mp in sc[:2]:
        st=st0; prefix=[]
        for t in range(0,len(mp)+1):
            if t%2==0 or t==len(mp):
                fin=beam(st,W,max(30,len(dp)+25)); tried+=1
                if fin is not None:
                    route=prefix+fin; chk=st0
                    for m in route: chk=core.apply_move(chk,m)
                    if chk==GOAL and (best is None or len(route)<len(best[0])): best=(route,t,v,-negk)
            if t<len(mp): st=core.apply_move(st,mp[t]); prefix.append(mp[t])
    return dict(target=tid,donor=did,donor_len=len(dp),best=(len(best[0]) if best else None),route=(best[0] if best else None),
                at_prefix=(best[1] if best else None),variant=(best[2] if best else None),tracked=(best[3] if best else None),beams=tried,secs=round(time.time()-t0))
if __name__=='__main__':
    comb=json.load(open('comb.json')); part,nparts=int(sys.argv[1]),int(sys.argv[2])
    seen=set(); todo=[]
    for x in comb:                       # best (shortest) held donor per target, n-1 donors first
        if x[0] in seen: continue
        seen.add(x[0]); todo.append((x[0],x[2]))
    todo=todo[part::nparts]; W=int(sys.argv[3]) if len(sys.argv)>3 else 2000
    fn=f'lift_part{part}_W{W}.json'
    try: out=json.load(open(fn))            # resume after a container restart
    except Exception: out=[]
    done={r['target'] for r in out}
    for tid,did in todo:
        if tid in done: continue
        r=lift(tid,did,W); out.append(r)
        print(tid,'<-',did,f"(donor {r['donor_len']})",'SOLVED',r['best'],'prefix',r['at_prefix'],'tracked',r['tracked'],f"beams {r['beams']} {r['secs']}s" if r['best'] else f"no route, beams {r['beams']} {r['secs']}s",flush=True)
        json.dump(out,open(fn,'w'))
