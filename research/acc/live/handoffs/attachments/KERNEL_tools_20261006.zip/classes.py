# SCRIPT: KERNEL-CLASSES-01  group rows into classes that transfer a solution with a few extra moves:
# generator signed permutations (8), relator order swap, relator inversion, cyclic rotation (after cyclic reduction)
import sys, json, collections; sys.path.insert(0,'.')
from load import relay, pool
def cred(w):
    w=list(w)
    while len(w)>1 and w[0]==-w[-1]: w=w[1:-1]
    return w
def rots(w): return [tuple(w[i:]+w[:i]) for i in range(len(w))] or [()]
def inv(w): return [-c for c in reversed(w)]
AUTS=[]
for swap in (0,1):
    for sx in (1,-1):
        for sy in (1,-1):
            def f(c,swap=swap,sx=sx,sy=sy):
                g=abs(c); s=1 if c>0 else -1
                if swap: g=3-g
                return s*(sx if g==1 else sy)*g
            AUTS.append(f)
def relkey(w): w=cred(w); return min(rots(w)+rots(inv(w)))
def key(r0,r1):
    best=None
    for f in AUTS:
        a=relkey([f(c) for c in r0]); b=relkey([f(c) for c in r1])
        k=tuple(sorted([a,b]))
        if best is None or k<best: best=k
    return best
if __name__=='__main__':
    R=relay(); C=collections.defaultdict(list)
    for n,cid,r in R: C[key(*r)].append((n,cid))
    sizes=collections.Counter(len(v) for v in C.values())
    print("113 rows ->",len(C),"classes; class-size histogram",sorted(sizes.items()))
    # also: twins elsewhere in the whole official pool (solved or not, unknown to us)
    P=pool(); PK=collections.defaultdict(list)
    for cid,r in P.items(): PK[key(*r)].append(cid)
    mine={k for k in C}; ext={k:[c for c in PK[k] if c not in {x[1] for x in C[k]}] for k in mine}
    print("classes with twins elsewhere in the 10,115-row pool:",sum(1 for k in mine if ext[k]))
    json.dump([{'rows':[x[0] for x in v],'ids':[x[1] for x in v],'pool_twins':ext[k]} for k,v in C.items()],open('classes_kernel.json','w'),indent=0)
    for k,v in sorted(C.items(),key=lambda kv:-len(kv[1]))[:8]: print(len(v),[x[1] for x in v][:6],"pool twins:",ext[k][:6])
