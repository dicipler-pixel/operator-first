# SCRIPT: KERNEL-MSLADDER-01  MS-basis ladder on rows 101-213: h = 4, 8, 12, uncapped; 3 shortest bases; W=2000 depth 300
import sys,json,time; sys.path.insert(0,'.')
from pipeline import solve; from load import relay
from concurrent.futures import ThreadPoolExecutor
rows=relay(); results=[]
for h in (4,8,12,None):
    t0=time.time()
    def one(x):
        n,cid,r=x; o=solve(r[0],r[1],h=h); o.update(row=n,id=cid,h=h,start=len(r[0])+len(r[1])); return o
    with ThreadPoolExecutor(2) as ex: out=list(ex.map(one,rows))
    sol=[o for o in out if o['moves']]
    newlow=sum(1 for o in out if min(t['best'] for t in o['tried'])<min(t['basis_len'] for t in o['tried']))
    print(f"MS h={h}: solved {len(sol)}/113 (official ok {sum(o['official_ok'] for o in sol)}), rows below basis start {newlow}, {time.time()-t0:.0f}s",
          [(o['id'],len(o['moves'])) for o in sol], flush=True)
    results+=out
    json.dump(results,open('ms_ladder_results.json','w'))
