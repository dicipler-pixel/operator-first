# SCRIPT: KERNEL-TAPS-CONTROL-01  compressor control: 60 training paths + 44 cross lines, official replay inside compress()
import sys,json,re,time,random; sys.path.insert(0,'.')
from taps import compress
from load import pool
T=json.load(open('../acc/competition/examples/training_424.json'))['instances']
random.seed(5); S=random.sample(T,60); t0=time.time(); rows=[]
for t in S:
    c=compress(t['initial_relators'][0],t['initial_relators'][1],t['moves'])
    rows.append((t['training_id'],len(t['moves']),None if c is None else len(c)))
b=[r for r in rows if r[2] is not None and r[2]<r[1]]; w=[r for r in rows if r[2] is not None and r[2]>r[1]]
print(f"TRAINING sample 60: shorter {len(b)} (saved {sum(r[1]-r[2] for r in b)}), longer {len(w)}, failed {sum(r[2] is None for r in rows)}, {time.time()-t0:.0f}s",flush=True)
print("  shorter examples:",b[:10],flush=True)
P=pool(); t0=time.time(); res=[]
for line in open('hub/cross.txt'):
    m=re.match(r'(ac-\d+): \[(.*)\]',line)
    if not m: continue
    cid=m.group(1); mv=[int(v) for v in m.group(2).split(',')]
    c=compress(P[cid][0],P[cid][1],mv); res.append((cid,len(mv),None if c is None else len(c),c))
    print("  ",cid,len(mv),'->',None if c is None else len(c),flush=True)
json.dump(res,open('taps_cross.json','w'))
print(f"CROSS 44 done {time.time()-t0:.0f}s",flush=True)
