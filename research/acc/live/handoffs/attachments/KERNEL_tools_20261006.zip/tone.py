# SCRIPT: KERNEL-TONE-01  song2 "ground tone": rank beam states by the floor of their 1-/2-move neighbourhood (H3/H4), opposite = ceiling (H5); baseline H0 same seeds/width
# Control first: training rows must still solve. Every route replayed on verifier.core.
import sys,subprocess,json,re,time; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from load import pool
S={1:'x',-1:'X',2:'y',-2:'Y'}; P=pool(); REC=json.load(open('rec_bob.json'))
def run(cid,W,H,seed,D):
    r0,r1=P[cid]; t=time.time()
    o=subprocess.run(['./kbeam6',str(W),str(D),'60',str(H),str(seed),''.join(S[c] for c in r0),''.join(S[c] for c in r1)],capture_output=True,text=True).stdout
    m=re.search(r'SOLVED depth (\d+) : \[(.*)\]',o)
    if not m: return None,round(time.time()-t)
    mv=[int(x) for x in m.group(2).split(',')]; st=(tuple(r0),tuple(r1))
    for x in mv: st=core.apply_move(st,x)
    return (mv if st==((1,),(2,)) else 'FAIL'),round(time.time()-t)
rows=sys.argv[1].split(','); W=int(sys.argv[2]); Hs=[int(h) for h in sys.argv[3].split(',')]
out={}
for cid in rows:
    for H in Hs:
        for seed in (1,2):
            mv,sec=run(cid,W,H,seed,REC.get(cid,60)+40)
            print(cid,'W',W,'H',H,'seed',seed,'->',(len(mv) if isinstance(mv,list) else mv),'record',REC.get(cid),f'({sec}s)',flush=True)
            if isinstance(mv,list): out.setdefault(cid,[]).append(mv)
json.dump(out,open(f'tone_{rows[0]}_W{W}.json','w'))
