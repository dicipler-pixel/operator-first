# SCRIPT: KERNEL-YXSCAN-01  over every team-pool row: road web (team road + any kernel roads), radius-3 bridges, Dijkstra to
#   XY and to the swapped goal YX. Reports rows where YX < team AC length (Stable line = YX + 2 <= AC + 1) or XY < team AC.
#   Every reported path is replayed on verifier.core (back() checks it); sac lines are re-checked with stable_core below.
import sys,json,re; sys.argv=['x']
exec(open('web2.py').read().split("if __name__=='__main__':")[0])
ids=[re.match(r'(ac-\d+):',l).group(1) for l in open('teampool.txt')]
part,n=int(sys.argv[1]) if len(sys.argv)>1 else 0,1
out={}
try: out=json.load(open('yxscan.json'))
except Exception: pass
for i,cid in enumerate(ids):
    if cid in out: continue
    try: r=web(cid,3)
    except Exception as e: out[cid]={'err':str(e)}; continue
    out[cid]={'team':r['best_in'],'xy':r['web'],'yx':r['yx'],'xy_moves':r['moves'],'yx_moves':r['yx_moves']}
    if (r['yx'] and r['yx']<r['best_in']) or (r['web'] and r['web']<r['best_in']):
        print(cid,'team',r['best_in'],'XY',r['web'],'YX',r['yx'],flush=True)
    if i%50==0: json.dump(out,open('yxscan.json','w')); print('..',i,flush=True)
json.dump(out,open('yxscan.json','w')); print('done',len(out))
