# SCRIPT: KERNEL-TAPS-01  turns-vs-taps compressor: keep taps (moves 0-5) in order, re-choose conjugations (6-13) minimally, exact finish, official replay
import sys,collections; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
def cred(w):
    w=list(w)
    while len(w)>1 and w[0]==-w[-1]: w=w[1:-1]
    return w
def cyc(w):
    w=cred(w); return min(tuple(w[i:]+w[:i]) for i in range(max(1,len(w)))) if w else ()
def ckey(st): return (cyc(st[0]),cyc(st[1]))
def replay(st,mv):
    for m in mv: st=core.apply_move(st,m)
    return st
CONJ=range(6,14)
def segment(st,tap,want,maxd=10,cap=None,limit=400000):
    # fewest conjugations c so that tap(c(st)) has cyclic classes == want
    if ckey(core.apply_move(st,tap))==want: return []
    par={st:None}; fr=[st]
    for d in range(maxd):
        nx=[]
        for s in fr:
            for m in CONJ:
                t=core.apply_move(s,m)
                if t in par or (cap and len(t[0])+len(t[1])>cap): continue
                par[t]=(s,m)
                if ckey(core.apply_move(t,tap))==want:
                    p=[]; u=t
                    while par[u]: u,mm=par[u]; p.append(mm)
                    return p[::-1]
                nx.append(t)
        fr=nx
        if len(par)>limit: return None
    return None
def finish(st,maxd=12,limit=600000):
    tgt=((1,),(2,))
    if st==tgt: return []
    par={st:None}; fr=[st]
    for d in range(maxd):
        nx=[]
        for s in fr:
            for m in range(14):
                t=core.apply_move(s,m)
                if t in par or len(t[0])+len(t[1])>len(st[0])+len(st[1])+4: continue
                par[t]=(s,m)
                if t==tgt:
                    p=[]; u=t
                    while par[u]: u,mm=par[u]; p.append(mm)
                    return p[::-1]
                nx.append(t)
        fr=nx
        if len(par)>limit: return None
    return None
def compress(r0,r1,path):
    start=(tuple(r0),tuple(r1))
    # original tap sequence and the cyclic classes after each tap
    st=start; taps=[]
    for m in path:
        st=core.apply_move(st,m)
        if m<=5: taps.append((m,ckey(st)))
    # the original conjugation tail after the last tap is replaced by an exact finish
    cur=start; out=[]
    for m,want in taps:
        seg=segment(cur,m,want)
        if seg is None: return None
        cur=replay(cur,seg+[m]); out+=seg+[m]
    fin=finish(cur)
    if fin is None: return None
    out+=fin
    return out if replay(start,out)==((1,),(2,)) else None
