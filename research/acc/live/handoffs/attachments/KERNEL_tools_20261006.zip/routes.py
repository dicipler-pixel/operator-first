# SCRIPT: KERNEL-ROUTES-01  many distinct routes per row from kernel's own engine; each shortened (exact radius-4 shortcuts), official replay, vs record
import sys,json,time,subprocess,re; sys.path.insert(0,'.'); sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from load import pool
from shortcut import shorten
from pipeline import solve
from concurrent.futures import ThreadPoolExecutor
S={1:'x',-1:'X',2:'y',-2:'Y'}
REC={'ac-00145':39,'ac-08995':45,'ac-03714':50,'ac-04086':34,'ac-03719':None,'ac-00580':42,'ac-05726':None}
P=pool()
def beam(r0,r1,W,H,seed,D=400):
    out=subprocess.run(['./kbeam2',str(W),str(D),str(len(r0)+len(r1)+60),str(H),str(seed),''.join(S[c] for c in r0),''.join(S[c] for c in r1)],capture_output=True,text=True).stdout
    m=re.search(r'\[(.*)\]',out); return [int(v) for v in m.group(1).split(',')] if m else None
def ok(st,mv):
    for m in mv: st=core.apply_move(st,m)
    return st==((1,),(2,))
def row(cid):
    r=P[cid]; st=(tuple(r[0]),tuple(r[1])); raw=[]
    for W in (500,2000,4000):
        for H in (0,1):
            for seed in (1,2,3):
                mv=beam(r[0],r[1],W,H,seed)
                if mv: raw.append(('beam W%d H%d s%d'%(W,H,seed),mv))
    o=solve(r[0],r[1])
    if o.get('moves'): raw.append(('MS-basis pipeline',o['moves']))
    routes={}
    lim=(REC.get(cid) or 60)+40
    for tag,mv in raw:
        if not ok(st,mv) or len(mv)>max(100,lim): continue
        sh=shorten(st,mv)
        if not ok(st,sh): sh=mv
        if len(sh)<=lim: routes.setdefault(tuple(sh),tag)
    return cid,routes,len(raw)
t0=time.time(); res={}
with ThreadPoolExecutor(2) as ex:
    for cid,routes,nraw in ex.map(row,REC):
        best=min((len(k) for k in routes),default=None); rec=REC[cid]
        tag='' if best is None or rec is None else ('BEAT' if best<rec else 'TIE' if best==rec else f'+{best-rec}')
        print(f"{cid} record {rec}: raw runs solved {nraw}, distinct routes {len(routes)}, lengths {sorted(len(k) for k in routes)} {tag}  ({time.time()-t0:.0f}s)",flush=True)
        res[cid]={' '.join(map(str,k)):v for k,v in routes.items()}
        json.dump(res,open('routes11b.json','w'))
