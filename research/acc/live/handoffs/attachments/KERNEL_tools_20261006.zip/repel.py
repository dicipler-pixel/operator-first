# SCRIPT: KERNEL-REPEL-01  repelled beam: states within R=2 of any known road get score+REPEL, depth cap record+3
import sys,re,json,subprocess,time,os
sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from load import pool
S={1:'x',-1:'X',2:'y',-2:'Y'}; P=pool()
cid=sys.argv[1]; rec=int(sys.argv[2]); Ws=[int(w) for w in sys.argv[3].split(',')]
start=(tuple(P[cid][0]),tuple(P[cid][1]))
out=[]
for W in Ws:
  for pen in (3,6,12):
    for H in (0,1):
      for seed in (1,2,3):
        env=dict(os.environ,ROADFILE=f'tube_{cid}_2.txt',REPEL=str(pen)); t0=time.time()
        o=subprocess.run(['./kbeam5',str(W),str(rec+3),str(len(start[0])+len(start[1])+60),str(H),str(seed),''.join(S[c] for c in start[0]),''.join(S[c] for c in start[1])],capture_output=True,text=True,env=env).stdout
        m=re.search(r'SOLVED depth (\d+) : \[(.*)\]',o); tag=f'W{W} pen{pen} H{H} s{seed}'
        if m:
          mv=[int(v) for v in m.group(2).split(',')]; st=start
          for x in mv: st=core.apply_move(st,x)
          flag='TIE' if len(mv)==rec else ('BEAT' if len(mv)<rec else '+%d'%(len(mv)-rec))
          print(cid,tag,'SOLVED',len(mv),flag,'ok',st==((1,),(2,)),f'{time.time()-t0:.0f}s',flush=True)
          if st==((1,),(2,)): out.append(mv)
        else: print(cid,tag,o.strip()[:90],f'{time.time()-t0:.0f}s',flush=True)
json.dump(out,open(f'repel_{cid}.json','w'))
