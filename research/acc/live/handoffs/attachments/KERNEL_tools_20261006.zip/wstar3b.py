# SCRIPT: KERNEL-WSTAR3-02  per-row one-sided search in the row's own letters (other relator fixed) to the image of a b^-1 a^-3, then finish; official replay
import sys,json,collections,time; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from onesided import cls
from wstar3 import bfs_to, replay, fl, AUTS
from basis import best_bases, sub
from classes import key; from msid import ms
from load import pool; from wstar_ids import IDS
P=pool(); M3=key(*ms(3,[-2,1,2,-1]))
ONE={0:(0,2,3,6,7,8,9),1:(1,4,5,10,11,12,13)}
def run_row(r,cap_extra=6,limit=4_000_000):
    R=(tuple(r[0]),tuple(r[1]))
    U=None
    for tot,s,w0,w1 in best_bases(r[0],r[1],keep=6):
        if key(w0,w1)==M3: U=(list(s[0]),list(s[1])); break
    T={cls(sub(fl_word,{1:U[0],2:U[1]})) for fl_word in ([fl(c,a) for c in [1,-2,-1,-1,-1]] for a in AUTS)}
    best=None
    for i in (0,1):
        fixed=R[1-i]; cap=len(R[i])+cap_extra
        par={R[i]:None}; fr=[R[i]]; hits=0
        while fr and len(par)<limit and hits<20:
            nx=[]
            for w in fr:
                for m in ONE[i]:
                    st=(w,fixed) if i==0 else (fixed,w)
                    t=core.apply_move(st,m)[i]
                    if len(t)>cap or t in par: continue
                    par[t]=(w,m); nx.append(t)
                    if cls(t) in T:
                        hits+=1; p=[]; u=t
                        while par[u]: u,mm=par[u]; p.append(mm)
                        p=p[::-1]; mid=replay(R,p)
                        fin=bfs_to(mid,lambda s:s==((1,),(2,)),len(mid[0])+len(mid[1])+6,limit=1_500_000)
                        if fin is not None:
                            line=p+fin
                            if replay(R,line)==((1,),(2,)) and (best is None or len(line)<len(best)): best=line
            fr=nx
            if best and fr and len(best)<=len(p)+1: break
    return best
out={}
for cid,n in IDS:
    if n!=3: continue
    t0=time.time(); line=run_row(P[cid])
    print(cid,"line length",None if line is None else len(line),"official core ok:",line is not None,f"{time.time()-t0:.0f}s",flush=True)
    if line: out[cid]=line
json.dump(out,open('wstar3_lines.json','w'))
