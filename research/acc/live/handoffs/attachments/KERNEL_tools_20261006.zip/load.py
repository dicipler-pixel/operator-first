# SCRIPT: KERNEL-LOAD-01  parse relay rows and check them against the official pool
import json, re
POOL='/tmp/claude-0/-home-claude/d6401873-8fe2-504f-bece-cf137876747f/scratchpad/acc/competition/problems/ac.jsonl'
L={'x':1,'X':-1,'y':2,'Y':-2}
def pool():
    P={}
    for line in open(POOL):
        d=json.loads(line); m=re.search(r'\|\s*(.*?)\s*>',d['description'])
        rels=[]
        for part in m.group(1).split(';'):
            part=part.strip().rstrip('= 1').strip() if False else part.split('=')[0].strip()
            w=[]
            for tok in part.split():
                w.append({'x':1,'x^-1':-1,'y':2,'y^-1':-2}[tok])
            rels.append(w)
        P[d['challenge_id']]=rels
    return P
def relay():
    rows=[]
    for line in open('relay.txt'):
        m=re.match(r'row (\d+): (ac-\d+)\s+(\S+) \| (\S+)',line)
        if m: rows.append((int(m.group(1)),m.group(2),[[L[c] for c in m.group(3)],[L[c] for c in m.group(4)]]))
    return rows
if __name__=='__main__':
    P=pool(); R=relay()
    bad=[r for r in R if P[r[1]]!=r[2]]
    print("rows",len(R),"ids unique",len({r[1] for r in R}),"mismatch vs official pool",len(bad))
    lens=[len(r[2][0])+len(r[2][1]) for r in R]; print("total length min/max",min(lens),max(lens))
