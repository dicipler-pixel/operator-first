# SCRIPT: KERNEL-WEB-01  "go one more": all known roads for a row in ONE graph.
#   Nodes = every state on every verified road (mine, team, Git). Edges = road steps (1 move)
#   + exact bridges between ANY two nodes (radius-R balls meet: d(u,w)+d(v,w), moves invertible).
#   Dijkstra start -> ((1,),(2,)), rebuild the moves, official core replay.
#   Why it proves what it claims: every edge is a concrete move list; the final path is replayed
#   move by move by verifier.core, so a reported length is a real certificate, not an estimate.
import sys,re,json,heapq,time,glob; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from load import pool
INV={0:0,1:1,2:3,3:2,4:5,5:4,6:7,7:6,8:9,9:8,10:11,11:10,12:13,13:12}
GOAL=((1,),(2,))
P=pool()
def ball(s,r):
    D={s:(0,None,None)}; fr=[s]
    for d in range(1,r+1):
        nx=[]
        for u in fr:
            for m in range(14):
                t=core.apply_move(u,m)
                if t not in D: D[t]=(d,u,m); nx.append(t)
        fr=nx
    return D
def trace(D,u):
    p=[]
    while D[u][1] is not None: p.append(D[u][2]); u=D[u][1]
    return p[::-1]
def roads_for(cid):
    R=set()
    for f in ['allp.txt','posted3.txt','batch4.txt','batch5.txt','batch6.txt','roads_batch1.txt','roads_batch2.txt','ext_roads.txt','batch7.txt']:
        try:
            for line in open(f):
                m=re.match(r'(ac-\d+): \[(.*?)\]',line)
                if m and m.group(1)==cid: R.add(tuple(int(v) for v in m.group(2).split(',')))
        except FileNotFoundError: pass
    for f in glob.glob('join_*.json'):
        d=json.load(open(f))
        for k in d.get(cid,{}): R.add(tuple(map(int,k.split())))
    good=[]
    st0=(tuple(P[cid][0]),tuple(P[cid][1]))
    for r in R:
        st=st0
        for m in r: st=core.apply_move(st,m)
        if st==GOAL: good.append(list(r))
    return st0,good
def web(cid,Rb=3):
    t0=time.time()
    st0,roads=roads_for(cid)
    if not roads: return None
    best_in=min(len(r) for r in roads)
    adj={}
    def add(u,v,w,mv):
        e=adj.setdefault(u,{})
        if v not in e or e[v][0]>w: e[v]=(w,mv)
    nodes=set()
    for r in roads:
        s=st0; nodes.add(s)
        for m in r:
            t=core.apply_move(s,m); add(s,t,1,[m]); nodes.add(t); s=t
    nodes=list(nodes)
    balls={u:ball(u,Rb) for u in nodes}
    meet={}
    for u in nodes:
        for w,(d,_,_) in balls[u].items(): meet.setdefault(w,[]).append((d,u))
    for w,L in meet.items():
        if len(L)<2: continue
        for du,u in L:
            for dv,v in L:
                if u is v or u==v: continue
                tot=du+dv
                if tot==0: continue
                e=adj.get(u,{})
                if v in e and e[v][0]<=tot: continue
                mv=trace(balls[u],w)+[INV[m] for m in reversed(trace(balls[v],w))]
                add(u,v,tot,mv)
    dist={st0:0}; prev={}; pq=[(0,0,st0)]; c=0
    while pq:
        d,_,u=heapq.heappop(pq)
        if u==GOAL: break
        if d>dist.get(u,1e9): continue
        for v,(w,mv) in adj.get(u,{}).items():
            if d+w<dist.get(v,1e9):
                dist[v]=d+w; prev[v]=(u,mv); c+=1; heapq.heappush(pq,(d+w,c,v))
    path=[]; u=GOAL
    while u!=st0: pu,mv=prev[u]; path=mv+path; u=pu
    st=st0
    for m in path: st=core.apply_move(st,m)
    ok=(st==GOAL)
    return dict(cid=cid,roads=len(roads),nodes=len(nodes),best_in=best_in,web=len(path),ok=ok,moves=path,secs=round(time.time()-t0))
if __name__=='__main__':
    Rb=int(sys.argv[2]) if len(sys.argv)>2 else 3
    out=[]
    for cid in sys.argv[1].split(','):
        r=web(cid,Rb)
        if r is None: print(cid,'no roads',flush=True); continue
        print(f"{cid} roads {r['roads']} nodes {r['nodes']} best_road {r['best_in']} -> web {r['web']} ok={r['ok']} ({r['secs']}s)",flush=True)
        if r['ok'] and r['web']<r['best_in']: print(f"  NEW: {cid}: {r['moves']}",flush=True)
        out.append(r)
    json.dump(out,open(f"web_{sys.argv[1].split(',')[0]}_R{Rb}.json",'w'))
