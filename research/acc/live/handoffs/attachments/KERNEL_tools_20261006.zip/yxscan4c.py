# SCRIPT: KERNEL-YXSCAN-03 (iter 3: + scan4b roads)  radius-4 web (team pool + every kernel road incl. scan_ac.txt) to XY and YX.
#   Resumable: yxscan4.json. Rows = scan_rows.json, biggest earlier gain first. Paths replayed by back() on verifier.core.
import sys,json,re
src=open('web2.py').read().split("if __name__=='__main__':")[0].replace("'teampool.txt']","'teampool.txt','scan_ac.txt','scan4_ac.txt','scan4b_ac.txt']")
exec(src)
Rb=int(sys.argv[1]) if len(sys.argv)>1 else 4
R=json.load(open('scan_rows.json'))
R.sort(key=lambda r:-(r[1]-min(r[2],r[3]+0)))
fn=f'yxscan{Rb}_it3.json'
try: out=json.load(open(fn))
except Exception: out={}
keep=set(l.split(':')[0][1:] for l in open('scan4b_sac.txt'))|set(l.split(':')[0] for l in open('scan4b_ac.txt'))
for c,team,xy,yx,s in R:
    if c not in keep: continue
    if c in out: continue
    try: r=web(c,Rb)
    except MemoryError: out[c]={'err':'mem'}; json.dump(out,open(fn,'w')); continue
    out[c]={'team':team,'xy3':xy,'yx3':yx,'xy':r['web'],'yx':r['yx'],'xy_moves':r['moves'],'yx_moves':r['yx_moves'],'secs':r['secs']}
    flag='  <<' if (r['web'] or 99)<xy or (r['yx'] or 99)<yx else ''
    print(c,'team',team,'R3',xy,yx,'R%d'%Rb,r['web'],r['yx'],r['secs'],'s',flag,flush=True)
    json.dump(out,open(fn,'w'))
print('done',len(out))
