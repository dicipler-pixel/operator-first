# SCRIPT: KERNEL-MSID-01  identify each row as MS(n,w) (up to relator rotation/inversion/swap and signed generator swaps)
import sys,json,collections; sys.path.insert(0,'.')
from classes import key
from basis import best_bases, red
from load import relay
T=json.load(open('../acc/competition/examples/training_424.json'))['instances']
def ms(n,w):  # training convention: r0 = X y^n x y^-(n+1), r1 = x w^-1
    return red([-1]+[2]*n+[1]+[-2]*(n+1)), red([1]+[-c for c in reversed(w)])
# check the convention reproduces training rows
bad=sum(1 for t in T if t['family']=='miller-schupp' and list(map(tuple,ms(t['n'],t['w_vector'])))!=list(map(tuple,t['initial_relators'])))
print("training MS rows reproduced by formula: mismatches",bad, "of", sum(t['family']=='miller-schupp' for t in T))
W={tuple(t['w_vector']) for t in T if t['family']=='miller-schupp'}
known=collections.defaultdict(set)
for t in T:
    if t['family']=='miller-schupp': known[tuple(t['w_vector'])].add(t['n'])
K={}
for w in W:
    for n in range(1,13):
        K.setdefault(key(*ms(n,list(w))),[]).append((n,w))
out=[]; hit=0
for num,cid,r in relay():
    m=K.get(key(r[0],r[1]))
    if not m:
        for tot,s,w0,w1 in best_bases(r[0],r[1],keep=8):
            m=K.get(key(w0,w1))
            if m: break
    if m: hit+=1
    out.append(dict(row=num,id=cid,ms=[(n,list(w)) for n,w in m] if m else None,training_n_for_w=sorted(known[m[0][1]]) if m else None))
print("rows identified as MS(n,w) with a training w:",hit,"/113")
c=collections.Counter((o['ms'][0][0], tuple(o['training_n_for_w'])) for o in out if o['ms'])
print("n vs training n's:",sorted(c.items())[:20])
json.dump(out,open('ms_identification.json','w'))
