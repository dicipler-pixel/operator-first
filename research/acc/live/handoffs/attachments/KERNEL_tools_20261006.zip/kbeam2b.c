// SCRIPT: KERNEL-BEAM-02b (hash fix: letters +3 so X=-1 no longer equals the 0xff separator)  was KERNEL-BEAM-02 (total-length cap + profile)  beam search over official AC moves (ac-r2-v1), letters 1=x,-1=X,2=y,-2=Y
// usage: kbeam W DEPTH MAXLEN HMODE SEED r0 r1   (r0/r1 as strings over xXyY)
// HMODE 0: score = total length ; HMODE 1: score = 4*cyclic_len_sum + total length
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MAXW 128
typedef struct { int8_t a[MAXW], b[MAXW]; uint8_t la, lb; } St;
static int MAXLEN; static int TOTCAP;
static void red(int8_t *w, int *n){ int8_t o[2*MAXW+4]; int k=0; for(int i=0;i<*n;i++){ if(k&&o[k-1]==-w[i]) k--; else o[k++]=w[i]; } memcpy(w,o,k); *n=k; }
// apply move m to state s -> t ; return 0 if exceeds MAXLEN
static int app(const St*s,int m,St*t){
  int8_t buf[4*MAXW]; int n=0; const int8_t *r0=s->a,*r1=s->b; int l0=s->la,l1=s->lb;
  *t=*s;
  int which = (m==0||m==2||m==3||(m>=6&&m<=9))?0:1;
  const int8_t *w = which?r1:r0; int lw= which?l1:l0; const int8_t *o= which?r0:r1; int lo= which?l0:l1;
  if(m==0||m==1){ for(int i=lw-1;i>=0;i--) buf[n++]=-w[i]; }
  else if(m==2||m==4){ memcpy(buf,w,lw); n=lw; memcpy(buf+n,o,lo); n+=lo; }
  else if(m==3||m==5){ memcpy(buf,w,lw); n=lw; for(int i=lo-1;i>=0;i--) buf[n++]=-o[i]; }
  else { int g; int k=(m-6)%4; // 6:x r x^-1 ;7: x^-1 r x ; 8: y r y^-1 ; 9: y^-1 r y (same for 10..13)
    g = (k<2)?1:2; int s1 = (k%2==0)? g : -g;
    buf[n++]=s1; memcpy(buf+n,w,lw); n+=lw; buf[n++]=-s1; }
  red(buf,&n); if(n>MAXLEN) return 0; if(n + (which? s->la : s->lb) > TOTCAP) return 0;
  if(which){ memcpy(t->b,buf,n); t->lb=n; } else { memcpy(t->a,buf,n); t->la=n; }
  return 1;
}
static int cyc(const int8_t*w,int n){ int i=0,j=n-1; while(i<j && w[i]==-w[j]){i++;j--;} return j-i+1<0?0:j-i+1; }
static uint64_t hs(const St*s){ uint64_t h=1469598103934665603ULL; for(int i=0;i<s->la;i++){h^=(uint8_t)(s->a[i]+3);h*=1099511628211ULL;} h^=0xff; h*=1099511628211ULL; for(int i=0;i<s->lb;i++){h^=(uint8_t)(s->b[i]+3);h*=1099511628211ULL;} return h?h:1; }
// visited set
static uint64_t *V; static uint64_t VM;
static int vins(uint64_t h){ uint64_t i=h&VM; while(V[i]){ if(V[i]==h) return 0; i=(i+1)&VM;} V[i]=h; return 1; }
typedef struct { int score; uint32_t rnd; int idx; } Key;
static int kc(const void*x,const void*y){ const Key*a=x,*b=y; if(a->score!=b->score) return a->score-b->score; return (a->rnd>b->rnd)-(a->rnd<b->rnd); }
static uint32_t rs=12345; static uint32_t rnd(){ rs^=rs<<13; rs^=rs>>17; rs^=rs<<5; return rs; }
static void parse(const char*s,int8_t*w,uint8_t*n){ int k=0; for(;*s;s++) w[k++]= *s=='x'?1:*s=='X'?-1:*s=='y'?2:-2; *n=k; }
int main(int argc,char**argv){
  int W=atoi(argv[1]), D=atoi(argv[2]); TOTCAP=atoi(argv[3]); MAXLEN=MAXW-1; int H=atoi(argv[4]); rs=atoi(argv[5])*2654435761u+1;
  if(MAXLEN>MAXW) MAXLEN=MAXW;
  St s0; memset(&s0,0,sizeof s0); parse(argv[6],s0.a,&s0.la); parse(argv[7],s0.b,&s0.lb);
  VM=(1ULL<<26)-1; V=calloc(VM+1,8);
  St *cur=malloc(sizeof(St)*W), *nxt=malloc(sizeof(St)*W*14); int nc=1; cur[0]=s0; vins(hs(&s0));
  uint32_t *par=malloc(sizeof(uint32_t)*(size_t)W*D); uint8_t *mv=malloc((size_t)W*D); // per layer: parent idx and move
  uint32_t *npar=malloc(4*(size_t)W*14); uint8_t *nmv=malloc((size_t)W*14); Key *K=malloc(sizeof(Key)*W*14);
  int best=s0.la+s0.lb; static short pmin[5000],pmax[5000]; int dl=0; int maxseen=s0.la+s0.lb;
  for(int d=0; d<D; d++){
    int nn=0;
    for(int i=0;i<nc;i++) for(int m=0;m<14;m++){ St t; if(!app(&cur[i],m,&t)) continue; uint64_t h=hs(&t); if(!vins(h)) continue;
        nxt[nn]=t; npar[nn]=i; nmv[nn]=m; int L=t.la+t.lb; int sc= H==2? -L : (H? 4*(cyc(t.a,t.la)+cyc(t.b,t.lb))+L : L);
        K[nn].score=sc; K[nn].rnd=rnd(); K[nn].idx=nn; nn++;
        if(t.la==1&&t.lb==1&&t.a[0]==1&&t.b[0]==2){ // solved: reconstruct
          int path[4096]; int pl=0; path[pl++]=m; int p=i;
          for(int e=d-1;e>=0;e--){ path[pl++]=mv[(size_t)e*W+p]; p=par[(size_t)e*W+p]; }
          printf("SOLVED depth %d : [",pl); for(int q=pl-1;q>=0;q--) printf("%d%s",path[q],q?", ":""); printf("]\n"); return 0; }
      }
    if(!nn){ printf("DEADEND depth %d best %d maxseen %d\n",d,best,maxseen); return 1; }
    int keep = nn<W?nn:W;
    if(nn>W) qsort(K,nn,sizeof(Key),kc); // full sort fine for moderate W
    for(int j=0;j<keep;j++){ int id=K[j].idx; cur[j]=nxt[id]; par[(size_t)d*W+j]=npar[id]; mv[(size_t)d*W+j]=nmv[id]; int L=cur[j].la+cur[j].lb; if(L<best) best=L; }
    { int mn=999,mx=0; for(int j=0;j<keep;j++){int L=cur[j].la+cur[j].lb; if(L<mn)mn=L; if(L>mx)mx=L;} pmin[d]=mn; pmax[d]=mx; dl=d+1; if(mx>maxseen)maxseen=mx; }
    nc=keep;
  }
  printf("NOSOL depth %d best %d maxseen %d PROFILE",D,best,maxseen); for(int q=0;q<dl;q+=10) printf(" %d-%d",pmin[q],pmax[q]); printf("\n"); return 1;
}
