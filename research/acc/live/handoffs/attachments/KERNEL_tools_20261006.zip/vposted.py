import json,sys
sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from load import pool
P=pool()
posted=[l for l in open('posted3.txt') if l.startswith('ac-')]
saved=set()
for f in ('join_ac-03871.json','join_ac-10098.json'):
    d=json.load(open(f))
    for cid,v in d.items():
        items=v if isinstance(v,list) else v.get('routes',v)
        for r in items:
            mv=r['moves'] if isinstance(r,dict) else r
            saved.add((cid,tuple(mv)))
def ok(cid,mv):
    r0,r1=P[cid]; st=(tuple(r0),tuple(r1))
    for m in mv: st=core.apply_move(st,m)
    return st==((1,),(2,))
for l in posted:
    cid,rest=l.split(':',1); mv=json.loads(rest)
    print(cid,len(mv),'official_ok' if ok(cid,mv) else 'FAIL','in_saved' if (cid,tuple(mv)) in saved else 'NOT_IN_SAVED')
print('saved routes:',sorted((c,len(m)) for c,m in saved))
