# SCRIPT: KERNEL-HARVEST-01  collect every move list Kernel holds (txt + json), replay each on the official core for its row:
#   ends at (x,y) -> AC road; ends at (y,x) -> (y,x) road (Stable line = road + [15,15]); sac lines checked with stable_core.
#   Team-supplied roads (teampool, prio_roads, pools, teamD, s2paths, relay) are excluded unless Kernel made them shorter.
import sys,os,re,json,glob
sys.path.insert(0,'../acc/competition/tools')
from verifier import core, stable_core as S
L={'x':1,'y':2}
P={}
for l in open('../acc/competition/problems/ac.jsonl'):
    d=json.loads(l); m=re.search(r'<x, y \| (.*?) = 1; (.*?) = 1>',d['description'])
    def w(s): return core.free_reduce(tuple((-L[t[0]] if t.endswith('^-1') else L[t]) for t in s.split()))
    P[d['challenge_id']]=(w(m.group(1)),w(m.group(2)))
GOAL=((1,),(2,)); YX=((2,),(1,))
team_files={'teampool.txt','prio_roads.txt','teamD.txt','pool1.txt','pool2.txt','pool3.txt','pool4.txt','s2paths.txt','relay.txt'}
cands=set()
def add(cid,mv):
    if cid and mv and all(type(a)==int and 0<=a<=22 for a in mv) and len(mv)>=3: cands.add((cid,tuple(mv)))
for f in glob.glob('*.txt'):
    if f in team_files: continue
    for l in open(f):
        for m in re.finditer(r'(s?ac-\d{5}): \[([\d, ]+)\]',l):
            add(m.group(1),[int(v) for v in m.group(2).split(',')])
def walk(o,cid):
    if isinstance(o,dict):
        for k,v in o.items():
            c=cid
            if isinstance(k,str) and re.fullmatch(r's?ac-\d{5}',k): c=k
            if isinstance(k,str) and re.fullmatch(r'[\d ]+',k) and ' ' in k: add(c,[int(t) for t in k.split()])
            if k=='cid' and isinstance(v,str): c=v
            walk(v,c if not (isinstance(o.get('cid'),str)) else o['cid'])
    elif isinstance(o,list):
        if o and all(type(a)==int for a in o): add(cid,o)
        else:
            for v in o: walk(v,cid)
for f in glob.glob('*.json'):
    if f.startswith('song9') or 'rules' in f or f.startswith('goal'): continue
    try: walk(json.load(open(f)),None)
    except Exception as e: pass
team=set()
for f in team_files:
    if os.path.exists(f):
        for l in open(f):
            m=re.match(r'(ac-\d+): \[(.*?)\]',l)
            if m: team.add(('ac-'+m.group(1)[3:],tuple(int(v) for v in m.group(2).split(','))))
ac={};yx={};sac={}
for cid,mv in cands:
    base='ac-'+cid.split('-')[1]
    if base not in P: continue
    s0=P[base]
    if cid.startswith('sac'):
        st=s0;ok=True
        for m in mv:
            st,e=S.apply_move(st,m)
            if st is None: ok=False;break
        if ok and st==(): sac.setdefault(base,set()).add(mv)
        continue
    if max(mv)>13: continue
    st=s0
    for m in mv: st=core.apply_move(st,m)
    if st==GOAL and (base,mv) not in team: ac.setdefault(base,set()).add(mv)
    elif st==YX: yx.setdefault(base,set()).add(mv)
na=sum(len(v) for v in ac.values()); ny=sum(len(v) for v in yx.values()); ns=sum(len(v) for v in sac.values())
print('candidates',len(cands),'AC roads',na,'rows',len(ac),'| YX roads',ny,'rows',len(yx),'| sac lines',ns,'rows',len(sac))
json.dump({'ac':{k:sorted(map(list,v),key=len) for k,v in ac.items()},'yx':{k:sorted(map(list,v),key=len) for k,v in yx.items()},'sac':{k:sorted(map(list,v),key=len) for k,v in sac.items()}},open('harvest.json','w'))
