# SCRIPT: KERNEL-WSTAR3-01  n=3 MS_3(w*) line: exact one-sided path (r1 fixed) + finish BFS + transfer to each pool row + official replay
import sys,collections,json; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from msid import ms
from onesided import cls, TGT, MOVES
from load import pool
from wstar_ids import IDS
def onesided_path(n,cap):
    r0,r1=map(tuple,ms(n,[-2,1,2,-1])); par={r0:None}; fr=[r0]
    while fr:
        nx=[]
        for w in fr:
            for m in MOVES:
                t=core.apply_move((w,r1),m)[0]
                if len(t)>cap or t in par: continue
                par[t]=(w,m)
                if cls(t)==TGT:
                    p=[]; u=t
                    while par[u]: u,mm=par[u]; p.append(mm)
                    return (r0,r1),p[::-1]
                nx.append(t)
        fr=nx
def bfs_to(st,goal_test,cap,limit=3_000_000,moves=range(14)):
    par={st:None}; q=collections.deque([st])
    if goal_test(st): return []
    while q:
        s=q.popleft()
        for m in moves:
            t=core.apply_move(s,m)
            if len(t[0])+len(t[1])>cap or t in par: continue
            par[t]=(s,m)
            if goal_test(t):
                p=[]; u=t
                while par[u]: u,mm=par[u]; p.append(mm)
                return p[::-1]
            q.append(t)
        if len(par)>limit: return None
    return None
def replay(st,mv):
    for m in mv: st=core.apply_move(st,m)
    return st
# ---- model path for exact MS_3(w*)
start,p1=onesided_path(3,16)
mid=replay(start,p1)
fin=bfs_to(mid,lambda s:s==((1,),(2,)),len(mid[0])+len(mid[1])+6)
model=p1+fin
assert replay(start,model)==((1,),(2,))
print("model MS_3(w*): one-sided",len(p1),"+ finish",len(fin),"=",len(model))
# ---- transfer onto a pool row
AUTS=[]
for sw in (0,1):
    for sx in (1,-1):
        for sy in (1,-1):
            AUTS.append((sw,sx,sy))
def fl(c,a):
    sw,sx,sy=a; g=abs(c); s=1 if c>0 else -1
    if sw: g=3-g
    return s*(sx if g==1 else sy)*g
LET2CONJ={1:0,-1:1,2:2,-2:3}; GEN=(1,-1,2,-2)
def map_move(m,a,swap):
    if m<=5:
        if not swap: return m
        return {0:1,1:0,2:4,3:5,4:2,5:3}[m]
    which=0 if m<=9 else 1; l=GEN[(m-6)%4]; l2=fl(l,a); w2=(1-which) if swap else which
    return 6+4*w2+LET2CONJ[l2]
def transfer(row):
    R=(tuple(row[0]),tuple(row[1])); best=None
    for a in AUTS:
        for swap in (0,1):
            M=(tuple(fl(c,a) for c in start[0]), tuple(fl(c,a) for c in start[1]))
            if swap: M=(M[1],M[0])
            if cls(R[0])!=cls(M[0]) or cls(R[1])!=cls(M[1]): continue
            pre=bfs_to(R,lambda s:s==M,len(R[0])+len(R[1])+8,moves=(0,1,6,7,8,9,10,11,12,13))
            if pre is None: continue
            body=[map_move(m,a,swap) for m in model]
            endst=replay(replay(R,pre),body)
            fin2=bfs_to(endst,lambda s:s==((1,),(2,)),12)
            if fin2 is None: continue
            line=pre+body+fin2
            if replay(R,line)==((1,),(2,)) and (best is None or len(line)<len(best)): best=line
    return best
P=pool(); out=[]
for cid,n in IDS:
    if n!=3: continue
    line=transfer(P[cid])
    ok = line is not None and replay((tuple(P[cid][0]),tuple(P[cid][1])),line)==((1,),(2,))
    print(cid, "len", None if line is None else len(line), "official core ok:", ok)
    if ok: out.append((cid,line))
json.dump(out,open('wstar3_lines.json','w'))
