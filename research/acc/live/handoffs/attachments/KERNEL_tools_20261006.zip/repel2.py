# SCRIPT: KERNEL-REPEL-02  deep repelled beams -> new-lineage roads, exact-shortened, appended to repelroads.txt
import sys,re,subprocess,os,time
sys.argv_saved=sys.argv[:]; cid=sys.argv[1]; rec=int(sys.argv[2]); sys.argv=['x']
from shortcut import shorten
sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from load import pool
S={1:'x',-1:'X',2:'y',-2:'Y'}; P=pool(); G=((1,),(2,))
start=(tuple(P[cid][0]),tuple(P[cid][1])); w0=''.join(S[c] for c in start[0]); w1=''.join(S[c] for c in start[1])
seen=set()
for W in (10000,40000,100000):
  for pen in (0,3,6,12,24):
    for H in (0,1):
      env=dict(os.environ,ROADFILE=f'tube_{cid}_2.txt',REPEL=str(pen)); t0=time.time()
      o=subprocess.run(['./kbeam5',str(W),str(rec+25),str(len(w0)+len(w1)+60),str(H),'1',w0,w1],capture_output=True,text=True,env=env).stdout
      m=re.search(r'SOLVED depth (\d+) : \[(.*)\]',o)
      if not m: print(cid,W,pen,H,'none',f'{time.time()-t0:.0f}s',flush=True); continue
      mv=[int(v) for v in m.group(2).split(',')]
      if tuple(mv) in seen: print(cid,W,pen,H,'dup',len(mv),flush=True); continue
      seen.add(tuple(mv))
      s=shorten(start,mv) if len(mv)<=rec+30 else mv; t=start
      for x in s: t=core.apply_move(t,x)
      if t!=G: s=mv
      t=start
      for x in s: t=core.apply_move(t,x)
      flag='TIE' if len(s)==rec else ('BEAT' if len(s)<rec else '+%d'%(len(s)-rec))
      print(cid,W,pen,H,'SOLVED',len(mv),'->',len(s),flag,'ok',t==G,f'{time.time()-t0:.0f}s',flush=True)
      if t==G: open('repelroads.txt','a').write(f"{cid}: {list(s)}\n")
