# SCRIPT: KERNEL-JOIN-01  new roads joined to the team road of each row:
#   FORWARD: kernel beam from the official start until it lands EXACTLY on a team-road state S_k (k >= K), then the team suffix.
#   BACKWARD: team prefix to S_k, then kernel beam from S_k to (x,y).
#   Every route: official replay, exact radius-4 shortening, dedupe.
import sys,re,json,subprocess,time,os; sys.path.insert(0,'.'); sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from load import pool
from shortcut import shorten
from hsh import hs
S={1:'x',-1:'X',2:'y',-2:'Y'}
P=pool()
def ok(st,mv):
    for m in mv: st=core.apply_move(st,m)
    return st==((1,),(2,))
def run(binary,st,W,H,seed,env=None,D=300):
    out=subprocess.run([binary,str(W),str(D),str(len(st[0])+len(st[1])+60),str(H),str(seed),''.join(S[c] for c in st[0]),''.join(S[c] for c in st[1])],capture_output=True,text=True,env=env).stdout
    m=re.search(r'\[(.*)\]',out); return [int(v) for v in m.group(1).split(',')] if m else None
def join_row(cid,road):
    start=(tuple(P[cid][0]),tuple(P[cid][1])); states=[start]
    for m in road: states.append(core.apply_move(states[-1],m))
    L=len(road); routes={}
    def add(tag,mv):
        if mv and ok(start,mv):
            sh=shorten(start,mv); sh=sh if ok(start,sh) else mv
            if tuple(sh)!=tuple(road): routes.setdefault(tuple(sh),tag)
    fn=f'road_{cid}.txt'
    for K in range(2,L-1,3):                      # forward joins onto the later part of the road
        idx={hs(states[k]):k for k in range(K,L)}
        open(fn,'w').write("\n".join(str(h) for h in idx)+"\n")
        env=dict(os.environ,ROADFILE=fn)
        for H,seed in ((0,1),(1,2),(0,3)):
            mv=run('./kbeam4',start,2000,H,seed,env)
            if not mv: continue
            s=start
            for m in mv: s=core.apply_move(s,m)
            k=idx.get(hs(s))
            if k is not None: add(f'fwd K{K} H{H} s{seed} -> S{k}',mv+road[k:])
    for k in range(4,L-3,4):                      # backward: team prefix, kernel finish
        for H,seed in ((0,1),(1,2)):
            mv=run('./kbeam2',states[k],2000,H,seed)
            if mv: add(f'bwd S{k} H{H} s{seed}',road[:k]+mv)
    return routes
if __name__=='__main__':
    paths={}
    for line in open('allp.txt'):
        m=re.match(r'(ac-\d+): \[(.*?)\]',line)
        if m: paths[m.group(1)]=[int(v) for v in m.group(2).split(',')]
    todo=[c for c in sys.argv[1].split(',') if c in paths]
    res={}
    for cid in todo:
        t0=time.time(); R=join_row(cid,paths[cid])
        print(f"{cid} team road {len(paths[cid])}: joined routes {len(R)}, lengths {sorted(len(k) for k in R)} ({time.time()-t0:.0f}s)",flush=True)
        res[cid]={' '.join(map(str,k)):v for k,v in R.items()}
        json.dump(res,open(f'join_{todo[0]}.json','w'))
