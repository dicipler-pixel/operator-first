# SCRIPT: KERNEL-DRIVE-01  run kbeam over a set of (id, r0, r1) in parallel; replay every path with the official core
import sys, json, subprocess, re, time
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'/tmp/claude-0/-home-claude/d6401873-8fe2-504f-bece-cf137876747f/scratchpad/acc/competition/tools')
from verifier import core
S={1:'x',-1:'X',2:'y',-2:'Y'}
def official_ok(r0,r1,moves):
    st=(tuple(r0),tuple(r1))
    for m in moves: st=core.apply_move(st,m)
    return tuple(tuple(w) for w in st)==((1,),(2,))
def run_one(args):
    cid,r0,r1,W,D,ML,H,seed=args
    t=time.time()
    out=subprocess.run(['./kbeam',str(W),str(D),str(ML),str(H),str(seed),''.join(S[c] for c in r0),''.join(S[c] for c in r1)],capture_output=True,text=True).stdout.strip()
    m=re.search(r'\[(.*)\]',out); moves=[int(v) for v in m.group(1).split(',')] if m else None
    ok= official_ok(r0,r1,moves) if moves else None
    return dict(id=cid,W=W,D=D,maxlen=ML,H=H,seed=seed,out=out.split(':')[0],moves=moves,official_ok=ok,secs=round(time.time()-t,2))
def run_all(items,W,D,ML,H,seed=1,workers=2):
    with ThreadPoolExecutor(workers) as ex: return list(ex.map(run_one,[(c,a,b,W,D,ML,H,seed) for c,a,b in items]))
