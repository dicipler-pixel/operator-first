# SCRIPT: KERNEL-PRIO5-02 (rerun 2: + UPG-H 11:18Z priority roads, 429 roads all replayed)  (memory-lean: radius-5 balls kept as hash->dist, bridge moves rebuilt lazily; 01 was OOM-killed at 6 GB)
# was KERNEL-PRIO5-01  radius-5 spine bridges on the gap-1 priority rows.
#   Graph = every known road (steps of 1) + radius-4 bridges between ANY two road nodes (as KERNEL-WEB) + radius-5 balls around
#   the SPINE (nodes of the current best XY and YX paths, plus GOAL and YX): spine-to-any-node bridges up to 5 and
#   spine-to-spine bridges up to 10 (two radius-5 balls meeting). Dijkstra to GOAL and YX.
#   Why it proves what it claims: every bridge is a concrete move list (ball trace + inverted trace); the final path is replayed
#   move by move on verifier.core inside back(); hits are re-checked with the official CLI before posting.
import sys,json,heapq,time
src=open('web2.py').read().split("if __name__=='__main__':")[0].replace("'teampool.txt']","'teampool.txt','scan_ac.txt','scan4_ac.txt','scan4b_ac.txt','scan5_ac.txt','prio_roads.txt']")
exec(src)
exec(open('hsh2.py').read())
pr=json.load(open('prio2_R4.json')); pg=json.load(open('prio2_goal.json'))
rows=json.load(open('prio_rows.json'))
need={}
for name,ours,rec in rows:
    ac='ac-'+name.split('-')[1]; need.setdefault(ac,{})['sac' if name.startswith('s') else 'ac']=int(rec)
def have(c):
    xy=min(x for x in [pr[c]['xy'],pg[c]['xy'],999] if x); yx=min(x for x in [pr[c]['yx'],pg[c]['yx'],999] if x)
    return xy,yx
order=[]
for c,tg in need.items():
    if c not in pr or pr[c].get('xy') is None: continue
    xy,yx=have(c)
    g=min([xy-tg['ac']] if 'ac' in tg else [99]+[])
    if 'sac' in tg: g=min(g,min(xy,yx)+2-tg['sac'])
    order.append((g,c))
order.sort()
fn='prio2_5.json'
try: out=json.load(open(fn))
except Exception: out={}
for g,c in order:
    if g>1: break
    if c in out: continue
    t0=time.time()
    st0,roads=roads_for(c)
    extra=[m for m in (pr[c]['xy_moves'],pg[c]['xy_moves']) if m]
    roads=roads+extra
    yxp=[m for m in (pr[c]['yx_moves'],pg[c]['yx_moves']) if m]
    adj={}
    def add(u,v,w,mv):
        e=adj.setdefault(u,{})
        if v not in e or e[v][0]>w: e[v]=(w,mv)
    nodes=set([st0,GOAL,YX])
    for r in roads+yxp:
        s=st0
        for m in r:
            t=core.apply_move(s,m); add(s,t,1,[m]); add(t,s,1,[INV[m]]); nodes.add(t); s=t
    nodes=list(nodes)
    balls={u:ball(u,4) for u in nodes}
    meet={}
    for u in nodes:
        for w,(d,_,_) in balls[u].items(): meet.setdefault(w,[]).append((d,u))
    def bridges(meet,balls):
        for w,L in meet.items():
            if len(L)<2: continue
            for du,u in L:
                for dv,v in L:
                    if u==v: continue
                    tot=du+dv
                    e=adj.get(u,{})
                    if v in e and e[v][0]<=tot: continue
                    add(u,v,tot,trace(balls[u],w)+[INV[m] for m in reversed(trace(balls[v],w))])
    bridges(meet,balls); del meet
    del balls
    spine=set([st0,GOAL,YX])
    for p in [pr[c]['xy_moves'],pg[c]['xy_moves'],pr[c]['yx_moves'],pg[c]['yx_moves']]:
        if not p: continue
        s=st0
        for m in p: s=core.apply_move(s,m); spine.add(s)
    spine=list(spine)
    nh={hs(v):v for v in nodes}
    meet={}
    for i,u in enumerate(spine):
        B=ball(u,5)
        for w,(d,_,_) in B.items():
            h=hs(w)
            if h in nh:
                v=nh[h]
                if v!=u:
                    mv=trace(B,w); add(u,v,d,mv); add(v,u,d,[INV[m] for m in reversed(mv)])
            L=meet.get(h)
            if L is None: meet[h]=d*1024+i
            elif type(L) is int: meet[h]=[L,d*1024+i]
            else: L.append(d*1024+i)
        del B
    lazy={}
    for h,L in meet.items():
        if type(L) is int: continue
        for a in L:
            for b in L:
                da,ia=divmod(a,1024); db,ib=divmod(b,1024)
                if ia==ib: continue
                u,v=spine[ia],spine[ib]; tot=da+db
                e=adj.get(u,{})
                if v in e and e[v][0]<=tot: continue
                add(u,v,tot,('lazy',ia,ib,h))
    del meet
    dist={st0:0}; prev={}; pq=[(0,0,st0)]; k=0
    while pq:
        d,_,u=heapq.heappop(pq)
        if d>dist.get(u,1e9): continue
        for v,(w,mv) in adj.get(u,{}).items():
            if d+w<dist.get(v,1e9): dist[v]=d+w; prev[v]=(u,mv); k+=1; heapq.heappush(pq,(d+w,k,v))
    def expand(mv):
        if type(mv) is list: return mv
        _,ia,ib,h=mv
        Ba=ball(spine[ia],5); Bb=ball(spine[ib],5)
        w=next(x for x in Ba if hs(x)==h and x in Bb)
        return trace(Ba,w)+[INV[m] for m in reversed(trace(Bb,w))]
    def back(g):
        if g not in dist: return None
        p=[]; u=g
        while u!=st0: pu,mv=prev[u]; p=expand(mv)+p; u=pu
        s=st0
        for m in p: s=core.apply_move(s,m)
        return p if s==g else None
    px=back(GOAL); py=back(YX)
    tg=need[c]; hit=[]
    if 'ac' in tg and px and len(px)<=tg['ac']: hit.append(f"{c}: {px}")
    if 'sac' in tg:
        cand=[m+[16,15] for m in [px] if m]+[m+[15,15] for m in [py] if m]
        if cand:
            b=min(cand,key=len)
            if len(b)<=tg['sac']: hit.append(f"s{c}: {b}")
    out[c]={'need':tg,'xy':len(px) if px else None,'yx':len(py) if py else None,'xy_moves':px,'yx_moves':py,'spine':len(spine),'nodes':len(nodes)}
    print(c,'need',tg,'R5spine xy',out[c]['xy'],'yx',out[c]['yx'],'was',have(c),'nodes',len(nodes),'spine',len(spine),round(time.time()-t0),'s','HIT' if hit else '',flush=True)
    if hit: open('prio2_hits.txt','a').write('\n'.join(hit)+'\n')
    json.dump(out,open(fn,'w'))
    del adj
print('done',len(out))
