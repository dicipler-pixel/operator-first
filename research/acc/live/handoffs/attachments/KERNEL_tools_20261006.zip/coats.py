# SCRIPT: KERNEL-COATS-01  every state ("coat") along the certificates the ms14 repo left, matched against the whole pool and the known solved roads
import sys,json,glob,collections; sys.path.insert(0,'.'); sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from classes import key
from load import pool
from knownset import khash
P=pool()
PK=collections.defaultdict(list)
for cid,r in P.items(): PK[key(r[0],r[1])].append(cid)
known=set(int(h) for h in json.load(open('known_table.json')))
CONJ={(0,1):6,(0,-1):7,(0,2):8,(0,-2):9,(1,1):10,(1,-1):11,(1,2):12,(1,-2):13}
MUL={(0,1,1):2,(0,1,-1):3,(1,0,1):4,(1,0,-1):5}
def expand(C):
    st=tuple(map(tuple,C['initial'])); yield st
    for o in C['moves']:
        if o[0]=='cycle':
            i,k=o[1],o[2]; w=st[i]; k%=max(1,len(w))
            for c in w[:k]: st=core.apply_move(st,CONJ[(i,-c)]); yield st
            continue
        m = o[1] if o[0]=='invert' else CONJ[(o[1],o[2])] if o[0]=='conj' else MUL[(o[1],o[2],o[3])]
        st=core.apply_move(st,m); yield st
links=collections.defaultdict(set); report=[]
for f in sorted(glob.glob('../ms14/certs/*.json')+glob.glob('../ms14/certs/*/*.json')):
    C=json.load(open(f)); rows=set(); roads=0; n=0
    for st in expand(C):
        n+=1
        if len(st[0])+len(st[1])<=2: continue
        k=key(list(st[0]),list(st[1]))
        for cid in PK.get(k,[]): rows.add(cid)
        if khash(k) in known: roads+=1
    report.append((f.split('certs/')[1],n,sorted(rows),roads))
    for a in rows:
        for b in rows:
            if a!=b: links[a].add(b)
for r in report: print(f"{r[0]:45s} states {r[1]:5d}  pool rows met: {r[2]}  known-road states met: {r[3]}")
# clusters
seen=set(); 
for a in links:
    if a in seen: continue
    comp=set(); st=[a]
    while st:
        u=st.pop()
        if u in comp: continue
        comp.add(u); st+=list(links[u])
    seen|=comp; print("CLUSTER:",sorted(comp))
