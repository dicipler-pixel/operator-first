# SCRIPT: KERNEL-YXLOOP-01  per row, repeat the radius-R web, feeding each new shortest XY road back in, until no gain.
#   Also feeds the YX road back as a node path (it ends at (y,x), not goal, so it only adds nodes via extra_nodes).
#   Resumable: yxloop_R{R}.json. Every path is replayed on verifier.core by back(); final lines re-checked by official CLI.
import sys,json
src=open('web2.py').read().split("if __name__=='__main__':")[0].replace("'teampool.txt']","'teampool.txt','scan_ac.txt','scan4_ac.txt','scan4b_ac.txt']")
exec(src)
EXTRA={}
_rf=roads_for
def roads_for(cid):
    st0,good=_rf(cid)
    return st0,good+[list(r) for r in EXTRA.get(cid,[])]
Rb=int(sys.argv[1]) if len(sys.argv)>1 else 4
R=json.load(open('scan_rows.json'))
fn=f'yxloop_R{Rb}.json'
try: out=json.load(open(fn))
except Exception: out={}
for c,team,xy3,yx3,s in R:
    if c in out: continue
    hist=[]; best=None
    for it in range(8):
        r=web(c,Rb)
        hist.append((r['web'],r['yx']))
        if best is None or (r['web'] or 999)<(best['web'] or 999) or (r['yx'] or 999)<(best['yx'] or 999):
            if best is None: best=dict(r)
            if (r['web'] or 999)<=(best['web'] or 999): best['web'],best['moves']=r['web'],r['moves']
            if (r['yx'] or 999)<=(best['yx'] or 999): best['yx'],best['yx_moves']=r['yx'],r['yx_moves']
            if r['moves']: EXTRA.setdefault(c,set()).add(tuple(r['moves']))
            if it>0 and hist[-1]==hist[-2]: break
        else: break
    out[c]={'team':team,'xy':best['web'],'yx':best['yx'],'xy_moves':best['moves'],'yx_moves':best['yx_moves'],'hist':hist}
    print(c,'team',team,'hist',hist,flush=True)
    json.dump(out,open(fn,'w'))
print('done',len(out))
