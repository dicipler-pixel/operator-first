# SCRIPT: KERNEL-LEVELSTEP-02  level step with target = all rotations/inversions/swap of P_(m-1) (both w forms)
import sys; sys.path.insert(0,'.')
from levelstep import *
extra=int(sys.argv[1]); lim=int(sys.argv[2])
for m in (4,5):
    s=P(m,W1); tg=set()
    for w in (W1,W2): tg|=variants(P(m-1,w))
    cap=len(s[0])+len(s[1])+extra
    path=mitm(s,list(tg),cap,maxd=30,limit=lim)
    print("m=%d cap %d targets %d -> %s"%(m,cap,len(tg),path),flush=True)
    if path: print("  lands:",replay(s,path),"in targets:",replay(s,path) in tg)
