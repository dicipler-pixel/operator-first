# SCRIPT: KERNEL-BASIS-01  Nielsen change of basis: find a short basis, translate basis paths to official letter moves, finish to (x,y)
import sys, itertools, collections
sys.path.insert(0,'/tmp/claude-0/-home-claude/d6401873-8fe2-504f-bece-cf137876747f/scratchpad/acc/competition/tools')
from verifier import core
def red(w):
    o=[]
    for c in w:
        if o and o[-1]==-c: o.pop()
        else: o.append(c)
    return o
def inv(w): return [-c for c in reversed(w)]
def sub(w,m):  # m: {1:word,2:word}
    out=[]
    for c in w: out+= m[abs(c)] if c>0 else inv(m[abs(c)])
    return red(out)
# a basis is (U, V): U = letter words of new generators a,b ; V = x,y written in a,b
def nielsen_neighbours(U,V):
    a,b=U; xa,yb=V  # V[0]=x in (a,b), V[1]=y in (a,b)
    res=[]
    # each elementary Nielsen move on (a,b); update the inverse by substituting old generators in terms of new ones
    moves=[ # (new a, new b in terms of old a=1,b=2) and (old a, old b in terms of new a,b)
      ([1,2],[2],  [1,-2],[2]), ([1,-2],[2], [1,2],[2]), ([2,1],[2], [-2,1],[2]), ([-2,1],[2], [2,1],[2]),
      ([1],[2,1],  [1],[2,-1]), ([1],[2,-1], [1],[2,1]), ([1],[1,2], [1],[-1,2]), ([1],[-1,2], [1],[1,2]),
      ([-1],[2],   [-1],[2]), ([1],[-2], [1],[-2]), ([2],[1], [2],[1]) ]
    for na,nb,oa,ob in moves:
        U2=(sub(na,{1:a,2:b}), sub(nb,{1:a,2:b}))
        V2=(sub(xa,{1:oa,2:ob}), sub(yb,{1:oa,2:ob}))
        res.append((tuple(U2[0]),tuple(U2[1]),tuple(V2[0]),tuple(V2[1])))
    return res
def best_bases(r0,r1,depth=3,keep=5):
    start=((1,),(2,),(1,),(2,)); seen={start}; frontier=[start]; cand=[]
    for d in range(depth):
        nxt=[]
        for s in frontier:
            for t in nielsen_neighbours((list(s[0]),list(s[1])),(list(s[2]),list(s[3]))):
                if t in seen: continue
                seen.add(t); nxt.append(t)
        frontier=nxt
    for s in seen:
        m={1:list(s[2]),2:list(s[3])}; w0=sub(r0,m); w1=sub(r1,m)
        cand.append((len(w0)+len(w1), s, w0, w1))
    cand.sort(key=lambda c:(c[0],sum(len(x) for x in c[1][:2])))
    return cand[:keep]
LETTERMOVE={1:6,-1:7,2:8,-2:9}   # conjugate r0 by letter l
def translate(path, U):
    a,b=list(U[0]),list(U[1]); gen={1:a,-1:inv(a),2:b,-2:inv(b)}
    out=[]
    for m in path:
        if m<=5: out.append(m); continue
        which=0 if m<=9 else 1; k=(m-6)%4; g=[1,-1,2,-2][k]
        w=gen[g]                         # conjugate by word w: w r w^-1 = l1(l2(...(lk r lk^-1)...))
        for l in reversed(w): out.append(LETTERMOVE[l]+4*which)
    return out
def replay(r0,r1,moves):
    st=(tuple(r0),tuple(r1))
    for m in moves: st=core.apply_move(st,m)
    return st
def finish(st,maxd=10):
    # BFS in letters from a short state to exactly ((1,),(2,))
    tgt=((1,),(2,)); 
    if st==tgt: return []
    par={st:None}; q=collections.deque([st])
    while q:
        s=q.popleft(); d=0; p=s
        for m in range(14):
            t=core.apply_move(s,m)
            if len(t[0])+len(t[1])>len(st[0])+len(st[1])+4 or t in par: continue
            par[t]=(s,m)
            if t==tgt:
                path=[]; u=t
                while par[u]: u,mm=par[u]; path.append(mm)
                return path[::-1]
            q.append(t)
        if len(par)>2_000_000: return None
    return None
