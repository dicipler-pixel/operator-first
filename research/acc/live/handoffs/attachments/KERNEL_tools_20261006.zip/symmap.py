# SCRIPT: KERNEL-SYMMAP-01  find pool rows that are exact symmetric images of each priority row
#   (signed generator permutations x 8, relator swap x 2, relator inversions x 4 = 64 maps, applied to the raw start state).
import sys,json,itertools,re
sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from load import pool
P=pool()
def fr(w): return core.free_reduce(tuple(w))
def maps():
    out=[]
    for perm in [(1,2),(2,1)]:
        for sx in (1,-1):
            for sy in (1,-1):
                sg={1:sx*perm[0],2:sy*perm[1]}
                f=lambda w,sg=sg: fr(tuple((sg[abs(a)] if a>0 else -sg[abs(a)]) for a in w))
                for swap in (0,1):
                    for i0 in (0,1):
                        for i1 in (0,1):
                            out.append((f,swap,i0,i1,(perm,sx,sy,swap,i0,i1)))
    return out
M=maps()
def apply(T,s):
    f,swap,i0,i1,_=T
    a,b=f(s[0]),f(s[1])
    if i0: a=core.invert(a)
    if i1: b=core.invert(b)
    return (b,a) if swap else (a,b)
idx={}
for c,(r0,r1) in P.items():
    idx.setdefault((fr(r0),fr(r1)),[]).append(c)
road_rows=set()
for f in ['teampool.txt','allp.txt','scan_ac.txt','scan4_ac.txt','scan5_ac.txt','ext_roads.txt']:
    try:
        for l in open(f):
            m=re.match(r'(ac-\d+):',l)
            if m: road_rows.add(m.group(1))
    except FileNotFoundError: pass
rows=json.load(open('prio_rows.json'))
acs=sorted(set('ac-'+n.split('-')[1] for n,_,_ in rows))
res={}
for c in acs:
    s=(fr(P[c][0]),fr(P[c][1])); imgs=set()
    for k,T in enumerate(M):
        t=apply(T,s)
        for d in idx.get(t,[]):
            if d!=c: imgs.add((d,k))
    res[c]=sorted(imgs)
json.dump(res,open('prio_sym.json','w'))
n=sum(1 for c in res if res[c]); nr=sum(1 for c in res if any(d in road_rows for d,k in res[c]))
print('rows',len(acs),'with images',n,'with images that have roads',nr)
for c in acs[:80]:
    if res[c]: print(c,[(d,k,d in road_rows) for d,k in res[c]][:6])
