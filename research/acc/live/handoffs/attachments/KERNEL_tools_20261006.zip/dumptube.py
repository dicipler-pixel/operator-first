# SCRIPT: KERNEL-DUMPTUBE-01  write hs() of every state within R of any verified road of a row
import sys,glob,re
sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from load import pool
from hsh import hs
P=pool(); GOAL=((1,),(2,)); cid=sys.argv[1]; R=int(sys.argv[2])
start=(tuple(P[cid][0]),tuple(P[cid][1])); pat=re.compile(r'^'+cid+r': \[([0-9, ]+)\]')
roads=set()
for f in glob.glob('*.txt')+glob.glob('hub/*.txt'):
    for line in open(f,errors='ignore'):
        m=pat.match(line.strip())
        if m: roads.add(tuple(int(v) for v in m.group(1).split(',')))
nodes=set()
for mv in roads:
    st=start; seq=[st]
    for m in mv: st=core.apply_move(st,m); seq.append(st)
    if st==GOAL: nodes.update(seq)
tube=set(nodes); fr=set(nodes)
for d in range(R):
    nf=set()
    for s in fr:
        for m in range(14):
            t=core.apply_move(s,m)
            if t not in tube: nf.add(t)
    tube|=nf; fr=nf
tube.discard(GOAL)
open(f'tube_{cid}_{R}.txt','w').write('\n'.join(str(hs(s)) for s in tube)+'\n')
print(cid,'roads',len(roads),'tube',len(tube))
