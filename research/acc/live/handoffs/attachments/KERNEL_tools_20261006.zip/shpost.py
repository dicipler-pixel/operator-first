# SCRIPT: KERNEL-SHPOST-01  collect new routes (cmp2 + goalball), exact radius-4 shortening, official replay, dedupe vs already-posted
import sys,json,glob,re; sys.argv=['x']; sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from shortcut import shorten
from verifier import core
from load import pool
P=pool(); REC=json.load(open('rec_bob.json'))
posted=set()
for f in ['posted3.txt','batch4.txt','batch5.txt','batch6_post.txt','roads_batch1.txt','roads_batch2.txt']:
    for l in open(f):
        m=re.match(r'(ac-\d+): \[(.*?)\]',l)
        if m: posted.add((m.group(1),tuple(int(v) for v in m.group(2).split(','))))
cand=[]
for cid,L in json.load(open('cmp2.json')).items(): cand+=[(cid,r) for r in L]
for f in glob.glob('goalball_*_R7.json'):
    for cid,L in json.load(open(f)).items(): cand+=[(cid,r) for r in L]
out={}
for cid,r in cand:
    if len(r)>REC[cid]+40: continue
    st0=(tuple(P[cid][0]),tuple(P[cid][1])); s=shorten(st0,r); st=st0
    for x in s: st=core.apply_move(st,x)
    if st!=((1,),(2,)): print('FAIL',cid); continue
    if (cid,tuple(s)) in posted: continue
    out.setdefault(cid,set()).add(tuple(s))
lines=[]
for cid in sorted(out):
    for s in sorted(out[cid],key=len):
        print(cid,len(s),'record',REC[cid],flush=True); lines.append(f"{cid}: {list(s)}")
open('batch7.txt','w').write('\n'.join(lines)+'\n')
