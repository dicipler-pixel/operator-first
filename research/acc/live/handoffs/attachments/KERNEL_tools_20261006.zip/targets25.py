# SCRIPT: KERNEL-T25-01  beam on Jeromie's 25 board targets; compare with record (lower = better); official replay
import sys,json,time; sys.path.insert(0,'.')
import drive2 as D
from load import pool
from concurrent.futures import ThreadPoolExecutor
REC={'ac-00005':(27,12),'ac-00021':(40,10),'ac-00029':(46,5),'ac-00033':(53,3),'ac-00043':(25,9),'ac-00061':(26,10),'ac-00064':(27,14),
'ac-00065':(48,4),'ac-00093':(62,3),'ac-00101':(30,14),'ac-00103':(52,6),'ac-00104':(21,11),'ac-00123':(31,12),'ac-00126':(33,3),
'ac-00130':(59,4),'ac-00147':(34,7),'ac-00154':(46,4),'ac-00156':(47,5),'ac-00163':(36,14),'ac-00168':(47,1),'ac-00170':(41,6),
'ac-00172':(42,9),'ac-00181':(49,5),'ac-00184':(42,6),'ac-00201':(41,12)}
P=pool(); W=int(sys.argv[1]); out={}
def one(cid):
    r=P[cid]; best=None
    for H in (0,1):
        o=D.run_one((cid,r[0],r[1],W,400,len(r[0])+len(r[1])+60,H,1))
        if o['moves'] and o['official_ok'] and (best is None or len(o['moves'])<len(best)): best=o['moves']
    return cid,best
t0=time.time()
with ThreadPoolExecutor(2) as ex:
    for cid,best in ex.map(one,REC):
        rec,k=REC[cid]; L=None if best is None else len(best)
        tag = '' if L is None else ('BEAT' if L<rec else 'TIE' if L==rec else '')
        print(f"{cid} record {rec} (k={k})  ours {L} {tag}",flush=True); out[cid]=best
json.dump(out,open(f'targets25_W{W}.json','w')); print(f"{time.time()-t0:.0f}s")
