# SCRIPT: KERNEL-ROADROWS-01  pool rows that sit ON a known solved road (up to symmetry); build + verify their lines
import sys,json,collections,time; sys.path.insert(0,'.'); sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from classes import key
from load import pool
from knownset import paths
from wstar3 import bfs_to, fl, AUTS, map_move
from onesided import cls
P=pool(); PK=collections.defaultdict(list)
for cid,r in P.items(): PK[key(r[0],r[1])].append(cid)
hits=[]
for pid,r0,r1,mv in paths():
    st=(tuple(r0),tuple(r1))
    for i in range(len(mv)+1):
        if len(st[0])+len(st[1])>2:
            for cid in PK.get(key(list(st[0]),list(st[1])),[]):
                if cid!=pid: hits.append((cid,pid,i,st,mv[i:]))
        if i<len(mv): st=core.apply_move(st,mv[i])
print("pool-row matches on known roads:",len(hits),"distinct rows",len({h[0] for h in hits}))
def line_for(cid,st,rest):
    R=(tuple(P[cid][0]),tuple(P[cid][1])); best=None
    for a in AUTS:
        for swap in (0,1):
            M=(tuple(fl(c,a) for c in st[0]),tuple(fl(c,a) for c in st[1]))
            if swap: M=(M[1],M[0])
            if cls(R[0])!=cls(M[0]) or cls(R[1])!=cls(M[1]): continue
            pre=bfs_to(R,lambda s:s==M,len(R[0])+len(R[1])+8,moves=(0,1,6,7,8,9,10,11,12,13))
            if pre is None: continue
            body=[map_move(m,a,swap) for m in rest]
            e=R
            for m in pre+body: e=core.apply_move(e,m)
            fin=bfs_to(e,lambda s:s==((1,),(2,)),12)
            if fin is None: continue
            line=pre+body+fin
            chk=R
            for m in line: chk=core.apply_move(chk,m)
            if chk==((1,),(2,)) and (best is None or len(line)<len(best)): best=line
    return best
best={}
for cid,pid,i,st,rest in hits:
    if cid in best and len(best[cid][1])<=len(rest): continue
    L=line_for(cid,st,rest)
    if L and (cid not in best or len(L)<len(best[cid][1])): best[cid]=(pid,L)
for cid,(pid,L) in sorted(best.items()): print(cid,"len",len(L),"via road of",pid)
json.dump({c:{'via':p,'moves':L} for c,(p,L) in best.items()},open('roadrows_lines.json','w'))
