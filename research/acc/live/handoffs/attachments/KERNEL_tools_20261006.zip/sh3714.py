import json,sys
sys.argv=['x']
from shortcut import shorten
sys.path.insert(0,'../acc/competition/tools')
from verifier import core
from load import pool
P=pool()
d=json.load(open('join_ac-10098.json'))['ac-03714']
items=d if isinstance(d,list) else d.get('routes',d)
out=set()
for r in items:
    mv=r['moves'] if isinstance(r,dict) else r
    r0,r1=P['ac-03714']; st=(tuple(r0),tuple(r1))
    s=shorten(st,list(mv))
    s=list(s[0] if isinstance(s,tuple) and isinstance(s[0],list) else s)
    t=st
    for m in s: t=core.apply_move(t,m)
    print(len(mv),'->',len(s),t==((1,),(2,)),flush=True)
    if t==((1,),(2,)): out.add(tuple(s))
json.dump([list(x) for x in sorted(out,key=len)],open('sh3714.json','w'))
