# SCRIPT: KERNEL-SONG10-RULES-01  "the trace left behind from the bridges you made": universal move-word identities.
#   For every reduced move word u (no move followed by its inverse) of length <= L, compute its action on K test states
#   (mid-road states from real rows). Words with the same action on all K states form a class; the shortest member v
#   is a candidate rewrite u -> v. Candidates are then checked on 300 more states; survivors are applied as substring
#   rewrites to every held road of every row, and each rewritten road is replayed on verifier.core (only exact cuts count).
import sys,json,re,random,itertools
sys.path.insert(0,'../acc/competition/tools'); sys.path.insert(0,'.')
from verifier import core
from load import pool
P=pool(); INV={0:0,1:1,2:3,3:2,4:5,5:4,6:7,7:6,8:9,9:8,10:11,11:10,12:13,13:12}
GOAL=((1,),(2,))
L=int(sys.argv[1])
roads=[]
for f in ['teampool.txt','scan_ac.txt','scan4_ac.txt','scan5_ac.txt','prio_roads.txt']:
    for l in open(f):
        m=re.match(r'(ac-\d+): \[(.*?)\]',l)
        if m: roads.append((m.group(1),[int(v) for v in m.group(2).split(',')]))
random.seed(7)
def mid_states(n):
    out=[]
    for c,r in random.sample(roads,n):
        s=(tuple(P[c][0]),tuple(P[c][1])); k=random.randrange(len(r))
        for m in r[:k]: s=core.apply_move(s,m)
        out.append(s)
    return out
T=mid_states(8)
def act(w,states):
    res=[]
    for s in states:
        for m in w: s=core.apply_move(s,m)
        res.append(s)
    return tuple(res)
best={}   # signature -> shortest word
cands=[]
words=[()]
for n in range(1,L+1):
    nw=[]
    for w in words:
        for m in range(14):
            if w and INV[w[-1]]==m: continue
            nw.append(w+(m,))
    words=nw
    for w in words:
        sg=hash(act(w,T))
        if sg in best:
            if len(best[sg])<len(w): cands.append((w,best[sg]))
        else: best[sg]=w
    print('len',n,'words',len(words),'classes',len(best),'shortening candidates so far',len(cands),flush=True)
# identity words (act like the empty word) are in best[hash(act((),T))]
T2=mid_states(300)
good=[(u,v) for u,v in cands if act(u,T2)==act(v,T2)]
print('verified universal shortening rules',len(good),flush=True)
for u,v in good[:40]: print(' ',list(u),'->',list(v))
json.dump([[list(u),list(v)] for u,v in good],open(f'song10_rules_L{L}.json','w'))
# apply to every road
cut=0;rows={}
for c,r in roads:
    rr=list(r); changed=True
    while changed:
        changed=False
        for u,v in good:
            for i in range(len(rr)-len(u)+1):
                if tuple(rr[i:i+len(u)])==u:
                    rr=rr[:i]+list(v)+rr[i+len(u):]; changed=True; break
            if changed: break
    if len(rr)<len(r):
        s=(tuple(P[c][0]),tuple(P[c][1]))
        for m in rr: s=core.apply_move(s,m)
        if s==GOAL:
            cut+=1
            if c not in rows or len(rr)<len(rows[c]): rows[c]=rr
print('roads',len(roads),'shortened by rules',cut,'rows',len(rows),flush=True)
json.dump(rows,open(f'song10_cuts_L{L}.json','w'))
