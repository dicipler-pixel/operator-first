# SCRIPT: KERNEL-SONG9-STAB-01  "let something foreign touch the inside": does a stabilization (third generator) ever make
#   a Stable finish shorter than the lazy finish (AC route to (x,y) or (y,x), then 2 destabilizations)?
#   Backward BFS from the empty presentation in the full sac-r8-v1 move set (rank capped), radius R. For each rank-2 state s
#   reached at stable distance dS, compare with lazy cost min(g_xy(s), g_yx(s)) + 2 from the radius-7 AC goal ball.
#   Why it proves what it claims: every predecessor is checked by applying the FORWARD official move (stable_core.apply_move)
#   and requiring it to land on the successor, so the ball's distances are real upper bounds; a shortcut state s comes with an
#   explicit forward move list that is replayed by stable_core before it is reported.
import sys,json,itertools
sys.path.insert(0,'../acc/competition/tools')
from verifier import stable_core as S, core
exec(open('hsh2.py').read())
R=int(sys.argv[1]); KMAX=int(sys.argv[2])
INV=S.INVERSE_MOVE
def preds(s):
    k=len(s); out=[]
    for m in range(S.NUM_MOVES):
        row=S.MOVE_TABLE[m]; cat=row['category']
        if cat=='stabilize':
            if k>=3 and s[-1]==(k,):
                p=s[:-1]
                if all(abs(a)<k for w in p for a in w):
                    t,e=S.apply_move(p,14)
                    if t==s: out.append((p,14))
            continue
        if cat=='destabilize':
            i=row['relator']
            if k+1>KMAX or i>k: continue
            for g in range(1,k+2):
                up=lambda w: tuple(a+1 if a>=g else (a-1 if a<=-g else a) for a in w)
                p=tuple(up(w) for w in s[:i])+((g,),)+tuple(up(w) for w in s[i:])
                t,e=S.apply_move(p,m)
                if t==s: out.append((p,m))
            continue
        mi=INV[m]
        if mi is None: continue
        p,e=S.apply_move(s,mi)
        if p is None: continue
        t,e=S.apply_move(p,m)
        if t==s: out.append((p,m))
    return out
D={():(0,None,None)}; fr=[()]
for d in range(1,R+1):
    nx=[]
    for s in fr:
        for p,m in preds(s):
            if p not in D: D[p]=(d,s,m); nx.append(p)
    fr=nx
    print('radius',d,'new',len(nx),'total',len(D),flush=True)
G={}
for line in open('goal2_R7.txt'):
    a,b=line.split(); G[int(a)]=int(b)
def gx(s): return G.get(hs(s))
best=[]
for s,(d,_,_) in D.items():
    if len(s)!=2: continue
    a=gx(s); b=gx((s[1],s[0]))
    lazy=min(x for x in (a,b,99) if x is not None)+2
    if d<lazy: best.append((lazy-d,d,lazy,s))
best.sort(reverse=True)
print('rank-2 states in ball',sum(1 for s in D if len(s)==2),'shortcut states',len(best),flush=True)
for gain,d,lazy,s in best[:15]:
    mv=[];u=s
    while D[u][1] is not None: mv.append(D[u][2]); u=D[u][1]
    t=s
    for m in mv: t,e=S.apply_move(t,m)
    print('gain',gain,'stable',d,'lazy',lazy,'state',s,'moves',mv,'replay_ok',t==(),flush=True)
json.dump([[g,d,l,[list(w) for w in s]] for g,d,l,s in best],open(f'song9_stab_R{R}_K{KMAX}.json','w'))
