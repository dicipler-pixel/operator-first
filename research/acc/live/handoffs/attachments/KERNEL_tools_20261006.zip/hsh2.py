# SCRIPT: KERNEL-HS-02  hash matching kbeam5 hs(): letters shifted +3 so no letter byte equals the 0xff separator (HS-01 collided: X=-1 -> 0xff)
def hs(st):
    h=1469598103934665603; M=0xFFFFFFFFFFFFFFFF
    for c in st[0]: h^=((c+3) & 0xff); h=(h*1099511628211)&M
    h^=0xff; h=(h*1099511628211)&M
    for c in st[1]: h^=((c+3) & 0xff); h=(h*1099511628211)&M
    return h or 1
