# SCRIPT: KERNEL-LIFT-CTL-01  control for KERNEL-LIFT-01: both rows held; hide the target's path, lift from the donor.
#   Also logs how far the mapped donor path tracks the donor's own length profile (the "tracked" depth).
import sys,json,collections; sys.argv=['x','0','1']
exec(open('lift.py').read().split("if __name__=='__main__':")[0])
from comb import classify
ms={c:classify(*P[c]) for c in held}
byw=collections.defaultdict(dict)
for c,v in ms.items():
    if v: byw[v[1]].setdefault(v[0],[]).append(c)
pairs=[]
for w,d in byw.items():
    for n in d:
        if n+1 in d: pairs.append((min(d[n+1],key=lambda c:len(held[c])),min(d[n],key=lambda c:len(held[c]))))
pairs.sort(key=lambda p:len(held[p[1]]))
print('control pairs available',len(pairs),flush=True)
hit=0
W=int(sys.argv[1]) if False else 8000
hard=[p for p in pairs if len(held[p[0]])>=25][:6]
for tid,did in hard:
    r=lift(tid,did,W)
    if r['best'] and r['at_prefix']: hit+=1
    print('CTL',tid,'(team',len(held[tid]),') <-',did,'(donor',len(held[did]),')','lift',r['best'],'prefix',r['at_prefix'],flush=True)
print("hard control: solved",hit,"of",len(hard))
