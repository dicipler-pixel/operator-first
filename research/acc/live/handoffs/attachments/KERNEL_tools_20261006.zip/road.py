# SCRIPT: KERNEL-ROAD-01  touch-a-known-road beam (kbeam3) on rows 101-213, letter basis, W=2000, depth 300, cap start+60
import sys,json,subprocess,re,random,time; sys.path.insert(0,'.')
from load import relay; from knownset import paths
sys.path.insert(0,'../acc/competition/tools'); from verifier import core
from concurrent.futures import ThreadPoolExecutor
S={1:'x',-1:'X',2:'y',-2:'Y'}
def run(r0,r1,cap,W=2000,D=300):
    return subprocess.run(['./kbeam3',str(W),str(D),str(cap),'0','1',''.join(S[c] for c in r0),''.join(S[c] for c in r1)],capture_output=True,text=True).stdout.strip()
# control again (filter changed the code)
random.seed(3); P=list(paths()); ok=0
for pid,r0,r1,mv in random.sample(P,20):
    st=(tuple(r0),tuple(r1)); k=random.randrange(len(mv)//2+1)
    for m in mv[:k]: st=core.apply_move(st,m)
    st=core.apply_move(st,6); o=run(st[0],st[1],200,200,3); ok+=('KNOWNROAD' in o or 'SOLVED' in o)
print("control (next-to-known-road recognised):",ok,"/20",flush=True)
t0=time.time()
def one(x):
    n,cid,r=x; o=run(r[0],r[1],len(r[0])+len(r[1])+60); return dict(row=n,id=cid,out=o)
with ThreadPoolExecutor(2) as ex: out=list(ex.map(one,relay()))
hits=[o for o in out if o['out'].startswith(('KNOWNROAD','SOLVED'))]
print(f"rows 101-213: touched a known road / solved on {len(hits)}/113 in {time.time()-t0:.0f}s", [(o['id'],o['out'][:40]) for o in hits],flush=True)
json.dump(out,open('road_results.json','w'))
