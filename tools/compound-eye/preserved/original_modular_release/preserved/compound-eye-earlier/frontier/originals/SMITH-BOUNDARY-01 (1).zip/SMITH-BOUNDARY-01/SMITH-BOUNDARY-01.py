#!/usr/bin/env python3
"""SMITH-BOUNDARY-01: exact algebra plus numerical boundary-response controls.

No Lean compilation is claimed. The symbolic gates are SymPy identities; the
matrix experiments are floating-point checks, not proofs of universal claims.
See SMITH-BOUNDARY-01_proof.md for the proofs and physical assumptions.

Dependencies: Python 3, numpy, sympy.
Run: python SMITH-BOUNDARY-01.py
The script writes SMITH-BOUNDARY-01_results.json beside itself.

Predeclared failure conditions:
- any symbolic identity does not reduce to zero;
- a matrix identity/symmetry residual exceeds 1e-10;
- a passive Schur/Cayley case violates positivity or contractivity by >1e-10;
- fixed-energy two-level coupling differs from sin(theta)^2 by >1e-12;
- sheet power balance or Smith mapping differs by >1e-12;
- a negative control fails to violate the assumption it tests.

Toy optical sheet assumptions: independent two-level dipoles, occupied ground
state, weak field, prescribed positive linewidth, local electric sheet, normal
incidence from one side, identical lossless media on both sides. No microscopic
claim about the user's rigidity R or continuum limit is made.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import sympy as sp

TOL = 1e-10
SEED = 20260905


def must(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def star(a: np.ndarray) -> np.ndarray:
    return a.conj().T


def herm(a: np.ndarray) -> np.ndarray:
    return (a + star(a)) / 2


def cayley(z: np.ndarray) -> np.ndarray:
    ident = np.eye(z.shape[0], dtype=complex)
    # Right division, without explicitly forming an inverse.
    return np.linalg.solve((z + ident).T, (z - ident).T).T


def schur(a: np.ndarray, ni: int) -> np.ndarray:
    return a[ni:, ni:] - a[ni:, :ni] @ np.linalg.solve(a[:ni, :ni], a[:ni, ni:])


def projector(v: np.ndarray) -> np.ndarray:
    return np.outer(v, v.conj()) / np.vdot(v, v).real


def symbolic_gates() -> dict:
    x, y = sp.symbols('x y', real=True)
    z = x + sp.I*y
    gamma = (z - 1)/(z + 1)
    norm2 = lambda w: sp.simplify(w * sp.conjugate(w))
    checks = {
        'scalar_passivity': sp.simplify(1 - norm2(gamma) - 4*x/((x+1)**2+y**2)),
        'projector_metric_pullback': sp.simplify(
            norm2(2/(z+1)**2)/(1+norm2(gamma))**2 - 1/(1+x*x+y*y)**2),
        'sheet_smith_map': sp.simplify(((1/(1+z)-1)/(1/(1+z)+1)) + z/(2+z)),
        'sheet_power_balance': sp.simplify(
            norm2(-z/(2+z)) + norm2(2/(2+z)) + 4*x/norm2(2+z) - 1),
        'sheet_half_absorption_gap': sp.simplify(
            sp.Rational(1,2) - 4*x/norm2(2+z)
            - ((x-2)**2+y*y)/(2*norm2(2+z))),
    }
    for name, value in checks.items():
        must(value == 0, f'Symbolic gate failed: {name}: {value}')
    return {name: str(value) for name, value in checks.items()}


def matrix_gates() -> dict:
    rng = np.random.default_rng(SEED)
    worst_identity = worst_transpose = worst_energy = 0.0
    min_hermitian = float('inf')
    max_singular = max_nonnormal = 0.0
    for trial in range(60):
        n, ni = 8, 5
        raw = rng.normal(size=(n,n))
        m = raw.T @ raw/n + 0.2*np.eye(n)
        raw = rng.normal(size=(n,n))
        e = (raw-raw.T)/2
        eps = [0.0, 0.2, 1.0, 4.0][trial % 4]
        omega = [0.0, 0.4, 1.7][trial % 3]
        ell = m + eps*e - 1j*omega*np.eye(n)
        ell_minus = m - eps*e - 1j*omega*np.eye(n)
        z, zm = schur(ell, ni), schur(ell_minus, ni)
        gam, gamm = cayley(z), cayley(zm)
        ident = np.eye(n-ni)
        inv = np.linalg.solve(z+ident, ident)
        lhs = ident-star(gam)@gam
        rhs = 2*star(inv)@(z+star(z))@inv
        worst_identity = max(worst_identity, float(np.linalg.norm(lhs-rhs)))
        worst_transpose = max(worst_transpose, float(np.linalg.norm(zm-z.T)),
                              float(np.linalg.norm(gamm-gam.T)))
        min_hermitian = min(min_hermitian, float(np.linalg.eigvalsh(herm(z))[0]))
        max_singular = max(max_singular, float(np.linalg.svd(gam,compute_uv=False)[0]))
        max_nonnormal = max(max_nonnormal, float(np.linalg.norm(ell@star(ell)-star(ell)@ell)))
        b = rng.normal(size=n-ni)+1j*rng.normal(size=n-ni)
        u = -np.linalg.solve(ell[:ni,:ni],ell[:ni,ni:]@b)
        w = np.r_[u,b]
        err = abs(np.vdot(w,ell@w)-np.vdot(b,z@b))
        worst_energy=max(worst_energy,float(err))
    must(worst_identity<TOL,'matrix Cayley identity')
    must(worst_transpose<TOL,'transpose symmetry')
    must(worst_energy<TOL,'Schur quadratic-form identity')
    must(min_hermitian>=-TOL,'Schur accretivity')
    must(max_singular<=1+TOL,'Cayley contraction')
    # Positive eigenvalues alone do NOT imply a passive boundary map.
    bad=np.array([[1.,4.],[0.,1.]])
    bad_gamma=cayley(bad)
    bad_sv=float(np.linalg.svd(bad_gamma,compute_uv=False)[0])
    must(bad_sv>1.5,'negative control failed to expose noncontractivity')
    must(np.allclose(bad_gamma,[[0,2],[0,0]]),'negative-control exact matrix mismatch')
    # Removing sign-reversal transpose symmetry should change the relation.
    broken = np.eye(2)+0.3*np.diag([1.,2.])
    opposite = np.eye(2)-0.3*np.diag([1.,2.])
    broken_res=float(np.linalg.norm(cayley(opposite)-cayley(broken).T))
    must(broken_res>0.1,'negative control failed to break sign-reversal symmetry')
    return dict(cases=60,max_cayley_residual=worst_identity,
                max_transpose_residual=worst_transpose,max_quadratic_form_residual=worst_energy,
                min_hermitian_part_eigenvalue=min_hermitian,max_reflection_singular_value=max_singular,
                max_interior_commutator_norm=max_nonnormal,
                positive_eigenvalues_counterexample_reflection_norm=bad_sv,
                symmetric_perturbation_control_residual=broken_res)


def projector_gates() -> dict:
    rng=np.random.default_rng(SEED+1)
    u=np.array([[1.,1.],[1.,-1.]])/np.sqrt(2)
    worst=0.0
    for _ in range(80):
        z=complex(rng.normal(),rng.normal())
        if abs(z+1)<1e-5: continue
        gam=(z-1)/(z+1)
        pz=projector(np.array([z,1]))
        pg=projector(np.array([1,gam]))
        worst=max(worst,float(np.linalg.norm(u@pz@u.T-pg)))
        b=complex(rng.normal(),rng.normal())
        pb=projector(np.array([1,b]))
        dist=float(np.linalg.norm(pg-pb)**2/2)
        target=abs(gam-b)**2/((1+abs(gam)**2)*(1+abs(b)**2))
        worst=max(worst,abs(dist-target))
    must(worst<TOL,'boundary-ray projector map')
    return dict(cases=80,max_residual=worst)


def sheet_gates() -> dict:
    sx=np.array([[0.,1.],[1.,0.]])
    sz=np.diag([1.,-1.])
    gap=1.0; hbar=1.0; linewidth=0.05
    strength=0.10  # Z0 * surface number density * dipole^2, in chosen units.
    max_coupling=max_power=max_smith=max_energy=0.0
    rows=[]
    for theta in np.linspace(0,np.pi/2,17):
        h=(gap/2)*(np.cos(theta)*sz+np.sin(theta)*sx)
        vals,vecs=np.linalg.eigh(h)
        vminus,vplus=vecs[:,0],vecs[:,1]
        coupling=abs(np.vdot(vplus,sz@vminus))**2
        max_coupling=max(max_coupling,abs(coupling-np.sin(theta)**2))
        max_energy=max(max_energy,float(np.max(np.abs(vals-[-gap/2,gap/2]))))
        for omega in np.linspace(.2,1.8,9):
            # alpha prefactor contains Z0*Ns, so this computes g=Z0*sigma_s.
            g=-1j*omega*strength*2*gap*coupling/(gap**2-(hbar*omega+1j*linewidth)**2)
            r=-g/(2+g); t=2/(2+g)
            rr=abs(r)**2; tt=abs(t)**2; aa=4*g.real/abs(2+g)**2
            z=1/(1+g)
            max_smith=max(max_smith,abs((z-1)/(z+1)-r))
            max_power=max(max_power,abs(rr+tt+aa-1))
            must(aa>=-1e-12 and aa<=.5+1e-12,'sheet passivity/bound')
        if any(abs(theta-a)<1e-12 for a in [0,np.pi/4,np.pi/2]):
            omega=1.
            g=-1j*omega*strength*2*gap*coupling/(gap**2-(hbar*omega+1j*linewidth)**2)
            rr=abs(-g/(2+g))**2; tt=abs(2/(2+g))**2; aa=4*g.real/abs(2+g)**2
            rows.append(dict(theta_over_pi=float(theta/np.pi),energies=vals.tolist(),
                             dipole_strength=float(coupling),reflection=rr,transmission=tt,absorption=aa))
    must(max(max_coupling,max_power,max_smith,max_energy)<1e-12,'sheet identity')
    return dict(angles=17,frequencies=9,max_energy_change=max_energy,
                max_coupling_error=max_coupling,max_power_balance_error=max_power,
                max_smith_error=max_smith,resonance_table=rows)


def threshold_gates() -> dict:
    # Fixed incident TE reference a; D varied through outgoing threshold.
    a=1.3
    table=[]
    for D in [1e-2,1e-4,1e-6,1e-8]:
        s=np.sqrt(D)
        gam=(a-s)/(a+s)
        coeff=(1-gam)/s
        ev=(a-1j*s)/(a+1j*s)
        must(abs(abs(ev)-1)<1e-12,'evanescent unit-circle condition')
        table.append(dict(D=D,sqrt_coefficient=float(coeff),target=2/a,
                         evanescent_phase=float(np.angle(ev))))
    must(abs(table[-1]['sqrt_coefficient']-2/a)<2e-4,'threshold asymptotic')
    return dict(reference=a,table=table)


def main() -> None:
    results=dict(symbolic=symbolic_gates(),matrix=matrix_gates(),
                 projector=projector_gates(),sheet=sheet_gates(),threshold=threshold_gates())
    print('SMITH-BOUNDARY-01 -- written proofs plus symbolic/numerical gates; NOT Lean-checked')
    print('Symbolic identities:', results['symbolic'])
    print('Matrix gates:',json.dumps(results['matrix'],indent=2))
    print('Boundary-ray projector gates:',results['projector'])
    print('Toy two-level sheet, same energies throughout:')
    print(' theta/pi   transition strength       R               T               A')
    for row in results['sheet']['resonance_table']:
        print(f" {row['theta_over_pi']:8.3f} {row['dipole_strength']:19.12f}"
              f" {row['reflection']:15.12f} {row['transmission']:15.12f} {row['absorption']:15.12f}")
    print('Threshold coefficients:')
    for row in results['threshold']['table']:
        print(row)
    print('ALL PREDECLARED GATES PASS.')
    out=Path(__file__).with_name('SMITH-BOUNDARY-01_results.json')
    out.write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':
    main()
