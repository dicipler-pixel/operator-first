SMITH-BOUNDARY-01

Written proofs, source/scope notes, a complete Python verifier, recorded output,
and machine-readable results. This is not a Lean certificate.

Run with Python 3 and installed numpy/sympy:
    python SMITH-BOUNDARY-01.py

No source papers, private data, network calls, or local edits are needed to run it.
The script writes only SMITH-BOUNDARY-01_results.json in its own directory.

Important boundaries:
- Snell/directional law and reflection/phase map are separate.
- A passive port quadratic form is not an intrinsic projector metric.
- Same-energy different-coupling toy dipoles are not a material-specific prediction.
- Power not reflected is not necessarily power absorbed.
- No claim closes the Rice-Mele endpoint connection lemma or local smoothing.
