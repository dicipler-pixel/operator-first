# Smith chart, boundary elimination, and projector geometry

**Working proof note — 5 September 2026**  
Companion to `SMITH-BOUNDARY-01.py`.

## Status and attribution

These are written mathematical proofs, standard scattering constructions, and an explicitly assumed toy optical model. The numerical file independently checks their algebra and supplies negative controls. **No new result in this package has been compiled in Lean.** A Lean executable was not present in this runtime, and an attempt to reach the official release host failed DNS resolution. No `.lean` certificate or successful kernel output is claimed.

The Smith/Cayley transform, Schur complements, and linear-response sheet optics are established tools, not claims of new inventions. Their application here is intended to test Jeromie Beasley's intrinsic-projector / boundary-response programme. The identification of his directional rigidity with a physical permittivity remains open. His intrinsic metric is not replaced by the hyperbolic metric of the passive disk.

## 1. Keep two optical questions separate

At a stationary uniform planar interface between isotropic media, frequency and tangential wavevector matching give Snell's relation. The complex boundary response controls reflected/transmitted amplitudes and phases. A Smith chart represents the second question; it is not a replacement for the first. A patterned interface or spatial dispersion needs a more general formulation.

For a fixed, real, positive reference impedance Z0, let z=Z/Z0. The conventional Smith coordinate is

\[
\Gamma=(z-1)/(z+1),\qquad z=(1+\Gamma)/(1-\Gamma).
\]

When the indicated denominators are nonzero,

\[
1-|\Gamma|^2=\frac{4\operatorname{Re}z}{|z+1|^2}.
\]

Proof: subtract |z-1|^2 from |z+1|^2. Thus Re z>=0 is equivalent to |Gamma|<=1 in this normalization. The quantity 1-|Gamma|^2 is power not returned through that port. It is not automatically absorbed power: it can include transmission to an unobserved port.

## 2. Boundary Schur complements preserve a positive Hermitian part

Let L be a finite complex matrix with Herm(L)=(L+L*)/2>=0. Partition interior and boundary indices:

\[
L=\begin{pmatrix}L_{ii}&L_{ib}\\L_{bi}&L_{bb}\end{pmatrix},
\qquad Z=L_{bb}-L_{bi}L_{ii}^{-1}L_{ib},
\]

assuming Lii is invertible. Then Herm(Z)>=0.

For any boundary vector b choose u=-Lii^{-1}Lib b and w=(u,b). Direct multiplication gives Lw=(0,Zb), hence

\[
b^*Zb=w^*Lw,\qquad
b^*\operatorname{Herm}(Z)b=w^*\operatorname{Herm}(L)w\ge0.
\]

This is a quadratic-form proof and does not require normality or Hermiticity of L. If Herm(L)>0 then Herm(Z)>0 and all principal interior blocks are automatically invertible.

## 3. Matrix Smith/Cayley passivity identity

For a normalized boundary matrix Z, define

\[
S=(Z-I)(Z+I)^{-1}.
\]

If Herm(Z)>=0, Z+I is invertible: a vector with Zx=-x would have Re(x*Zx)=-||x||^2, impossible unless x=0. Let A=Z+I and B=Z-I. Then

\[
\begin{aligned}
I-S^*S
&=A^{-*}(A^*A-B^*B)A^{-1}\\
&=2A^{-*}(Z+Z^*)A^{-1}\\
&=4A^{-*}\operatorname{Herm}(Z)A^{-1}\ge0.
\end{aligned}
\]

Consequently every singular value of S is at most one. No eigenvector condition or diagonalizability assumption was used.

More generally, whenever Z+I is invertible, this congruence preserves rank and inertia:

\[
\operatorname{rank}(I-S^*S)=\operatorname{rank}(\operatorname{Herm}Z).
\]

For an n-dimensional boundary,

\[
\det(I-S^*S)=\frac{4^n\det(\operatorname{Herm}Z)}{|\det(Z+I)|^2}.
\]

These are statements about a response quadratic form, not an identification with the tangent metric or curvature-positivity condition in the light manuscript.

### Negative control: eigenvalues alone do not certify passivity

Take

\[
Z=\begin{pmatrix}1&4\\0&1\end{pmatrix}.
\]

Both eigenvalues are +1, but Herm(Z) has eigenvalues 3 and -1. Directly,

\[
S=\begin{pmatrix}0&2\\0&0\end{pmatrix},\qquad ||S||_2=2.
\]

The scattering eigenvalues are both zero; nevertheless one singular channel amplifies. A hypothesis about eigenvalues in the right half-plane cannot replace Herm(Z)>=0.

## 4. Application to the light manuscript's fixed symmetric-plus-skew family

The source manuscript, Section 5.4, specifies H(epsilon)=A+D0+epsilon E with A,D0 real symmetric and E real skew-symmetric. Choose c so M=A+D0+cI>0. For real omega and epsilon define

\[
L_\epsilon(\omega)=M+\epsilon E-i\omega I.
\]

Then Herm(L)=M>0, independently of epsilon and omega. Sections 2-3 give a well-defined contractive boundary transform for every epsilon. This is an admissible passive finite-dimensional response construction; it is not yet a derivation that this artificial normalization equals an optical surface impedance.

Also L_{-epsilon}=L_epsilon^T. For the same partition,

\[
Z_{-\epsilon}=Z_\epsilon^T,\qquad S_{-\epsilon}=S_\epsilon^T.
\]

The first equality follows by transposing the Schur complement. For the second, the factors Z-I and (Z+I)^{-1} commute, being rational functions of Z, so transposition reverses no effective ordering.

Thus each diagonal reflection coefficient Sjj is even in epsilon. The off-diagonal difference Sij-Sji is odd and need not vanish. Differentiating at zero gives S'(0)^T=-S'(0), so first-order changes can exist in the directed cross-channel response even when the first-order trace-log and diagonal reflections vanish.

This separates the scalar ledger from the whole response matrix. It does not prove a spatial local-smoothing bound or the self-consistent nonlinear tip-tail feedback.

## 5. A complete toy chain from electronic eigenvectors to a Smith coordinate

Assume independent, identically oriented two-level dipoles, the lower level occupied, a fixed polarization probe, weak-field linear response, a positive prescribed linewidth, and a local infinitely thin electric sheet. Illuminate normally from one side, with identical lossless media on the two sides. These are model assumptions, not descriptions of all surfaces.

Let

\[
H_\vartheta=\frac{\Delta}{2}(\cos\vartheta\,\sigma_z+\sin\vartheta\,\sigma_x),
\quad \widehat d=d\sigma_z,\quad \Delta>0.
\]

The energies stay at +/-Delta/2 for every vartheta. The probe is held physically fixed; this is not a simultaneous change of coordinates on H and d. The material angle vartheta is not an angle of optical incidence.

Writing P+/-=(I+/-n.sigma)/2, or diagonalizing explicitly,

\[
|\langle+|\widehat d|-\rangle|^2
=\operatorname{Tr}(P_+\widehat d P_-\widehat d)
=d^2\sin^2\vartheta.
\]

With time dependence e^{-i omega t}, the two-level linear-response formula with the specified symmetric retarded broadening eta>0 is

\[
\alpha_\vartheta(\omega)=d^2\sin^2\vartheta
\left[\frac1{\Delta-\hbar\omega-i\eta}
+\frac1{\Delta+\hbar\omega+i\eta}\right]
=\frac{2\Delta d^2\sin^2\vartheta}
{\Delta^2-(\hbar\omega+i\eta)^2}.
\]

Without the phenomenological broadening this follows by solving the two off-diagonal equations for the linearized density matrix in response to -d E(t). The positive linewidth specifies a damped response model; it is not a microscopic derivation of all radiative or dissipative corrections. For omega>0 its imaginary part is nonnegative.

For sheet number density Ns define sigma_s=-i omega Ns alpha and g=Z0 sigma_s. Then Re(g)>=0. Boundary electric-field continuity and the magnetic-field jump give

\[
t=1+r,\qquad -2r=g t.
\]

Therefore

\[
r=-g/(2+g),\qquad t=2/(2+g).
\]

The effective admittance looking into the outgoing medium plus sheet is Y0+sigma_s, so its normalized impedance is z=1/(1+g). Substitution in the Smith map gives exactly

\[
\Gamma=(z-1)/(z+1)=-g/(2+g)=r.
\]

Consequently

\[
R=\frac{|g|^2}{|2+g|^2},\quad
T=\frac4{|2+g|^2},\quad
A=\frac{4\operatorname{Re}g}{|2+g|^2},\quad R+T+A=1.
\]

For this one-sided, symmetric, purely electric sheet,

\[
\frac12-A=\frac{(\operatorname{Re}g-2)^2+(\operatorname{Im}g)^2}{2|2+g|^2}\ge0.
\]

The maximum 1/2 is specific to these assumptions. Reflectors, a second coherent input, magnetic surface response, or unequal media change the problem.

This model proves a conditional example: at fixed energies, changing eigenvectors relative to the fixed dipole probe changes reflection, transmission and dissipation. It does not derive the user's rigidity R, predict perceptual hue, or explain every square root in the programme.

## 6. The Smith coordinate also has an explicit orthogonal-projector representation

Set v_z=(z,1)^T and v_Gamma=(1,Gamma)^T. With the fixed unitary

\[
U=\frac1{\sqrt2}\begin{pmatrix}1&1\\1&-1\end{pmatrix},
\qquad Uv_z=\frac{z+1}{\sqrt2}v_\Gamma.
\]

Thus the orthogonal ray projectors obey P_Gamma=U P_z U*. In this *chosen two-component Euclidean normalization*,

\[
\frac12||P_{\Gamma_1}-P_{\Gamma_2}||_F^2
=\frac{|\Gamma_1-\Gamma_2|^2}
{(1+|\Gamma_1|^2)(1+|\Gamma_2|^2)}.
\]

The corresponding intrinsic line element is

\[
\frac12\operatorname{Tr}[(dP)^2]
=\frac{|d\Gamma|^2}{(1+|\Gamma|^2)^2}
=\frac{|dz|^2}{(1+|z|^2)^2}.
\]

This constructs a projector associated with boundary response data. It does not claim that it equals the material's Bloch/Riesz projector. An oblique biorthogonal projector is a different object. Also the hyperbolic disk metric proportional to |dGamma|^2/(1-|Gamma|^2)^2 is a different metric; a shared chart does not identify them.

## 7. The chart retains a square-root propagation threshold

For a TE mode in a lossless, isotropic, nonmagnetic planar half-space,

\[
k_{z,2}=k_0\sqrt{D},\quad
D=n_2^2-(k_\parallel/k_0)^2.
\]

With equal permeabilities, fixed incident reference a=kz,1/k0>0, and outgoing square-root branch, Z2/Z1=a/sqrt(D). Hence

\[
\Gamma(D)=\frac{a-\sqrt D}{a+\sqrt D}
=1-\frac2a\sqrt D+O(D)\quad(D\downarrow0).
\]

For D=-kappa^2<0,

\[
\Gamma=\frac{a-i\kappa}{a+i\kappa},\quad |\Gamma|=1,
\quad \arg\Gamma=-2\arctan(\kappa/a).
\]

The Smith point stays finite at the threshold while its dependence on D retains the square-root branch. Evanescent continuation alone is not absorption. The fixed-a slice varies the outgoing channel while holding the incident reference fixed; varying incidence angle varies a as well and must be differentiated accordingly.

## 8. What Lean would add

The ideal next formal statements are the actual linking maps, not only scalar endpoint identities: Schur quadratic-form equality, accretivity preservation, the matrix Cayley identity, its inverse-domain conditions, and the physical sheet boundary equations with real positive reference normalization. All physical identifications and constitutive assumptions must remain explicit premises or separately proved results.

A successful proof check validates the encoded statement relative to its assumptions. It does not check explanatory prose, an incorrectly encoded model, or an unproved empirical identification. Review the printed declaration, compilation result, and `#print axioms` for the exact final theorem and its dependencies. An unfinished proof can reflect missing lemmas or tactics; it does not by itself refute the mathematical statement.

The original `Offset_theorem10_core (1).lean` explicitly distinguishes geometry-to-pairing from pairing-to-zero. Its declaration is integer-valued; a theorem about real logarithmic entanglement levels needs the real/matrix extension. Likewise the Gaussian file proves the log-quadratic midpoint identity, not the stronger commentary about every finite cumulant truncation.

## 9. Sources and reproducibility

Source manuscript: Jeromie Beasley, *Light Keeps the Ledger — Matter, Direction, and the Wall Between Them*, uploaded HTML, Sections 3.2, 3.7, 5.1, 5.2 and 5.4. The intrinsic two-register structure is kept separate from the constructed port response.

Established-tool sources consulted:

- Ohio State University Ximera, *Impedance and admittance circles on the Smith Chart*: https://ximera.osu.edu/electromagnetics/electromagnetics/smithChart/digInSmithChartDerivationImpedanceAdmittance
- Feynman, Leighton and Sands, *The Feynman Lectures on Physics*, Vol. II, Chapter 33: https://www.feynmanlectures.caltech.edu/II_33.html
- Barriuso et al., *Hyperbolic reflections as fundamental building blocks for multilayer optics*, arXiv:physics/0305040: https://arxiv.org/abs/physics/0305040
- Berman, Boyd and Milonni, *Polarizability and the optical theorem for a two-level atom with radiative broadening*, Physical Review A 74, 053816 (2006): https://doi.org/10.1103/PhysRevA.74.053816 . Relevant to why linewidth conventions and dissipative/radiative meanings must be stated; no claim that the fixed-eta toy model reproduces all its corrections.
- Lean official documentation, *Validating a Lean Proof*: https://lean-lang.org/doc/reference/latest/ValidatingProofs/

Executed checks: five exact symbolic identities; 60 complex non-normal Schur/Cayley cases; 80 boundary-projector pairs; 17 material angles and nine frequencies for the two-level sheet; four threshold scales; two failing-assumption negative controls. Full numerical values are in the output and JSON. These are verification controls beside the proofs, not replacements for the proofs.
