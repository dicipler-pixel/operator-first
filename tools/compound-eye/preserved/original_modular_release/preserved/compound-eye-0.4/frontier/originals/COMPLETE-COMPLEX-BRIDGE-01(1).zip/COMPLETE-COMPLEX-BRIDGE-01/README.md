# COMPLETE-COMPLEX-BRIDGE-01

Working review and proof addendum to Jeromie Beasley's complete-complex note.

Read COMPLETE-COMPLEX-BRIDGE-01.pdf for the full mathematical arguments.
The original manuscript and uploaded archive are not modified.

Run the complete verifier without edits:

```bash
python COMPLETE-COMPLEX-BRIDGE-01.py
```

Requirements: Python 3.10 or newer, numpy, sympy.

The PDF and its editable LaTeX source contain:
- An analytic proof of the source's K4 minimum.
- Exact balanced replication: N -> q^3 N and D -> q^2 D.
- The extension to all k >= 4, using the cited Kozlov theorem at non-powers.
- Same-degree and cross-degree Hamming convention checks.
- The Gram/graph-projector/Cayley dictionary.
- The 3-cycle counterexample to max-normalized entropy and its fixed-scale repair.
- An exact isospectral fixed-probe response counterexample to scalar completeness.

K4_exact_gauge_certificate.json lists all 216 root-fixed S3 gauges and costs.
The program output labels larger-k gauge minima as theorem values, not enumerations.
original_source_verifier_output.txt is the output of the user's verifier, rerun unchanged.

No Lean kernel compilation, novelty clearance, actual optical experiment, or derivation
of electronic permittivity is claimed. The X article was not readable through the
available web route and is not used as evidence.
