"""Exact controls for the hypersurface synthesis. Requires sympy; no Lean claim."""
import json
from pathlib import Path
import sympy as s

def schur(M, eliminated):
    kept = [i for i in range(M.rows) if i not in eliminated]
    A=M.extract(eliminated, eliminated)
    return M.extract(kept,kept)-M.extract(kept,eliminated)*A.inv()*M.extract(eliminated,kept)

# Two internal shells and two retained ports; positive definite real example.
M=s.Matrix([[6,1,1,0],[1,5,0,1],[1,0,4,1],[0,1,1,3]])
K=schur(M,[0,1]); staged=schur(schur(M,[0]),[0])
assert K==staged
W=(-M[:2,:2].inv()*M[:2,2:]).col_join(s.eye(2))
assert W.T*M*W==K
V=(K+s.eye(2)).inv();S=(K-s.eye(2))*V
assert s.eye(2)-S.T*S==4*(W*V).T*M*(W*V)
assert M.det()==M[:2,:2].det()*K.det()

# B-symmetric probes, three spectral levels, one occupied level.
# Each cross-gap pair has rank-one metric; the sum has rank two.
A=s.diag(0,1,3); B=s.eye(3)
V1=s.Matrix([[0,1,0],[1,0,0],[0,0,0]])
V2=s.Matrix([[0,0,1],[0,0,0],[1,0,0]])
probes=[V1,V2]
g=s.Matrix(2,2,lambda i,j:sum(probes[i][0,n]*probes[j][n,0]/(A[0,0]-A[n,n])**2 for n in [1,2]))
assert A.T*B==B*A and all(v.T*B==B*v for v in probes)
assert g==s.diag(1,s.Rational(1,9)) and g.det()==s.Rational(1,9)

# Divergence of one chosen symmetrizer does not imply an exceptional point.
t=s.symbols('t',positive=True);Ad=s.diag(0,1);Bd=s.diag(1/t,1)
assert Ad.T*Bd==Bd*Ad
out={'nested_schur':str(K),'staged_equals_direct':True,
     'lift_and_cayley_exact':True,'determinant_factorization_exact':True,
     'reciprocal_multichannel_metric':str(g),'metric_determinant':str(g.det()),
     'diverging_pairing_constant_simple_spectrum':[0,1],
     'scope':'Exact finite examples; not a refutation of a special rank-one theorem; no Lean certification'}
Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
