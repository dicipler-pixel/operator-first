# Hypersurfaces as organizing interfaces

Jeromie N. Beasley research programme — recovered-source synthesis, 7 September 2026

**Goal:** determine how electrical response, spectral subspaces, and interface matching organize surfaces and the modes extending through their interiors and surroundings.

**Present conclusion:** the recovered work supports a precise interface-response programme. Its strongest physical example already links electronic orientation to surface susceptibility and to a whole guided optical mode. It does not yet establish electrical organization of every physical surface or a universal spacetime hypersurface. This dossier preserves the ambitious goal while identifying the equations that can carry it.

## 1. Recovered research strands

The search covered prior-context retrieval, attached files and their archives, and Library content/title searches for Smith, Snell, hypersurface, spectral lens, electrical boundary response, and reciprocity. Versions are retained as sources, not ranked by filename alone. This is a substantial recovered collection, not a claim that every historical file or GitHub revision has been exhausted.

| Source | Contribution to this goal | Reading/status |
|---|---|---|
| `paper_I_v5.pdf`, especially §6 | Intrinsic projector metric; conserved tangential momentum; geometric Snell/Clairaut relation; turning before a degenerating stratum | Relevant derivations read directly; this corrects the earlier rigidity-index identification |
| `Pasted text(48).txt` | Earlier transport/refraction argument, including a curvature-flux route to squared sine | Historical source: a curvature inequality does not supply a conserved flux |
| `Pasted text(75).txt` | Foundational operator-field draft with a fixed-energy kinetic-action derivation | Read through source service; its squared-momentum intermediate line misses a factor of R, although a corrected derivation yields its conditional final law |
| `Universal_Projector_Geometry_from_Electrical_Measurements...pdf` and `(4)(3).pdf` | Electrical covariance → projector → geometric diagnostics; cross-subspace redistribution operator | Historical electrical connection recovered. Raw experimental data were not available in this task; broad empirical/cosmological conclusions are not newly validated |
| `4_Body_Prob (3).pdf` | Five-dimensional shape-space programme, binary/collinear strata and refraction | Historical model. Its wording “3D hypersurface” in a 5D ambient space needs correction or a different explicitly specified ambient space |
| `k_transport (8).pdf` | Lattice/transport continuation, pairing and boundary programme | Recovered for continuity; not independently revalidated in full |
| Attached `three_body_operator_first.pdf`, v2 archive, and `three_body_operator_first_v3.pdf` | Corrected Gram spectrum; fold; syzygy versus gap closure; reciprocity; conical-refraction model | v3 read directly; original/v2 retained as historical versions |
| Attached `bodies_infographic.html` and PNG | Pairing-based pinching and wall claim | Must retain transition-pair/probe hypotheses; see §5 below |
| Attached `Price of a Direction v5.zip` | Projector directional distance, capacity, channel census, internal intensity-generated wall | Relevant paper sections read; nested original reproducibility archive preserved |
| `SMITH-BOUNDARY-01.zip` and proof note | Passive Schur reduction, matrix Smith transform, projector chart, electronic-sheet example | Proof note read; original Python suite rerun successfully |
| `HYPERSURFACE-TESTS-01.zip` | Two-sided elimination, nonlinear surface response, TE waveguide, exterior tail sensitivity, electronic orientation, Hall controls | Proof note read; 328/328 model assertions rerun successfully |
| `light_keeps_the_ledger (7).html` | Earlier light-paper source and boundary-wall programme | Recovered, relevant source lineage inspected; filename does not establish latestness |
| `Light_Keeps_the_Ledger_v4_draft.html`, §§8–10 | Integrated boundary/Smith identities and explicitly open constitutive identification | Relevant integrated sections read directly; draft status preserved |
| `What_Transport_Keeps.md`, §§6–7, and `atlas_calculation_method_20260906.md` | Later capacity qualification, electronic-sheet continuation, cross-paper method map | Relevant sections inspected; arithmetic transport does not establish a physical coupling |

Machine-readable original names, Library identities and local-source checksums are in `source_manifest.json`. Retrieved conversation hints alone were not used as proof. No manuscript was silently updated.

## 2. The Snell law that survives the version history

For a regular positive metric

\[
ds^2=g_\parallel(y)\,dx^2+g_\perp(y)\,dy^2,
\]

translation in x is a symmetry. With the geodesic Lagrangian one half the squared speed, the momentum is p_x=g_parallel xdot. Along a unit-speed geodesic, the metric angle from the interface normal satisfies sin(theta)=sqrt(g_parallel) xdot. Therefore

\[
\boxed{\sqrt{g_\parallel}\sin\theta=p_x,\qquad
g_\parallel\sin^2\theta=p_x^2.}
\]

This is the explicit result in `paper_I_v5`, Proposition 6.1. The squared version retains the magnitude but loses the sign of tangential momentum; the signed first-power relation should be retained for direction tracking. The component depends on the normalization of the Killing coordinate, while g(v,K) is the invariant conserved expression for a fixed Killing field K.

If C=p_x²>0 and g_parallel tends to zero, the inequality g_parallel≥C prevents reaching that stratum. A regular turning point satisfies g_parallel=C and theta=pi/2. An exactly normal path with C=0 is not excluded by this bound; actual continuation through a singular metric still needs its own analysis.

The older action L=(R/2)|qdot|²−V also yields a squared-sine relation under isotropy, tangential symmetry, a stationary interface, and fixed energy:

\[
p_\parallel^2=R^2v^2\sin^2\theta
=2R(E-V)\sin^2\theta.
\]

Equal V on both sides gives R1 sin²(theta1)=R2 sin²(theta2). A potential jump instead preserves R(E−V)sin²(theta). This conditional action model does not identify R with the inverse smallest eigenvalue of some other operator. The optical/parameter-space incidence angle, a principal angle between subspaces, and the dipole-orientation angle are also distinct variables until a physical map relates them.

The later paper explicitly distinguishes the metric component from lambda_min and its reciprocal. Its turning example should supersede the earlier universal narrative that every trajectory aligns into a singular wall.

## 3. The concrete organizing equation: both sides enter the surface

Write a finite linear operator at a fixed frequency as

\[
M=\begin{pmatrix}A&B&0\\ C&D&G\\0&F&E\end{pmatrix},
\]

on interior, interface, exterior coordinates. For a source f applied at the interface and invertible A,E,

\[
\boxed{K_\Sigma=D-CA^{-1}B-GE^{-1}F,\quad K_\Sigma u_\Sigma=f,}
\]
\[
u_I=-A^{-1}Bu_\Sigma,\qquad u_O=-E^{-1}Fu_\Sigma.
\]

The interface response includes the interior loading and the exterior loading. It therefore provides a useful organizing description of the whole boundary-value problem. This is standard Schur/Kron reduction applied to the programme; the algebra is not a claim of a newly invented universal force.

An exact extension worth carrying forward is **nested-interface consistency**. For a fixed finite linear operator, eliminating successive shells or eliminating their union gives the same retained response, provided all required blocks are invertible. Proof: both solve the same eliminated equations uniquely for every retained boundary vector, so substitution into the retained equations must coincide. Repeated substitution also yields the same lift back to the interior.

Thus the method can address interfaces inside a body, not only its outer skin. Artificial computational cuts are allowed; an artificial cut need not carry a physical surface charge or sheet. For continuum fields one must separately specify traces, operator domains and well-posedness. At a resonance of an eliminated block the ordinary inverse formula must be replaced by an appropriate retained-mode or meromorphic treatment.

For a two-block split with interior A, define W=(-A^{-1}B,I)^T and K=D−CA^{-1}B. Then MW=(0,K)^T, so

\[
\operatorname{Herm}K=W^\dagger\operatorname{Herm}M\,W.
\]

If Herm(M)≥0, the reduced operator is accretive. Under a specified positive port normalization, define S=(K−I)(K+I)^{-1} and V=(K+I)^{-1}. Then

\[
\boxed{I-S^\dagger S=4(WV)^\dagger\operatorname{Herm}M\,(WV).}
\]

This supplies one chain from the interior operator to the surface reflection/response form. The original Smith note and integrated light draft already contain its two-block form. Nested composition follows by applying the same identity at each elimination stage. This positive power-response form is not automatically the quantum tangent metric.

There is also exact bookkeeping:

\[
\det M=\det A\det K.
\]

With two disconnected eliminated sides, det M=det A det E det K_Sigma. This gives a legitimate contact with the ledger programme. An additive logarithm requires nonzero determinants and compatible branch choices; it is not a general branch-free identity or a derivation of a cosmological constant.

## 4. The electrical mechanism already demonstrated in the recovered work

The two-level sheet model holds electronic energies fixed while rotating electronic projectors relative to a fixed dipole probe:

\[
H_\vartheta={\Delta\over2}(\cos\vartheta\,\sigma_z+\sin\vartheta\,\sigma_x),
\quad \widehat d=d\sigma_z,
\quad |\langle+|\widehat d|-\rangle|^2=d^2\sin^2\vartheta.
\]

The stated response model converts this transition strength into polarizability alpha(omega), sheet conductivity sigma_s=−i omega N_s alpha, and reflection. For identical media, normal incidence, and a local electric sheet, zeta=Z0 sigma_s gives r=−zeta/(2+zeta) and t=2/(2+zeta). With z_b=1/(1+zeta), r=(z_b−1)/(z_b+1), exactly the Smith coordinate.

This establishes a conditional electronic-projector → surface-response map. For real positive reference impedance, refractive index and impedance encode different combinations of permittivity and permeability. Snell addresses direction under symmetry; Smith addresses reflected amplitude and phase. A response chart alone cannot identify a general material's microscopic dynamics.

The hypersurface package then solves a symmetric TE guide with electric sheets. Its even-mode matching condition is

\[
q\tan(qa)+g_s-\kappa=0,
\quad q^2=n_c^2k_0^2-\beta^2,
\quad \kappa^2=\beta^2-n_o^2k_0^2.
\]

The interior field is cos(qx); the exterior field is cos(qa)exp[−kappa(|x|−a)]. They are one matched mode. At k0=1, nc=1.5, a=0.8 and zero sheet strength, the recovered tests give:

| Exterior index | Effective index beta/k0 | Exterior L² intensity fraction |
|---:|---:|---:|
| 1.0 | 1.227329 | 0.379116 |
| 1.2 | 1.301982 | 0.487850 |
| 1.4 | 1.415419 | 0.728830 |

The exact sensitivity is d(beta)/d(no)=(no k0²/beta) f_out. These are model results, not measurements of a new material, and L² intensity fraction is not automatically a dispersive energy fraction.

At fixed exterior index 1, rotating the electronic angle from 0 to pi/2 changes g_s from 0 to 0.4 and beta/k0 from 1.227329 to 1.318814 while the electronic energies remain −1,+1. This is the strongest present demonstration of what the user means by electrical organization of both the interface and its interior field.

## 5. What must be fixed before saying “every hypersurface”

**Pairing is not a universal pinching theorem.** For one selected real transition pair, a square of a single linear amplitude has rank at most one. A sum over independent transition pairs can have higher rank. The attached infographic must preserve whichever pair/probe restriction makes its rank statement true.

A newly checked exact control takes A=diag(0,1,3), B=I, and two real symmetric probes coupling level 0 respectively to levels 1 and 2. The rank-one occupied spectral projector has quantum metric

\[
g=\operatorname{diag}(1,1/9),\qquad\det g=1/9>0.
\]

All stated operator/probe reciprocity relations hold. This disproves the unrestricted inference from reciprocity alone to pinching of every aggregate quantum metric. It does not refute a properly scoped special transition-pair result in the three-body construction. Likewise A=diag(0,1), B(t)=diag(1/t,1) has a diverging chosen pairing as t→0 but constant simple spectrum; pairing blow-up alone does not imply an exceptional point. The singular wall may invalidate an interior obstruction without automatically creating a cone.

**Different boundaries require a dictionary.** A material interface, a singular locus in configuration space, a mode threshold in parameter space, and a subspace/complement splitting are different mathematical objects. A smooth hypersurface is codimension one. A determinant zero set is a regular hypersurface only where the defining differential is nonzero. A three-dimensional stratum in a five-dimensional space has codimension two. A projector splitting is not itself a material skin.

**Electrical readout is not proof of electrical causation.** The recovered electrical-covariance manuscript supplies a measurement pipeline and valid cross-block algebra. Whether the measured eigenspaces represent physical transport modes requires calibration to the measured variables and the original laboratory pipeline. No raw covariance experiment was rerun here, and old claims of effective dimension approaching one were not adopted from narrative alone.

**Boundary response is not complete tomography.** An interior mode uncoupled to every measured port can change without changing the boundary response. This exact counterexample is already in HYPERSURFACE-TESTS-01. Identifying the entire interior requires observability, adequate probes/frequencies and model assumptions.

**A wave residual is not the desired rigidity operator.** On an exact guided solution, the matching residual has a zero singular value. Substituting it into R_eta=[sigma_min²+eta]^{-1} gives 1/eta for every mode while the index varies. The recovered suite already rejects that particular identification. A physically derived propagation/evolution operator with fixed inner products is the appropriate next candidate to investigate.

## 6. Research target carried forward

Use the following as the working organizing principle:

> The interface response encodes how a specified interior, surface coupling, and exterior admit a common transported mode; nested interfaces compose consistently, and electronic response can move the resulting modes and their geometry.

The next physical bridge is specific: derive the propagation operator for the electronic-sheet waveguide, retain the same physical normalization and probe, and compare (i) mode-projector geometry, (ii) conserved tangential momentum, and (iii) the boundary scattering response as electronic orientation and exterior loading vary. Test any proposed rigidity/index relation over that family, rather than defining a normalization to force it. Then extend from a planar guide to nested curved interfaces.

This brings the light, Snell, Smith, electrical covariance, and directional-capacity strands into one testable programme. It leaves the universal claim open to evidence rather than treating the shared notation as its proof.

## 7. Reproducibility and provenance

- The original Smith script was rerun: all declared gates pass, including 60 matrix cases, 80 boundary-projector pairs, the electronic sheet and threshold controls.
- The original hypersurface script was rerun: **328/328 assertions passed**.
- `new_checks/verify_nested_and_pairing.py` adds exact rational checks of nested elimination, the lifted Cayley identity, determinant factorization, the reciprocal multichannel control, and the divergent-pairing control.
- Original archives are unchanged under `sources/`. Fresh outputs are under `reruns/`; original stored results remain in the source archives.
- Python dependencies: numpy, scipy, sympy. These are algebra/model checks. No new Lean kernel certification is claimed; the recovered hypersurface release records 22 uncompiled candidates. This is the status of that release, not a claim about later repository work.
- No claim is made that all theorems in all recovered historical manuscripts have been reverified.

External calibration: [Dörfler and Bullo, Kron reduction](https://arxiv.org/abs/1102.2950); [MIT, Electromagnetics and Applications course notes](https://ocw.mit.edu/courses/6-013-electromagnetics-and-applications-spring-2009/d3be4ea78b036a6362230fb41780cf54_MIT6_013S09_notes.pdf). These support the established electrical and boundary-reduction framework; the research-specific findings above are grounded in the recovered manuscripts and checks.
