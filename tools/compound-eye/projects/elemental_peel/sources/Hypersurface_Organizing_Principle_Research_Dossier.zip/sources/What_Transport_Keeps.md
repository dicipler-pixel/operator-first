---
title: "What Transport Keeps"
subtitle: "Projector selection, conserved pairings, and spectral geometry after the Ramanujan Challenge"
author: "Jeromie N. Beasley"
date: "6 September 2026 · Follow-up research edition 3"
lang: en
---

# The question and the claim grades

A transport can forget almost every direction and still retain a constant. A flat matrix field can have changing spectral subspaces. An electronic system can keep its energy levels and change how it responds to light. These are the relationships that motivated the operator-first programme: what survives, what moves, and what a chosen measurement can recover are different questions about one construction.

The Ramanujan Challenge supplied an unusually strong calibration. Its authors released explicit recurrences, special-function realizations, exact initial data, and proofs of the target limits [1]. The earlier companion-matrix study [2] asked what a singular-vector diagnostic sees when those answers are already known. This follow-up closes the finite-dimensional selection and pairing arguments, reconstructs the Catalan field, and retains the connection to projector geometry and boundary response. The arithmetic identification remains credited to the challenge authors. The additional object studied here is the geometry of the transport and the information retained by its readout. The recovered Atlas [10] now contributes working tools: pairwise numerator cancellation, projector selection, frame-consistent expansion, and trajectory comparison. Their use closes the band-exponent question and makes the remaining arithmetic cost explicit.

**Abstract.** We formulate a normalized-Gram criterion for convergence of the dominant right singular projector, including a quantitative bound and explicit tied-growth controls. Strict modal dominance follows as a sufficient special case; tied growth can produce a fixed line, a rotating line, or a higher-rank unresolved block. We combine conserved dual pairings with a finite readout-error bound and reproduce the exact Catalan cancellation from the official challenge proof. For the two-parameter Meijer-G field reconstructed from the earlier calibration, a global rational plaquette identity and an exact algebraic certificate establish discrete compatibility and nonzero spectral eigenline curvature at a regular point, respectively. These are different statements with different notions of connection. An exact expansion along $k=0$ now proves the two outer curvature exponents and the distinct middle-band exponent, including their leading coefficients. An exact kernel-and-output criterion recovers numerator selection, while seven CMF trajectory tests measure approximation against primitive integer height. We then derive the rank-one stress composition law, an exact projective-circle capacity census, and the electronic-orientation-to-boundary-response chain. Catalan's angular rail integral is retained with its measure stated explicitly. Physical identification of that measure is a hypothesis, not an arithmetic consequence. The result is a closed paper about selection, pairing, and geometric response, with a defined physical continuation rather than an assumed unification.

## Assumptions before interpretation

**A1 — Space and instrument.** Transport acts in a finite-dimensional real or complex vector space with a fixed positive-definite inner product. Coordinates are orthonormal unless a metric matrix is explicitly supplied. Singular vectors, norms, and adjoints refer to this instrument. A general nonunitary change of coordinates must also transform the inner product to represent the same instrument.

**A2 — Order.** For column evolution $x_{n+1}=A_nx_n$, write $B_N=A_{N-1}\cdots A_0$. The official Catalan matrix walk instead uses the right-ordered product $W_N=M(0)\cdots M(N-1)$. Both appear below and are never interchanged. Matrices being inverted are assumed invertible at the stated indices.

**A3 — Selection.** A singular direction means its orthogonal rank-one projector, so arbitrary signs or complex phases are removed. The normalized-Gram limit and its top gap are hypotheses of Theorem 1, not conclusions drawn merely from instantaneous eigenvalues.

**A4 — Arithmetic inputs.** The special-function representation, recessive-mode selection, and initial-vector evaluation of the official Catalan proof [1, Lemmas 17–19] are cited inputs. The exact rational cancellation and matrix identities are independently checked here. Neither the challenge proof nor this paper is used as a proof of Catalan's irrationality.

**A5 — Local spectral geometry.** The eigenline calculations use a smooth rational family in a declared fixed ambient trivialization, on regions with simple eigenvalues. A spectral idempotent need not be self-adjoint. The positive Hilbert–Schmidt metric is asserted only for orthogonal projectors. Discrete plaquette compatibility is not silently identified with a smooth ambient connection.

**A6 — Physical realization.** The optical continuation uses a specified two-level dipole model and finite boundary elimination. Below-resonance response is lossless in that model. The field profile, its Hilbert-space norm, and any physical energy norm are distinct until identified. No spacetime field equation or universal gravitational coupling is assumed.

**A7 — Scope of computation.** Exact rational/algebraic identities, finite-precision numerical measurements, cited results, and proposed physical bridges have separate grades. Historical measurements are identified as historical. No Lean certification is inferred from a symbolic computation or a printed proof.

## The grading system

This edition uses the following five grades. They describe evidence, not prestige or priority.

| Grade | Meaning in this paper |
|:--|:--|
| **[T]** | Exact theorem with a written proof; hypotheses stated. Established identities may also carry [C]. |
| **[V]** | Reproducible computation. The caption or statement specifies exact algebra versus finite precision. |
| **[C]** | Result cited from an identified source. It is not claimed as new here. |
| **[D]** | Data reported from a physical dataset or experiment. No new [D] claim is made in this paper. |
| **[H]** | Hypothesis or proposed identification, including motivation that is not yet a theorem. |

The historical Atlas [10] uses [C] for conjecture and [D] for a derivation within its framework. Those historical labels are not imported into this paper with a different meaning; every result below is graded by the present legend.

A [T]+[V] statement has a written proof and a computational check. A numerical slope stays [V] until an asymptotic proof is supplied. A machine-kernel certificate, when available, must name the exact declarations and toolchain separately; it is not another meaning of [V]. This release contains written and symbolic proofs, not a Lean-certified theorem count.

![Figure 1. The retained architecture: transport, selection, pairing and response have separate inputs. The dashed physical continuation is [H]; the algebraic and geometric maps are developed below.](figures/architecture.png)

# 1. Let the Gram matrix decide

For any nonzero cumulative transport $B_N$, define

$$H_N=\frac{B_N^*B_N}{\operatorname{Tr}(B_N^*B_N)}.$$

It is positive semidefinite with trace one. Its leading eigenprojector is precisely the dominant right singular projector of $B_N$. Scalar normalization of $B_N$ has no effect on it. This positive matrix records the instrument's amplification of seed directions; it is not the spectrum of a single transport step.

## Theorem 1 — A gapped Gram limit selects a line [T]

Let $H_N$ and $H$ be positive semidefinite Hermitian matrices on the same finite-dimensional inner-product space. Suppose $H_N\to H$ in operator norm, and $H$ has a simple largest eigenvalue $\lambda_1$ with gap $\delta=\lambda_1-\lambda_2>0$. Let $Q$ be its top projector. Then the top projector $Q_N$ of $H_N$ is eventually unique and converges to $Q$. With $\eta_N=\|H_N-H\|$,

$$1-\operatorname{Tr}(Q_NQ)\leq\frac{2\eta_N}{\delta}.$$

**Proof.** Let $u$ be a unit top eigenvector of $H$, and $v_N$ a unit top eigenvector of $H_N$. The variational principle gives

$$v_N^*H_Nv_N\geq u^*H_Nu\geq\lambda_1-\eta_N.$$

Consequently $v_N^*Hv_N\geq\lambda_1-2\eta_N$. On the other hand, expanding $v_N$ in an orthonormal eigenbasis of $H$ gives

$$v_N^*Hv_N\leq\lambda_1-\delta(1-|u^*v_N|^2).$$

Combining these proves the bound. The same variational principle on subspaces bounds each ordered eigenvalue change by $\eta_N$; hence the top gap of $H_N$ is at least $\delta-2\eta_N>0$ eventually. Finally $\|Q_N-Q\|_F^2=2(1-|u^*v_N|^2)\to0$. $\square$

No trace normalization is required for this theorem. Applying it to $B_N^*B_N/\operatorname{Tr}(B_N^*B_N)$ makes the transport diagnostic invariant under nonzero scalar rescaling; applying it to an unnormalized Gram matrix uses its gap and perturbation in the same units. The conclusion concerns a line, not an arbitrary signed eigenvector. The theorem is sufficient; a moving Gram matrix can also have a fixed top projector without converging as a whole.

## Theorem 2 — Strict dominance, with a finite error [T]

Suppose

$$B_N/s_N=u_Na^*+E_N,\qquad \|u_N\|=1,\quad a\ne0,\quad \|E_N\|\to0,$$

where $s_N>0$ and $a$ is a fixed seed covector represented using A1. Then the dominant right singular projector converges to $aa^*/\|a\|^2$. Put

$$\varepsilon_N=2\|a\|\|E_N\|+\|E_N\|^2.$$

When $\varepsilon_N<\|a\|^2/2$, the top line is unique and

$$1-\operatorname{Tr}\left(Q_N\frac{aa^*}{\|a\|^2}\right)
\leq\frac{2\varepsilon_N}{\|a\|^2}.$$

**Proof.** Expanding the unnormalized Gram matrix gives

$$(B_N/s_N)^*(B_N/s_N)=aa^*+a u_N^*E_N+E_N^*u_Na^*+E_N^*E_N.$$

The last three terms have operator norm at most $\varepsilon_N$. Apply Theorem 1 and its finite perturbation bound to $aa^*$, whose gap is $\|a\|^2$. $\square$

For a finite modal basis with one solution vector larger in norm than every other by a ratio tending to infinity, expansion in the fixed seed basis supplies this decomposition. The covector $a^*$ extracts the coefficient of that dominant solution. Ties among the smaller modes do not enter the proof.

**Order-2 corollary [T]+[C].** Let $\mathbf f_N=(f_N,f_{N-1})^T$ and $\mathbf d_N=(d_N,d_{N-1})^T$ be independent real solution states with $\|\mathbf f_N\|/\|\mathbf d_N\|\to0$. The dominant seed functional annihilates $(f_0,f_{-1})^T$, so its representing line is

$$\operatorname{span}(-f_{-1},f_0)^T.$$

This is the earlier Casoratian-dual argument [2], stated with vector-state minimality. For a continued fraction with Pincherle value $K=-f_0/f_{-1}$ and $f_{-1}\ne0$, the selected line has slope $K$ [1, Proposition 1]. This corollary explains the diagnostic; it does not replace the arithmetic proof identifying the minimal solution.

## Tied growth has three outcomes [T]+[V]

The criterion can be tested without guessing a phase law. Consider these cumulative matrices; each is generated by invertible steps $A_N=B_{N+1}B_N^{-1}$.

1. **A selected line without modal separation:** $B_N=2^N\operatorname{diag}(2,1)$. Both independent modes have comparable growth, yet $H_N=\operatorname{diag}(4,1)/5$ and $Q_N=e_1e_1^T$ for every $N$.
2. **A rotating line:** $B_N=2^N\operatorname{diag}(2,1)R(N\pi/4)$, with $R$ the plane rotation. Its Gram top line rotates periodically and has no limit, although its two singular values remain separated in ratio $2$.
3. **An unresolved block:** $B_N=2^NI$. The entire plane is the top singular space. Selecting one vector adds an arbitrary convention.

All three have tied exponential growth. Their different outcomes are visible directly in the Gram matrices. A growth tie alone establishes none of them.

![Figure 2. Exact tied-growth controls [T]+[V]. The left panel retains a fixed leading projector; the centre rotates it; the right has a two-dimensional leading space. The transport growth scale is the same in all three.](figures/gram_controls.png)

# 2. The constant is recovered by a pairing

## Theorem 3 — Dual conservation and finite readout error [T]+[C]

Let $x_{n+1}=A_nx_n$ and $\ell_{n+1}=A_n^{-T}\ell_n$. Here the pairing is the algebraic bilinear pairing $\ell^Tx$; for a Hermitian dual convention use $A_n^{-*}$ and $\ell^*x$. Then

$$\ell_{n+1}^Tx_{n+1}=\ell_n^Tx_n.$$

Under a moving coordinate change $x'_n=S_n^{-1}x_n$, $\ell'_n=S_n^T\ell_n$, the value is unchanged at every index. These statements follow by cancellation of adjacent inverses. The official proof uses this structure together with recessive-mode selection [1, Corollaries 1–3]. Conservation alone does not identify a number.

For the quantitative readout, take fixed complex row functionals $p,q$, a vector $x$ with $qx\ne0$, and $K=px/(qx)$. If $y=c(x+r)$ with $c\ne0$ and $\|q\|\|r\|<|qx|$, then

$$\left|\frac{py}{qy}-K\right|
\leq\frac{\|p-Kq\|\|r\|}{|qx|-\|q\|\|r\|}.$$

**Proof.** The scalar $c$ cancels. Subtracting the ratios leaves $(p-Kq)r/(qx+qr)$. Apply the operator-norm bound to the numerator and the reverse triangle inequality to the denominator. $\square$

The inequality separates two costs: selection error $r$ and readout sensitivity through $qx$. A nearly vanishing denominator can make a well-selected mode a poor numerical instrument. That distinction matters for both recurrence ratios and optical response.

## Theorem 4 — Coboundaries preserve the pairing, not an untransformed Euclidean metric [T]+[C]

For right-ordered transports satisfying

$$T(n)U(n+1)=U(n)C(n),$$

successive cancellation gives

$$T(0)\cdots T(N-1)=U(0)[C(0)\cdots C(N-1)]U(N)^{-1}.$$

This is the official coboundary identity [1, Corollary 2]. Both endpoint frames are present. It explains why changing product order or omitting $U(N)$ changes the comparison.

In coordinates $x=Sx'$, a fixed physical norm $x^*Gx$ becomes $x'^*S^*GSx'$. Replacing $G$ by the identity again after a nonunitary $S$ changes the instrument. Consequently singular directions and Frobenius stress computed with a fixed coordinate Euclidean norm are not invariant under arbitrary rational gauges. The conserved pairing is invariant under the matching dual transformation.

This is also a limit on interpretation. A varying frame along a single path does not require nonzero curvature. Curvature is tested by a two-parameter connection, not inferred from a mismatch between frames at two depths.

# 3. Catalan: the exact calibration anchor

The official Question 5 defines an explicit polynomial matrix $M(n)$, a right-ordered walk $W_N=M(0)\cdots M(N-1)$, and

$$A=\begin{pmatrix}30921&-32972&8240\\33750&-36000&9000\end{pmatrix}.$$

Its three ratios are the ratios of the two rows of $AW_N$. All nine polynomials of $M$ are reproduced in `verify.py`, with no external script dependency.

**Official result [C].** The authors prove that each ratio tends to Catalan's constant

$$G=\sum_{j=0}^{\infty}\frac{(-1)^j}{(2j+1)^2}.$$

Their route is specific: a positive Meijer-G integral selects the recessive companion solution; the limiting companion polynomial is

$$(z-1)(z^2-34z+1);$$

the nonzero terminal connections select that solution in every column; and the initial data recover $G$ by exact cancellation [1, Lemmas 16–19 and Theorem 5]. No irrationality conclusion is needed.

## The exact cancellation [C]+[V: exact]

Write $F_G=\sqrt\pi\,f$ with

$$f=\begin{pmatrix}
150G-128\log2-146/3\\
(24745/4)G-(14624/3)\log2-823511/360\\
(7225281/32)G-(886784/5)\log2-2818419551/33600
\end{pmatrix}.$$

The initial Krylov matrix is

$$U_0=\begin{pmatrix}
1&152/5&195477/175\\
0&1723/90&1963751/2800\\
0&-143/18&-165201/560
\end{pmatrix}.$$

Multiplication gives

$$\boxed{A U_0^{-T}F_G=450\sqrt\pi\begin{pmatrix}G\\1\end{pmatrix}.}$$

The verification treats $G$ and $\log2$ as independent symbols. The coefficient of $\log2$ cancels in both rows, the rational terms cancel in the first, and the second becomes exactly $450$. Thus the certificate checks the cancellation independently of any decimal approximation to either constant.

The complete limit is a cited theorem; the cancellation is independently reproduced exact algebra. The distinction is deliberate. A printed matrix multiplication does not re-prove the Meijer-G integral evaluation from which $F_G$ came.

## Proposition 4a — Cancel a subspace, retain the readout [T]+[V: exact]

Let $C$ be a rational matrix of unwanted coefficients and $b$ a rational row functional to be retained. There exists a rational column $c$ with $Cc=0$ and $bc\ne0$ if and only if $b$ is not in the row space of $C$. If $N$ is a full-column-rank rational basis of its nontrivial kernel, put

$$\Pi=N(N^TN)^{-1}N^T.$$

The criterion is equivalently $b\Pi b^T>0$. For a zero-dimensional kernel take $\Pi=0$. A rational solution of $C^Ty=b^T$ is a dual certificate that the desired retention is impossible.

**Proof.** The annihilator of $\ker C$ is the row space of $C$. Moreover $b\Pi b^T=\|\Pi b^T\|^2$, so positivity gives the rational witness $c=\Pi b^T$. If $C^Ty=b^T$, every kernel vector has $bc=y^TCc=0$. These alternatives exhaust the finite-dimensional row-space decomposition. $\square$

This is the kernel-and-output test recovered from the Atlas probe [10]. Applied to the coefficient matrix $J$ defined by $f=J(G,\log2,1)^T$ above, take $C$ to be the transpose of its last two columns and $b$ the transpose of its first. The test yields

$$w=\left(\frac{2006814443}{11474790},
-\frac{1105372862}{9562325},
\frac{5834864}{1912465}\right)^T,\qquad w^TJ=(1,0,0).$$

Thus the unwanted components vanish while the Catalan component survives. This reconstructs a known initial readout; it does not replace the cited evaluation of $f$ or establish irrationality.

The numerator also states a useful limit. For rational rows $u,v$ and a fixed coefficient column $c$ independent of an indeterminate $z$,

$$(zv-u)c\equiv0\quad\Longleftrightarrow\quad uc=vc=0.$$

Coefficient comparison proves the equivalence. Cancelling the entire formal error numerator therefore destroys the denominator as well. At depth two the actual two-row readout has rank two and its one-dimensional kernel has $v\Pi v^T=0$, checked exactly. This excludes identity cancellation of that kind; partial asymptotic cancellation and small nonzero values at $z=G$ remain distinct possibilities.

For primitive integer pairs $(p,q)$ with $q>0$, the relevant arithmetic object is $qG-p$, not just $G-p/q$. Appendix C tests seven trajectories with the initial readout held fixed. Every one of its 84 sampled linear forms has certified absolute value greater than 1, despite some very small ratio errors. The numerator's gain must exceed the integer-height cost. This finite finding is not an obstruction to all trajectories or all coefficient combinations.

## A common rail does not identify a common constant [T]+[C]

The nontrivial roots are

$$\lambda_\pm=17\pm12\sqrt2,\qquad\lambda_+\lambda_-=1.$$

They are the same roots as the limiting Apéry polynomial for $\zeta(3)$. In the rail parametrization,

$$\lambda_\pm=\sec\psi\pm\tan\psi,\qquad\sec\psi=17.$$

This is a precise shared algebraic scale. The readout depends additionally on the selected initial solution and the rows applied to it. Equality of limiting roots does not identify Catalan with $\zeta(3)$, or make their complete recurrences equivalent. The shared rail is a structural observation that motivates comparison of the full transports.

## Product order is part of the datum [V]

The new verifier forms both $M(0)\cdots M(N-1)$ and $M(N-1)\cdots M(0)$ at 180-digit working precision, keeping their norms controlled by scalar rescaling. It evaluates all three official ratios and both right singular directions. The measurements are supplied in `checks/results.json` and plotted below. They confirm that the official and reversed products select different right directions. The reversed product is not used to prove the challenge limit.

![Figure 3. Recomputed Catalan calibration [V]. Left: the maximum error of the three official row ratios. Right: the first-coordinate magnitude of the dominant right singular vector for the official and reversed product orders. Decimal errors are numerical evidence; the exact limit is credited to [1].](figures/catalan_products.png)

# 4. Discrete compatibility and spectral curvature

The previous paper introduced a transverse Meijer-G parameter $k$ [2]. We reconstruct its shift machinery, rather than use an unavailable private helper. This closes the reproducibility gap of the earlier listings.

The upper parameters are

$$a=(-1-n+k,-1-n,n+5/2,n+3),$$

and the lower parameters are $(3/2,1/2,1,0)$. Put

$$\prod_j(\theta-a_j+1)-\prod_j(\theta-b_j)
=r_3\theta^3+r_2\theta^2+r_1\theta+r_0.$$

Where $r_3\ne0$, set $c_i=-r_i/r_3$. The column state $(F,\Theta F,\Theta^2F)^T$ has a numerator-lowering shift

$$N_j(a)=\begin{pmatrix}
1-a_j&1&0\\0&1-a_j&1\\c_0&c_1&c_2+1-a_j
\end{pmatrix}.$$

A denominator-lowering shift is its signed counterpart with $s=a_j-1$:

$$D_j(a)=\begin{pmatrix}s&-1&0\\0&s&-1\\-c_0&-c_1&s-c_2\end{pmatrix}.$$

Raising that denominator uses $D_j(a+e_j)^{-1}$. Compose numerator shifts $1,2$ and denominator raises $3,4$ to obtain $T(n,k)$; use $N_1$ alone to obtain $L(n,k)$. The complete rational entries are in `cmf_explicit.py`, and `cmf.py` regenerates them from these operations. These shift identities are inherited from the Meijer-G construction [1,2,6].

## Proposition 5 — Exact identities of the reconstructed field [T]+[V: exact]

With the column convention above,

$$T(n,0)M(n)=\sigma(n)I,$$

$$\sigma(n)=-2(n+2)^2(n+3)^2(2n+5)(2n+7)^2,$$

and

$$\boxed{L(n+1,k)T(n,k)=T(n,k-1)L(n,k).}$$

These are identities over $\mathbb Q(n,k)$: clear denominators and each entry of the difference is the zero polynomial. The verifier performs that exact check for all nine entries, not just selected plaquettes. The first identity fixes the column/row convention against the official matrix; $T(n,0)=T_G(n)^T$.

The determinant is

$$\det T=
\frac{(2n+7)(k-n-3)(k-n-2)(2k-2n-7)(2k-2n-5)}
{(n+1)(n+2)(2n+3)^2(2n+5)}.$$

**Proof.** Substitution of the rational matrices generated above verifies the first two identities entrywise. Expanding the determinant by its six permutation terms and collecting over the common denominator gives the displayed factorization. These finite polynomial identities are exact certificates supplied with the paper. $\square$

On the real domain $n\ge0$, the determinant's zeros are the four stated $k$-lines. On a larger complex domain, numerator zeros such as $2n+7=0$ and all poles must also be tracked. The intermediate shift construction excludes its own denominator zeros; the simplified $T$ can admit additional extensions. The common lattice identity is used only where both paths are defined.

## Theorem 6 — The eigenline curvature certificate [T]+[V: exact]

For a smooth matrix family with a complete simple spectrum on the region considered, choose local right and left eigenvectors for $\lambda_b$ with $\ell_b^Tr_c=\delta_{bc}$ and set $P_b=r_b\ell_b^T$. In the fixed trivialization of A5, define

$$\alpha_b=\ell_b^Tdr_b,\qquad
F_b=\operatorname{Tr}\bigl(P_b[\partial_nP_b,\partial_kP_b]\bigr).$$

Then

$$F_b=\sum_{c\ne b}
\frac{(\ell_b^TT_nr_c)(\ell_c^TT_kr_b)
-(\ell_b^TT_kr_c)(\ell_c^TT_nr_b)}{(\lambda_b-\lambda_c)^2},
\qquad\sum_bF_b=0.$$

**Proof.** Differentiate $Tr_b=\lambda_br_b$ and multiply by $\ell_c^T$, $c\ne b$, to obtain $\ell_c^T\partial_xr_b=(\ell_c^TT_xr_b)/(\lambda_b-\lambda_c)$. Differentiate the left equation similarly. In $d\alpha_b=d\ell_b^T\wedge dr_b$, insert the complete eigenbasis. The $b$-term cancels by normalization; the other terms give the formula. Exchanging $b,c$ changes the sign of each summand, proving the sum rule. Expanding derivatives of $r_b\ell_b^T$ gives the projector formula. Under $r_b\mapsto fr_b$, $\ell_b\mapsto f^{-1}\ell_b$, the connection changes by $f^{-1}df$ and its curvature is unchanged. $\square$

The formula and mechanism are established spectral geometry [4]; the specific field and exact nonzero certificate are the present application. Gauge invariance here means eigenvector rescaling, or a consistently transformed ambient connection. An arbitrary parameter-dependent change of ambient basis followed by resetting the connection to ordinary differentiation is a different geometric calculation.

At $(n,k)=(2,0)$ the matrix has three distinct real eigenvalues. The verifier forms

$$p(z)=\det(zI-T),\qquad P(z)=\frac{\operatorname{adj}(zI-T)}{p'(z)},$$

and differentiates along the eigenvalue using $\lambda_x=-p_x/p'$. The resulting rational curvature is reduced modulo $p$. The numerator and denominator are each coprime to $p$ over $\mathbb Q$. Therefore the curvature is nonzero at **each** of the three eigenlines at this point. The exact polynomials and gcd certificates are printed in Appendix A. This proves nonvanishing independently of a small numerical residual.

The numerical check uses the sum-over-states expression and an independent finite difference of left/right eigenframes. Halving the step reduces the discrepancy by approximately four, while the sum-over-states calculation obeys the sum rule at high precision. The two routes test different implementations of the same written formula.

![Figure 4. Recomputed spectral curvature on the Catalan field [V]. All three bands are tracked in the all-real region. Guide slopes describe the finite-depth data; Theorem 6a separately proves the exponents by exact expansion.](figures/curvature.png)

**Band-dependent finite-depth scaling [V].** Label bands by decreasing eigenvalue magnitude as in the verifier. The doubling ratios $|F_b(n,0)|/|F_b(2n,0)|$ are:

| $n\to2n$ | Band 1 | Band 2 | Band 3 |
|:--|--:|--:|--:|
| 16 → 32 | 3.638186 | 6.656027 | 3.405112 |
| 32 → 64 | 3.802380 | 7.235201 | 3.667973 |
| 64 → 128 | 3.896474 | 7.589266 | 3.823628 |
| 128 → 256 | 3.946981 | 7.786736 | 3.908957 |

The outer-band ratios differ at finite depth; both move toward 4, while the middle ratio moves toward 8. The sum rule is checked independently at 100-digit working precision. These measurements motivated the band-resolved expansion below; they are retained as an independent numerical comparison with its exact result.

## Theorem 6a — Exact band-resolved curvature asymptotics [T]+[V: exact]

Let $T(n,k)$ be the reconstructed column-transport matrix of Proposition 5, and let $F_b$ denote its eigenline curvature in the original fixed ambient frame. At $k=0$, label the three bands by their limiting eigenvalues $17+12\sqrt2$, $1$, and $17-12\sqrt2$.

As $n\to+\infty$,

$$\begin{aligned}
F_{\mathrm{dom}}(n,0)&=-\frac{5\sqrt2}{16n^2}
+\frac{-9/16+95\sqrt2/64}{n^3}+O(n^{-4}),\\
F_{\mathrm{mid}}(n,0)&=\frac{9}{8n^3}+O(n^{-4}),\\
F_{\mathrm{rec}}(n,0)&=\frac{5\sqrt2}{16n^2}
+\frac{-9/16-95\sqrt2/64}{n^3}+O(n^{-4}).
\end{aligned}$$

Thus the outer exponents are exactly 2 and the middle exponent is exactly 3 for this field, trajectory and curvature convention. The coefficients satisfy the exact sum rule order by order:

$$-\frac{5\sqrt2}{16}+0+\frac{5\sqrt2}{16}=0,$$
$$\left(-\frac9{16}+\frac{95\sqrt2}{64}\right)+\frac98
+\left(-\frac9{16}-\frac{95\sqrt2}{64}\right)=0.$$

This is a consistency check on the coefficient set, not an independent proof of its individual values. This supplies a direct algebraic derivation of the older recognized amplitudes and band-dependent decay; it does not claim that those observations first appeared in this edition.

**Proof.** Set $t=1/n$ and balance the rational matrix by $S=\operatorname{diag}(1,t^{-1},t^{-2})$. Expand $B=S^{-1}TS$, $X=S^{-1}T_nS$ and $Y=S^{-1}T_kS$, differentiating $T$ before changing basis. The limiting matrix $B_0$ has simple spectrum. Polynomial spectral projectors and their first perturbations therefore give analytic expansions for every term in Theorem 6. Exact substitution yields the displayed coefficients; the limiting gaps are nonzero, giving the $O(t^4)$ remainder. Appendix B supplies all six expansion matrices, the projector corrections and the coefficient formulas. $\square$

The middle band's leading pair contributions cancel, while its next coefficient is $9/8$. This is the numerator mechanism sought in Atlas B75/B82 [10], established for the actual field rather than inferred from eigenvalue ordering. No exact commuting derivative decomposition is assumed. The older recognition of the outer amplitude and the two exponents [2,3] is retained as the motivation; the exact coefficient derivation is the addition here.

## What this establishes about flatness

The plaquette identity proves equality of discrete matrix compositions. The spectral curvature concerns eigenspaces of a smooth rational family in a fixed trivialization. The coexistence is exact; it does not require interpreting one connection as the other.

For an independently specified smooth flat ambient connection $\nabla$, its projected connection on a subbundle may have curvature supplied by the projection terms. That is the standard subbundle mechanism [4]. Identifying such a smooth connection with the discrete Meijer-G transport requires an explicit construction. We retain this as a useful geometric question instead of declaring it solved by a lattice identity.

The earlier eigenvector drift and exceptional-point analysis [2,3] remain motivations for further continuation. Theorem 6a closes the band-exponent and amplitude question along $k=0$; it does not derive curvature from one-parameter drift. A one-parameter family $P(n,k)=P(1/n)$ independent of $k$ has eigenvector drift of order $n^{-2}$ but $F_{nk}=0$. Thus drift alone cannot establish the two-parameter curvature or its exponent. Open-path connection integrals also require a specified gauge or endpoint convention; they are not obtained by integrating a curvature component along a line.

# 5. Stress, composition, and what the instrument forgets

## Proposition 7 — Rank-one stress and tensor composition [T]+[V]

Let $B=uv^*$ with $\|u\|=\|v\|=1$, so $\|B\|_F=1$, and define

$$\mathcal S(B)=\tfrac12\|BB^*-B^*B\|_F^2.$$

Then

$$\mathcal S(B)=1-|u^*v|^2.$$

**Proof.** $BB^*=uu^*$ and $B^*B=vv^*$. Expanding the squared Frobenius norm gives $2-2|u^*v|^2$. $\square$

For normalized rank-one $B,C$,

$$\boxed{1-\mathcal S(B\otimes C)
=(1-\mathcal S(B))(1-\mathcal S(C)).}$$

Indeed, the left/right overlap of the tensor product is the product of the overlaps. If $v^*u\ne0$, the associated spectral idempotent $\Pi=uv^*/(v^*u)$ has norm $\kappa=1/|v^*u|$, hence $\mathcal S=1-\kappa^{-2}$ and $\log\kappa$ is additive under tensor composition. At zero overlap this idempotent is undefined, although the normalized matrix and its stress remain defined.

These formulas apply to the rank-one sector, or to a limit known to have that form. They are not an exact finite-depth composition law for arbitrary full-rank commutator stress. A scalar rescaling leaves a normalized diagnostic unchanged; a nonunitary basis change with an untransformed metric does not.

The earlier Kronecker calibration for the $\pi+e$ construction [2] is retained as a concrete application of this rank-one limit. It joins the selection theorem and the stress calculation without identifying stress with the arithmetic constant itself.

# 6. Resolution is another part of the instrument

For unit vectors $v,w$ and orthogonal rank-one projectors,

$$\|P_v-P_w\|_F^2=2(1-|v^*w|^2)=2\sin^2\theta.$$

Here $\theta=\arccos|v^*w|$ is a projective angle. Over the real numbers, $v$ and $-v$ represent the same line; over the complex numbers, every common phase does. A sphere of representatives must be quotiented accordingly.

Define $C_{\mathcal D}(\epsilon)$ as the largest size of an $\epsilon$-separated subset of a declared set of projective directions, with separation $\sin^2\theta\ge\epsilon$. This is the exact part of the directional-capacity construction [7].

## Proposition 8 — An exact capacity control [T]+[V]

For the full real projective line and $0<\epsilon\le1$,

$$C_{\mathbb{RP}^1}(\epsilon)
=\left\lfloor\frac{\pi}{\arcsin\sqrt\epsilon}\right\rfloor.$$

**Proof.** Represent lines by angles modulo $\pi$ and put $\alpha=\arcsin\sqrt\epsilon$. Adjacent cyclic gaps in any separated set must each be at least $\alpha$, so its size $m$ obeys $m\alpha\le\pi$. Conversely, $m=\lfloor\pi/\alpha\rfloor$ equally spaced lines attain the bound; their projective pairwise separation is at least $\alpha$. $\square$

**Boundary-safe census [T]+[V].** At $\epsilon=1,1/2,1/4$, the exact identities $\sin^2(\pi/2)=1$, $\sin^2(\pi/4)=1/2$, and $\sin^2(\pi/6)=1/4$ give capacities 2, 4, and 6. The verifier asserts these symbolically and never rounds a floating-point floor at these boundaries. Its remaining table entries are checked by the strict inequalities $\sin^2(\pi/m)>\epsilon>\sin^2(\pi/(m+1))$ at high precision.

| $\epsilon$ | 1 | 0.9 | 0.5 | 0.25 | 0.1 | 0.01 |
|:--|--:|--:|--:|--:|--:|--:|
| $C_{\mathbb{RP}^1}(\epsilon)$ | 2 | 2 | 4 | 6 | 9 | 31 |

For a finite set of distinct projectors, capacity equals its cardinality once $\epsilon$ falls below the minimum nonzero pairwise separation. For a continuous set such as $\mathbb{RP}^1$, it increases without bound as resolution improves even though the geometric set is fixed. These exact controls determine how a flat-versus-running census must be interpreted.

The programme's census discriminator is retained as a comparison of specified instruments, admissible direction sets and threshold ranges. It is not a proof of the classical Kakeya dimension conjecture, and a fixed geometric boundary alone does not force a constant packing capacity for all thresholds. The useful operational question survives: which apparent limit comes from the object, which from the admissible sampling, and which from resolution?

# 7. The hypersurface connection carried forward

The physical motivation is not added after the mathematics. The same distinction between spectrum, projector, and readout already occurs in the electronic-sheet model recovered from the light and hypersurface work [8,9]. It supplies a controlled realization of a relational response.

## Proposition 9 — Fixed levels, changing optical loading [T]+[C]+[V]

Take

$$H_\vartheta=\frac\Delta2(\cos\vartheta\,\sigma_z+\sin\vartheta\,\sigma_x),
\qquad D=d\sigma_z,\quad\Delta>0.$$

Its eigenvalues are fixed at $\pm\Delta/2$, while the lower projector $P_\vartheta=(I-H_\vartheta/(\Delta/2))/2$ obeys

$$g_{\vartheta\vartheta}=\tfrac12\operatorname{Tr}[(\partial_\vartheta P)^2]=\tfrac14,
\qquad |\langle e|D|g\rangle|^2=d^2\sin^2\vartheta.$$

**Proof.** Use $(\mathbf n\cdot\boldsymbol\sigma)^2=I$ for the unit vector $\mathbf n=(\sin\vartheta,0,\cos\vartheta)$. Its derivative has unit length and is orthogonal to it, giving the metric. The variance of $D$ in the ground state is $d^2-d^2\cos^2\vartheta$; in two levels that variance is the sole off-diagonal transition strength. $\square$

### Constitutive input [C]

In the declared ground-state, lossless, linear-response model away from resonance [8,9],

$$\chi_s(\omega)=\frac{N_s}{\varepsilon_0}
\frac{2\Delta d^2\sin^2\vartheta}{\Delta^2-(\hbar\omega)^2}.$$

This is a constitutive input derived in the earlier finite-dipole work [8,9]. It gives a physically meaningful orientation relative to a fixed probe. Rotating the state and every observable together would instead be a change of coordinates.

The separate color test [8] keeps a quadratic-touching spectrum fixed and changes its eigenprojector texture; its interband conductivity changes accordingly. The original script is included and rerun. It is a model calculation, not a perceptual-color dataset or a derivation of all material color.

## Proposition 10 — The interface retains loading from both sides [T]+[C]+[V]

For the declared block operator

$$\mathcal M=\begin{pmatrix}A&B&0\\C&D_\Sigma&G\\0&F&E\end{pmatrix},$$

assume the interior and exterior blocks $A,E$ are invertible. Eliminating their variables gives

$$\boxed{K_\Sigma=D_\Sigma-CA^{-1}B-GE^{-1}F.}$$

If only $E$ varies,

$$\delta K_\Sigma=GE^{-1}(\delta E)E^{-1}F.$$

**Proof.** The first and third block equations give $u_I=-A^{-1}Bu_\Sigma$ and $u_O=-E^{-1}Fu_\Sigma$. Substitute into the middle equation. Differentiate $E^{-1}E=I$ to obtain the sensitivity formula. $\square$

A separated spectral cluster of a smooth $K_\Sigma(s)$ has Riesz projector

$$P(s)=\frac1{2\pi i}\oint_\Gamma(zI-K_\Sigma(s))^{-1}\,dz,$$

$$\partial_sP=\frac1{2\pi i}\oint_\Gamma R(z)(\partial_sK_\Sigma)R(z)\,dz.$$

The latter follows by differentiating the inverse on a fixed separated contour. Thus external loading can move the selected boundary subspace. It need not do so for every perturbation; a scalar shift, for example, can leave projectors fixed. Positivity of a projector metric additionally requires the orthogonal setting of A5.

The earlier waveguide calculation provides the more concrete chain

$$\vartheta\longmapsto\chi_s\longmapsto
q\tan(qa)+k_0^2\chi_s-\kappa=0
\longmapsto u_{\mathrm{inside/outside}}\longmapsto P_u.$$

Its full profile is normalized in a declared transverse $L^2(dx)$ space [9]. We carry this relationship forward as a demonstrated model mechanism, not as a universal identification of an arithmetic recurrence with light propagation.

# 8. The rail integral, with its measure visible

For $0\le\psi<\pi/2$, set

$$\lambda_\pm=\sec\psi\pm\tan\psi,
\qquad t=\log\lambda_+=\operatorname{arcosh}(\sec\psi).$$

Then $\lambda_\pm=e^{\pm t}$ and $d\psi=\operatorname{sech}t\,dt$.

## Proposition 11 — Catalan as a weighted rail integral [T]+[V]

$$\boxed{G=\frac12\int_0^{\pi/2}\log\lambda_+(\psi)\,d\psi
=\frac12\int_0^\infty t\operatorname{sech}t\,dt.}$$

**Proof.** For $t>0$, expand $\operatorname{sech}t=2\sum_{j\ge0}(-1)^je^{-(2j+1)t}$. The sum of the integrals of the absolute terms $t e^{-(2j+1)t}$ is $\sum_j(2j+1)^{-2}<\infty$, so termwise integration is valid. Each integral is $(2j+1)^{-2}$. $\square$

A finite cutoff has the explicit positive remainder

$$\frac{(T+1)e^{-T}}{1+e^{-2T}}
\leq\frac12\int_T^\infty t\operatorname{sech}t\,dt
\leq(T+1)e^{-T}.$$

This follows from $\tfrac12\operatorname{sech}t=e^{-t}/(1+e^{-2t})$. The bounds close the endpoint of this integral; they are unrelated to the still-separate Rice–Mele determinant endpoint problem.

For the electronic projector of Proposition 9, $ds=|d\vartheta|/2$. A monotone path $\vartheta(\psi)$ therefore gives

$$\int\log\lambda_+\,ds
=\frac12\int_0^{\pi/2}\log\lambda_+(\psi)
\left|\frac{d\vartheta}{d\psi}\right|d\psi.$$

The unit-speed identification $|d\vartheta/d\psi|=1$ is sufficient to recover $G$. It is not necessary for a single integral equality: other weights can have the same weighted integral. The normalized uniform angular average is $4G/\pi$, not $G$; normalization is part of the claimed observable.

**Physical identification [H].** The color/hypersurface construction supplies actual projector motion. The recurrence supplies the rail. A physical model that locks their angles or derives an equivalent weight would connect them. None of the recovered equations forces that locking. The precise open task is to derive the measure from a coupling or an admissibility condition, then evaluate the resulting integral without choosing the weight to obtain a desired constant.

# 9. What is closed, what is carried forward

The finite mathematical contribution is complete under the stated assumptions: the gapped-Gram selection theorem and finite bound; the modal corollary; the tied-growth controls; conserved pairing and readout sensitivity; coboundary bookkeeping; the exact Catalan cancellation; rational compatibility and a nonzero eigenline-curvature certificate at $(n,k)=(2,0)$ for the reconstructed field; the exact band-resolved curvature expansion; kernel-and-output selection with a dual certificate; rank-one stress composition; projective-circle capacity; boundary reduction; and the rail integral with a controlled remainder.

The earlier challenge-wide calibration remains a source of applications [2]. Its actual implemented scope was Questions 1, 2, 3, 5, 6, 7 and 8 plus Apéry's recurrence. Question 4's inhomogeneous sum was outside that diagnostic. We do not advertise the old listings as newly rerun or repeat their obsolete tied-growth prediction. The present release is self-contained for the statements it checks.

The arithmetic continuation is also explicit. The Atlas trajectory score is supplemented by primitive denominator height, and the numerator is tested for retained output after cancellation. The sampled trajectories do not establish irrationality. A successful continuation must construct nonvanishing integer linear forms tending to zero, with a uniform bound that includes the cost of clearing denominators.

The physical continuation is explicit [H]. Color and polarization provide projectors and probes; an interface supplies a concrete place where internal and external loading meet; directional capacity supplies an operational resolution test; and the dual pairing supplies a model of retained information despite directional selection. Knot and character-variety work motivates constraints on admissible continuation, but no identification of colored-Jones labels with optical hue or an $SU(3)$ degree of freedom is made here. Each bridge must specify its map.

The gravity continuation [H] asks for an action that couples the boundary operator to a physical metric, so metric variation defines the stress-energy response. Deriving that action and comparing geometric and energetic loading on the same system remain future work. The finite results here supply operator and boundary data for that question.

**Conclusion.** The rail describes a growth scale. The projector describes what remains distinguishable. The pairing describes what a readout can retain. The boundary describes which part of the larger system enters that readout. The Ramanujan Challenge lets these statements be calibrated against exact arithmetic, and the optical model shows why their distinction is physically worth keeping. The programme remains *Subspaces Before Space*: begin with the operator, retain its relational structure, and require every later interpretation to pass through an explicit map. The present paper closes the selection-and-pairing layer and the band-resolved curvature expansion. The numerator tells us which components cancel; the retained denominator tells us whether that cancellation remains an instrument. Keeping those relationships together gives both the arithmetic and physical continuations a defined starting point.

# Appendix A. Exact certificates and reproducibility

At $(2,0)$, the monic characteristic polynomial is $p(z)=q(z)/211680$, where

$$q(z)=211680z^3-8545334z^2+26602699z-871200.$$

Its signs at $0,1,4,40$ are $-,+,-,+$, so it has one root in each of $(0,1)$, $(1,4)$ and $(4,40)$. A cubic has no further roots; in particular these three roots are real and simple.

The curvature at an eigenvalue $z$ is $a(z)/b(z)$, with the following common-scaled remainder polynomials:

$$\begin{aligned}
a(z)={}&-315692356934422501517904z^2\\
&+971776779958348659730344z\\
&+148197892949119993795200,
\end{aligned}$$

$$\begin{aligned}
b(z)={}&8036886764505094218878498z^2\\
&-32312696044376681193609433z\\
&+10593126561603564973615860.
\end{aligned}$$

Exact Euclidean reduction over $\mathbb Q[z]$ gives

$$\gcd(a,q)=\gcd(b,q)=1.$$

Thus $a$ and $b$ are nonzero at every root of $q$. These remainder polynomials come from the spectral-idempotent formula in Theorem 6 and implicit differentiation of $p(z)=0$, as implemented in `verify.py`; they are not fitted from eigenvalue samples. At decreasing eigenvalue magnitude the numerical curvatures are approximately $-0.04034491$, $0.02146000$ and $0.01888491$.

The main verifier passes 22 named checks, with additional reconstruction and color-model checks in separate logs. At depth 80 the largest error of the three official Catalan ratios is approximately $3.06\times10^{-130}$ at 180-digit precision. The independent curvature finite-difference errors for steps $10^{-3}$, $5\times10^{-4}$ and $2.5\times10^{-4}$ are $2.7021\times10^{-7}$, $6.7552\times10^{-8}$ and $1.6888\times10^{-8}$, respectively. These decimal values carry [V], not [D].

`python verify.py` reproduces the exact Catalan cancellation, the field identities, the algebraic curvature certificate, independent numerical curvature checks, both product orders, tensor controls, the scalar boundary check, and the rail integral. `python color_check.py` reproduces the color-model checks. `python rebuild_cmf.py` independently regenerates the explicit rational matrices from the shift machinery. Dependencies and tested versions are in the code package. Figures are generated from the recorded results by `make_figures.py`.

An exact symbolic certificate is a finite identity over rational functions or algebraic numbers; a decimal test is not such a certificate. The positive integral and initial-value evaluation needed for the full Catalan limit are cited from [1]. No new Lean certificate is claimed. This release does not depend on the irrationality claim in Z.-W. Sun, *Catalan's constant is irrational*, [arXiv:2609.04176v1](https://arxiv.org/abs/2609.04176v1), submitted 3 September 2026. That claim is not an input to any result here.


# Appendix B. Exact proof of the band expansion

Set $t=1/n$ and $S(t)=\operatorname{diag}(1,t^{-1},t^{-2})$. Define

$$B(t)=S^{-1}T(1/t,0)S,$$
$$X(t)=S^{-1}T_n(1/t,0)S,\qquad
Y(t)=S^{-1}T_k(1/t,0)S.$$

Crucially, $T_n,T_k$ are differentiated **before** this change of basis. We do not replace them by ordinary derivatives of $B$ and thereby change the ambient connection. The curvature sum-over-states formula is invariant under this pointwise similarity when all its factors are transformed together.

Exact rational expansion gives

$$B=B_0+tB_1+O(t^2),\quad X=tX_1+t^2X_2+O(t^3),\quad Y=tY_1+t^2Y_2+O(t^3),$$

with

$$B_0=\begin{pmatrix}17&24&0\\12&17&0\\8&12&1\end{pmatrix},\qquad
B_1=\begin{pmatrix}9&-45&-30\\89/2&23&-20\\113/2&113/2&-10\end{pmatrix},$$

$$X_1=\begin{pmatrix}0&-24&0\\12&0&0\\16&12&0\end{pmatrix},\qquad
X_2=\begin{pmatrix}-9&90&90\\0&-23&40\\113/2&0&10\end{pmatrix},$$

$$Y_1=\begin{pmatrix}-26&-18&12\\-19&-14&8\\-13&-11&4\end{pmatrix},\qquad
Y_2=\begin{pmatrix}41&77&-44\\-29&16&-3\\-125/2&-23&16\end{pmatrix}.$$

All transformed entries are analytic near $t=0$. The eigenvalues of $B_0$ are the three distinct values stated above, so their local branches and spectral projectors are analytic. Write them as $\lambda_b+t\ell_b+O(t^2)$ and $P_b+tP_b^{(1)}+O(t^2)$. The zeroth-order projectors and first corrections are

$$P_b=\prod_{c\ne b}\frac{B_0-\lambda_c I}{\lambda_b-\lambda_c},\qquad
\ell_b=\operatorname{Tr}(P_bB_1),$$

$$P_b^{(1)}=\sum_{c\ne b}\frac{P_cB_1P_b+P_bB_1P_c}{\lambda_b-\lambda_c}.$$

The first formula follows by polynomial interpolation on the simple spectrum. The correction follows by differentiating the eigenprojector equations and their normalization, or by differentiating the resolvent and taking its residues.

For each pair set

$$N_{bc}(t)=\operatorname{Tr}\bigl(P_b(t)X(t)P_c(t)Y(t)-P_b(t)Y(t)P_c(t)X(t)\bigr).$$

Its coefficient of $t^2$ is

$$N_{bc}^{(2)}=\operatorname{Tr}(P_bX_1P_cY_1-P_bY_1P_cX_1).$$

Its coefficient of $t^3$ is obtained by replacing exactly one projector by its first correction or one derivative factor by $X_2$ or $Y_2$, retaining the antisymmetric subtraction. `atlas/asymptotic.py` supplies all eight terms explicitly. With $d_{bc}=\lambda_b-\lambda_c$, the two curvature coefficients are

$$a_b=\sum_{c\ne b}\frac{N_{bc}^{(2)}}{d_{bc}^2},$$

$$b_b=\sum_{c\ne b}\left(\frac{N_{bc}^{(3)}}{d_{bc}^2}
-\frac{2(\ell_b-\ell_c)N_{bc}^{(2)}}{d_{bc}^3}\right).$$

Substituting the six displayed rational matrices and the exact projectors gives

$$a=\left(-\frac{5\sqrt2}{16},0,\frac{5\sqrt2}{16}\right),$$

$$b=\left(-\frac9{16}+\frac{95\sqrt2}{64},\frac98,-\frac9{16}-\frac{95\sqrt2}{64}\right).$$

Analyticity and the nonzero limiting gaps justify the remainder $O(t^4)$. The nonzero leading coefficients then establish the asserted exponents. No eigenvector-drift inference or commuting derivative decomposition is needed. $\square$

**Independent numerical control.** A separate left/right eigenvector implementation evaluates the original-frame curvature at $n=512,1024,2048$ using 100-digit arithmetic. After subtracting the two proved terms, successive remainder ratios lie between 15.7 and 16.3 in every band, as expected for $n^{-4}$. This is a control of the implementation, not the proof of the exponents. The theorem gives an asymptotic remainder order; it does not provide an explicit uniform remainder constant or threshold.


## Scope check on the recovered derivative relation [V: exact]

The strong finite version of the B81 relation would require

$$T_n=T_k\Lambda+D,\qquad [T,\Lambda]=[T,D]=0.$$

At $(2,0)$, $T$ has simple spectrum. Every commuting matrix is therefore a polynomial of degree at most two in $T$. Substitute $\Lambda=aI+bT+cT^2$ and $D=dI+eT+fT^2$. Vectorization gives a rational $9\times6$ linear system. Its coefficient rank is 6; its augmented rank is 7. `atlas/certificates.json` supplies a rational dual vector $y$ with $y^TC=0$ and $y^T\operatorname{vec}(T_n)=1$.

Thus this exact finite decomposition cannot be used at that regular point. A leading-order asymptotic relation is a separate question. The earlier CMF paper itself reports nonidentical finite ratios approaching common limits, which motivates that weaker reading. The exact lattice plaquette identity remains intact; commuting with a single spectral matrix is not by itself a proof of lattice flatness.

The useful outcome is a repaired proof route: the exact band expansion above directly establishes the cancellation the historical cards were trying to explain, without assuming this stronger decomposition.


# Appendix C. Trajectory arithmetic and reproducibility [V]

Starting at $(0,0)$, a direction $(a,-b)$ applies $a$ successive $n$-shifts followed by $b$ successive downward $k$-shifts in each block. For a column-state transport step $C$, the dual readout evolves by right multiplication with $C^{-1}$. The code uses its adjugate projectively, checks the determinant is nonzero, clears denominators exactly and removes common integer factors. The same initial two-row readout is retained throughout.

At $k=0$, $T(n,0)^{-1}$ is projectively the official polynomial matrix $M(n)$, so direction $(1,0)$ reproduces the prior arithmetic test. On other paths, closeness to $G$ is measured and certified at the sampled endpoints; no new all-depth limit theorem for those directions is assumed.

All three columns were evaluated after 10, 20, 40 and 80 blocks in seven directions. The following table chooses the column with the smallest absolute primitive linear form at 80 blocks. Different directions have different elementary-step costs.

| Direction | Elementary steps | Column | $\log_{10}q$ | $\log_{10}|G-p/q|$ | $\log_{10}|qG-p|$ |
|:--|--:|--:|--:|--:|--:|
| (1,0) | 80 | 2 | 302.944 | -133.452 | 169.492 |
| (0,-1) | 80 | 2 | 135.374 | -11.317 | 124.057 |
| (1,-1) | 160 | 1 | 436.347 | -217.664 | 218.683 |
| (1,-2) | 240 | 2 | 606.409 | -258.705 | 347.704 |
| (1,-3) | 320 | 2 | 739.089 | -285.196 | 453.892 |
| (2,-1) | 240 | 2 | 729.050 | -368.716 | 360.334 |
| (3,-1) | 320 | 3 | 1038.027 | -505.423 | 532.605 |


The exact pairs and positive-series rational enclosure of $G$ are in `atlas/trajectory_results.json`. All 84 sampled primitive linear forms have a certified nonzero sign and absolute value greater than 1; none supplies the shrinking integer forms needed here. The logarithms are numerical presentations of exact rational bounds.

The finite error-to-height score

$$\eta=-\frac{\log|G-p/q|}{\log q},\qquad q>1,$$

compares cancellation with primitive denominator size. The best sampled column at 80 blocks in direction $(2,-1)$ gives roughly $\eta=0.506$, compared with about $0.441$ for the best-linear-form column of $(1,0)$. This is a measurable improvement in this score, still below 1. A finite score is not an irrationality exponent; a proof needs a uniform shrinking nonzero integer-linear-form sequence. Approximation speed alone, the object measured by B69, is insufficient.


## Exact enclosure behind the arithmetic tests [T]+[V: exact]

Here “certified” means exact rational interval bounds obtained with arbitrary-precision integers, rather than the symbolic polynomial gcd certificate used in §4. Neither usage implies Lean certification. The decimal table is backed by these rational intervals. From

$$G=\int_0^1\frac{-\log x}{1+x^2}\,dx,
\qquad \frac1{1+x^2}=\sum_{j=0}^{\infty}\frac{(1-x^2)^j}{2^{j+1}},$$

monotone convergence gives $G=\sum_{j\ge0}J_j/2^{j+1}$, where $J_j=\int_0^1(-\log x)(1-x^2)^j\,dx$. These positive rational coefficients obey

$$J_j=I_jH_j,\qquad I_0=H_0=1,$$
$$I_{j+1}=\frac{2j+2}{2j+3}I_j,\qquad H_{j+1}=H_j+\frac1{2j+3}.$$

For completeness, put $K_j(a)=\int_0^1x^{a-1}(1-x^2)^j\,dx=2^j j!/[a(a+2)\cdots(a+2j)]$ for $a>0$. Integration by parts proves this product formula, and differentiation at $a=1$ gives $J_j=-K_j'(1)=I_jH_j$. Since $0<J_j\le1$, the rational partial sum $S_K$ satisfies

$$S_K<G\le S_K+2^{-K}.$$

The run uses $K=3565$. For each recorded primitive $(p,q)$, multiplication by the positive integer $q$ and subtraction of $p$ encloses $qG-p$ exactly. Both endpoints have the same sign and the nearer endpoint has absolute value greater than 1 in all 84 cases. Thus neither floating-point cancellation nor a fitted slope decides the reported failure of these samples to produce small integer linear forms.

Run `python run_all.py` in the proof/code package to rerun the original checks, the exact asymptotic expansion, the seven trajectory tests, and the independent certificates. The `atlas` directory includes exact results and the recovered source/card index. No historical papers are bundled. The code uses exact rational arithmetic for the linear-form enclosures and algebraic arithmetic for the curvature coefficients; the reported decimal logarithms and remainder-ratio controls remain [V].

# References

```{=latex}
\begingroup
\fontsize{9.5}{11.5}\selectfont
\setlength{\parskip}{3pt}
```

1. Ramanujan Machine Group, **Ramanujan Challenge Proofs**, supplied August 2026 proof release (the 02_08 PDF). The exact source filename and hash are recorded in the code-package manifest. Question 5; §3.9, Corollaries 1–3; §8, Lemmas 16–19 and Theorem 5. Repository named in the source: [RamanujanChallengeSolutions](https://github.com/RamanujanMachine/RamanujanChallengeSolutions). The supplied PDF is the reference version used here.
2. J. N. Beasley, **The Companion-Matrix Projector Diagnostic: An Exact Order-2 Theorem, a Convergence Criterion, and a Complete Calibration Against the Ramanujan Machine Challenge Proofs**, August 2026. Supplied `projector_calibration_merged (3).pdf`. This paper retains its positive selection mechanism and replaces its unconditional tied-growth converse.
3. J. Beasley, **Spectral Stress on a Conservative Matrix Field**, August 2026. Supplied historical edition `paper_XI_spectral_stress_CMF (19).pdf`. Source of the subsequent asymptotic and exceptional-point programme. Theorem 6a gives an exact derivation of its recognized band behavior.
4. M. A. Oancea, T. B. Mieling and G. Palumbo, **Quantum geometric tensors from sub-bundle geometry**, *Quantum* 10, 1965 (2026), [doi:10.22331/q-2026-01-14-1965](https://doi.org/10.22331/q-2026-01-14-1965). General subbundle geometry and projected connections.
5. T. Raz et al., **From Euler to AI: Unifying Formulas for Mathematical Constants**, NeurIPS 2025; [arXiv:2502.17533v4](https://arxiv.org/abs/2502.17533v4). Prior unification and transport framework; this follow-up does not claim that framework as new.
6. NIST Digital Library of Mathematical Functions, **Meijer G-function: definition, identities and differential equation**, [Chapter 16](https://dlmf.nist.gov/16). The concrete reduction and its official anchor are supplied in [1,2] and rebuilt here.
7. J. Beasley, **The Price of a Direction**, Lemma 2.1 and CENSUS work. Source of the projector-distance/operational-capacity viewpoint; Proposition 8 states the precise capacity used in this paper.
8. J. Beasley, **Light Keeps the Ledger**, and **COLOR-PROJECTOR-CHECK-01**. Recovered model check of fixed-spectrum optical response. Its external calibration is C.-g. Oh et al., *Science Advances* 12, eady2033 (2026), [doi:10.1126/sciadv.ady2033](https://doi.org/10.1126/sciadv.ady2033).
9. J. Beasley research programme, **The inside, the surface, and the outside: a controlled test suite**, 5 September 2026, `HYPERSURFACE-TESTS-01`, §§1–4. Source of the sheet and inside–outside mode realization. This citation does not imply that its then-uncompiled Lean candidates are certified.

10. J. N. Beasley, **The Operator-First Atlas**, recovered 90-card archive and **AK Atlas Probe**. Cards B45, B69, B75, B78, B81, B82 and B83 inform the present tests; the earlier 53-bridge edition is a distinct source. Source hashes and all 90 card titles are indexed in the code package. Historical conjectures are not adopted as hypotheses without an explicit statement.

**Acknowledgment.** The challenge organizers' release of complete proofs made this calibration possible. This follow-up was developed with AI assistance for reconstruction, symbolic verification, computation and drafting. Proof grades refer to the evidence supplied, not to the identity of the assistant. No publication-wide priority claim is made for the standard linear algebra or differential geometry used here.

```{=latex}
\endgroup
```
