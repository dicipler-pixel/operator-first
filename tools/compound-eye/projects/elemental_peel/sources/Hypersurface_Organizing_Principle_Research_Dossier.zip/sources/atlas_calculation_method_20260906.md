# What to keep, what to eliminate, and what to read

Jeromie N. Beasley research programme · Method synthesis · 6 September 2026

This note gathers the computational methods recovered from the Operator-First Atlas through the current transport, Catalan, light, Smith-boundary, gravity, Kakeya, and Offset work. It proposes a common way of organizing calculations. It is not a new universal field equation, a claim to have invented the classical tools it uses, or a fresh certification of every historical Atlas card.

The practical principle is: **choose the observable; preserve the relations that determine it; eliminate the rest exactly; carry the remaining error and readout together.**

## 1. Offset in one equation

For a finite number-conserving Gaussian region with strict covariance domain \(0<C_A<I\),

\[
\boxed{\tau_A=\log\frac{P_A(\mathrm{empty})}{P_A(\mathrm{full})}}
\]

where \(P_A(\mathrm{empty})=\det(I-C_A)\) and \(P_A(\mathrm{full})=\det C_A\). This is the complete finite trace of the one-particle entanglement Hamiltonian. Its scalar coefficient is \(\tau_A/|A|\); the selected central rung, ladder phase, spacing and full trace remain separate observables.

For computation the corresponding bounded coordinate is especially useful:

\[
\boxed{\gamma_A=\tanh(\tau_A/2)
=\frac{P_A(\mathrm{empty})-P_A(\mathrm{full})}
{P_A(\mathrm{empty})+P_A(\mathrm{full})}.}
\]

Both probabilities must be positive. Their sum is not generally one: this is the normalized contrast of the two formation events. A zero reading means equal probabilities. Their tiny common scale cancels.

For the fixed physical cut and positive hoppings of the odd Rice–Mele family, hold \(ab=p\) and \((a-b)^2+v^2=e^2\) fixed and write \(a-b=e\cos\theta\), \(v=e\sin\theta\). The written all-size theorem says

\[
\gamma_{2n+1}(\theta)=\sin\theta\,\gamma_{2n+1}(\pi/2),\qquad n\ge0.
\]

Thus one reference calculation per block size determines the entire isospectral circle. It is the normalized contrast, rather than the logarithmic trace itself, that follows the sine law. The fixed-parameter magnitude limit is

\[
|\tau_{2n+1}|\longrightarrow
2\operatorname{artanh}\frac{|v|}{\sqrt{E_{\min}E_{\max}}}.
\]

The sign has a size-parity dependence. This formula is dimensionless and does not by itself specify a physical cosmological constant.

## 2. An exact intersection with the Smith-chart idea

Put \(z=P_A(\mathrm{empty})/P_A(\mathrm{full})>0\). Then

\[
\gamma=\frac{z-1}{z+1},\qquad
z=\frac{1+\gamma}{1-\gamma},\qquad
\tau=\log z=2\operatorname{artanh}\gamma.
\]

This is exactly the scalar Cayley transformation used in the normalized impedance/reflection coordinate of the Smith chart. Here its input is probability odds. In the optical note its input is normalized impedance, which can be complex. The coordinate algebra is shared; no equation here identifies formation odds with a physical impedance or identifies the corresponding projector metrics.

The payoff is a choice of coordinates for the same calculation: ratios multiply, logarithms add, and bounded contrasts compose rationally. Near \(|\gamma|=1\), converting back to the trace is ill-conditioned because \(d\tau/d\gamma=2/(1-\gamma^2)\). A useful implementation must retain logarithmic data or increase precision there, rather than round the contrast to one.

This connection was checked by exact symbolic algebra in this session. It is a repackaging of established identities and the existing Offset definition, not a new physical derivation.

## 3. Composition with the correlation correction retained

For independent regions, empty and full formation probabilities factor separately. Therefore

\[
\tau_{A\cup B}=\tau_A+\tau_B,
\qquad
\gamma_{A\cup B}=\frac{\gamma_A+\gamma_B}{1+\gamma_A\gamma_B}.
\]

For example, \(\gamma_A=1/5\) and \(\gamma_B=3/10\) give \(\gamma_{A\cup B}=25/53\), exactly. This is composition of probability contrasts, not optical gain.

For correlated disjoint regions, define the correction rather than discarding it:

\[
\delta(A,B)=\tau_{A\cup B}-\tau_A-\tau_B.
\]

Then the exact update is

\[
\gamma_{A\cup B}=\tanh\!\left(
\operatorname{artanh}\gamma_A+
\operatorname{artanh}\gamma_B+\delta(A,B)/2\right).
\]

Its associativity bookkeeping follows just by expanding the definition:

\[
\delta(A,B)+\delta(A\cup B,C)
=\delta(B,C)+\delta(A,B\cup C).
\]

All involved formation probabilities must be defined and positive. This equality is a telescoping identity; it neither determines the correction nor implies locality, independence or a constant contribution per boundary cell. It gives a useful consistency check for any implementation that joins regions in different orders.

## 4. The common mathematical engine already in the Atlas

Atlas B78 is a particularly strong reusable tool:

\[
f(H)=\frac{1}{2\pi i}\oint_\Gamma f(z)(zI-H)^{-1}\,dz.
\]

For a contour enclosing an isolated spectral cluster, the analogous cluster integral with \(f=1\) gives its Riesz projector; \(f=z\) gives its weighted operator contribution. A holomorphic logarithm gives a logarithmic functional where its branch and domain are valid. The displayed full functional calculus assumes the contour encloses the relevant spectrum and the function is holomorphic in the required region.

This avoids differentiating arbitrarily phased eigenvectors. A collision inside an isolated cluster does not invalidate the cluster integral. A pole crossing the contour or a logarithm losing its branch does. A Riesz idempotent for a non-Hermitian operator need not be an orthogonal projector, so its bilinear geometry cannot automatically inherit positivity.

The integral is classical resolvent functional calculus. The programme's useful organizational choice is to select the cluster and readout first, then use the same reduction and control discipline across different realizations.

## 5. The most useful elementary calculation: eliminate an interior

For a block matrix with invertible interior block,

\[
M=\begin{pmatrix}M_{ii}&M_{i\partial}\\M_{\partial i}&M_{\partial\partial}\end{pmatrix},
\quad
M_{\mathrm{eff}}=M_{\partial\partial}
-M_{\partial i}M_{ii}^{-1}M_{i\partial},
\]

\[
\det M=\det M_{ii}\det M_{\mathrm{eff}}.
\]

Interior variables are removed while their loading remains in the effective boundary matrix. Source terms also have to be transformed when solving an inhomogeneous system. In an eigenvalue problem the elimination is applied to \(H-zI\), and the resulting effective matrix generally depends on \(z\). A smaller constant matrix does not automatically retain the entire original spectrum.

This is the same operation appearing in the Atlas seam, the Smith-boundary note, the inside/surface/outside model, and the finite Offset reduction. In Offset a common interior determinant cancels in the symmetry-related ratio. For a general model that cancellation must be established; eliminated determinant factors cannot simply be dropped.

Repeated elimination may be regrouped where the required blocks are invertible. A computational diagram could therefore attach effective matrices, determinant factors, sources and error bounds to exposed interfaces, with elimination as a legal replacement rule. That would be a genuine calculational diagram system rather than a suggestive picture. Schur/Feshbach reduction and related network methods already supply much of its algebra.

## 6. Give the lever cascade an exact sensitivity calculation

For a scalar nearest-neighbor tridiagonal problem, elimination gives pivot updates

\[
q_{j+1}=a_{j+1}-\frac{b_jc_j}{q_j}.
\]

Each step is a fractional linear transformation represented projectively by

\[
\begin{pmatrix}a_{j+1}&-b_jc_j\\1&0\end{pmatrix}.
\]

For two inputs propagated with the same coefficients and nonzero pivots,

\[
q_{j+1}-\widetilde q_{j+1}
=\frac{b_jc_j}{q_j\widetilde q_j}
(q_j-\widetilde q_j).
\]

Consequently

\[
\boxed{q_m-\widetilde q_m
=(q_0-\widetilde q_0)
\prod_{j=0}^{m-1}\frac{b_jc_j}{q_j\widetilde q_j}.}
\]

This is an exact way to express progressive reduction in a cascade. The product determines whether the input error contracts or grows. More stages alone do not guarantee precision. New rounding errors introduced at intermediate stages contribute additional propagated terms.

For the matrix \(\left(\begin{smallmatrix}3&1&0\\1&4&2\\0&2&5\end{smallmatrix}\right)\), the exact pivots are \(3,11/3,43/11\); their product gives determinant 43. No diagonalization is needed.

The physical finite covariance in Offset is dense. This scalar nearest-neighbor recurrence is therefore a worked model of the method, not an already-proved recurrence or sharp remainder bound for that covariance. A useful next construction would derive the appropriate structured Hankel/Toeplitz or boundary-prediction recursion, then prove its sensitivity bound. The existing sine law would carry a valid equal-hopping remainder estimate along the isospectral family, with its stated parameter domain.

## 7. The recovered methods, grouped by the work they save

| Method carried forward | Practical calculation rule | Source and present limit |
|:--|:--|:--|
| Choose the observable before a score | Write its domain, scale, pairing and readout; check that it distinguishes the target cases. | Atlas calibration; Offset M01–M12. A highly persistent descriptor can still be irrelevant to the target. |
| Lift a failing descriptor | Track a spectral cluster projector, then a legal contour functional or holonomy when individual eigenvectors become ill-conditioned. | Atlas lifting ladder, B35/B65/B78/B79. Larger lifts retain less detail; loop observables need their own domains. |
| Subspaces before coordinates | Use projectors and principal angles to remove arbitrary eigenvector signs, phases and internal basis rotations. | Atlas L1; transport selection theorem. Fixed spectrum does not imply fixed subspace. |
| Specify the pairing | Carry the metric under nonunitary basis changes and the dual readout under every frame change. | B83; transport Theorems 3–4. Ordinary Euclidean singular directions are not invariant under arbitrary nonunitary gauges. |
| Separate transport, obstruction and mixing | Use the actual \(A+D_0+\varepsilon E\) construction and local interfaces instead of one global stress score. | B84; Earth–Moon recap. Roles and skew character may only hold to the stated gradient order. |
| Preserve sign and orientation | Keep phase, signed determinants or an orientation sheet when a Gram matrix or norm has discarded them. | B66/B67/B71. A distance does not generally determine holonomy. |
| Test admissible moves | Keep exactly the claimed invariants fixed, hold the physical probe/cut fixed, and examine the residual along the family. | B10; Offset moduli circle; fixed-spectrum optical response. A simultaneous rotation of state and probe is a coordinate change. |
| Compare symmetry partners first | Extract the odd part or ratio before computing large common contributions. | Offset \(v\leftrightarrow-v\), empty/full determinants; Smith reciprocity. Cancellation alone does not bound the surviving part. |
| Reduce to the seam | Eliminate interiors by Schur complements while retaining determinants, sources and coupling terms. | B48; Smith proof; transport Proposition 10; Offset odd-block reduction. Requires legal inverses. |
| Cancel nuisance terms without losing the answer | Solve \(Ac=0\) together with a retained-output condition \(bc\ne0\). | AK Atlas probe; Catalan exact selection. A dual row-space witness can certify impossibility for the stated finite problem. |
| Use exact spectral projectors | For simple roots, compute \(P(\lambda)=\operatorname{adj}(\lambda I-H)/p'(\lambda)\), or polynomial projectors, and reduce identities modulo \(p\). | B45/B78; exact curvature certificate. Individual simple-root formula fails at repeated roots; cluster contours are a different route. |
| Inspect pair numerators before gap denominators | Derive which leading terms cancel before fitting a decay exponent. | B24/B25/B75/B82; Catalan expansions. Log-determinant product weights and susceptibility gap weights are distinct. |
| Balance asymptotics in the correct frame | Set \(t=1/n\), balance matrix powers, differentiate in the original frame or transform the connection consistently. | Catalan exact expansions and B83. This proved outer \(n^{-2}\) and middle \(n^{-3}\) behavior on the specified trajectory. |
| Exploit reciprocal symmetry | Replace \(t+t^{-1}\) by a new variable to halve a reciprocal polynomial's degree. | B51; rail parametrizations. The contour, branch and interval still determine which roots are relevant. |
| Count at a declared resolution | Separate sample cardinality, packing capacity, census depth and the full trace. | B16; Price of a Direction; transport projective-circle control. A fixed continuous direction set can have increasing capacity as resolution improves. |
| Measure the first allowed response | Use symmetry to determine which observable is odd or even in a perturbation; choose a channel that can respond at the order of interest. | B89; Smith off-diagonal reciprocity response. Breaking a symmetry permits a term but does not force a nonzero coefficient. |
| Read a zero's order before fitting its square root | If the relevant soft eigenvalue has a zero of order \(m\), its line-element magnitude has exponent \(m/2\). | B90 and gravity's explicit hypotheses. Generic crossing/tangency, nullity and a nonvanishing hard eigenvalue matter; an exponent alone does not diagnose every open system. |
| Price the arithmetic | Clear denominators, remove common factors, and measure the primitive integer linear form rather than ratio accuracy alone. | B69; seven Catalan trajectories. A spectral speed improvement is not an irrationality proof. |
| Let exact obstructions prune a search | Turn a failed candidate into a rank witness, forbidden configuration, or learned constraint; avoid recomputing equivalent states. | AK probe; Catalan dual certificate; Earth–Moon lazy obstruction search. Diagnostic Atlas scores guide branching, while the target's certificate decides success. |
| Keep the residual through composition | Preserve shared coupling/correlation terms when joining pieces; test sensitivity from one stage to the next. | Gluing, lever suggestion, Smith note, proposed Cayley update here. Neither independence nor sharp contraction is automatic. |
| Upgrade the whole evidence record | Carry positive/null/false controls, precision and mesh checks; distinguish exact algebra, numerical convergence, written proof and Lean kernel checks. | Atlas L0; Offset method notes and correction ledger. A passed formal theorem proves its encoded premises and conclusion. |

## 8. One exact criterion that should precede expensive searches

For a rational nuisance matrix \(A\) and retained row \(b\), let \(\Pi\) be the orthogonal projector onto \(\ker A\). Then

\[
\boxed{\exists c:\ Ac=0,\ bc=1\quad\Longleftrightarrow\quad b\Pi b^T>0.}
\]

If the right side is positive, \(c=\Pi b^T/(b\Pi b^T)\) is a witness. If it vanishes, a solution of \(A^Ty=b^T\) certifies that every allowed cancellation also kills the desired output. This follows from the row-space/kernel decomposition and is standard finite linear algebra used in the recovered probe.

Example: \(A=\left(\begin{smallmatrix}1&1&0\\0&1&1\end{smallmatrix}\right)\), \(b=(1,0,0)\) gives \(c=(1,-1,1)^T\). This exact example and the criterion's witness were checked in this session.

In the actual Catalan application this criterion retains Catalan while cancelling two nuisance components. It reconstructs the existing readout. Cancelling the entire formal error polynomial also cancels its denominator, so partial asymptotic cancellation with controlled integer height is the meaningful subsequent target.

## 9. What a reusable implementation should contain

The proposed implementation is a collection of small, composable operations rather than one solver for every paper:

1. **Select:** choose a cluster, a covariance restriction, or a constraint kernel, with its retained observable.
2. **Reduce:** apply a proved symmetry quotient, exact nuisance cancellation or Schur elimination.
3. **Move:** transport through an explicitly admissible parameter family while keeping the probe and required invariants fixed.
4. **Compose:** combine interfaces or transports, retaining sources, determinant factors, order, frames and correlation corrections.
5. **Read:** apply the declared dual pairing, determinant ratio, contour trace, phase or count.
6. **Control:** return the result together with its domain, exact witness or numerical error estimate, and a control that could reject it.

Each operation should emit a short certificate that can be checked separately. The resulting diagrams would be executable replacement rules, with exposed ports indicating exactly which data a later composition needs. Existing projector calculus, Schur/Feshbach reduction, Riccati/Möbius updates and exact linear algebra provide the primitives. The proposed contribution is their consistent selection and composition around this programme's observables; novelty of a new implementation or theorem must be established separately.

For Offset the first practical target is to reuse the equal-hopping reference along the exact sine-law circle and evaluate boundary prediction errors directly, with controlled arithmetic. For the optical cascade the first target is a passive boundary response and a derivative/error bound. For arithmetic cancellation it is a retained numerator with an integer-height budget. Those targets use a common discipline without equating their physical or arithmetic outputs.

## 10. Verification and remaining work

This session performed exact SymPy 1.14.0 checks of the Cayley inverse and product-composition identities, the scalar cascade derivative, the rational contrast example, a tridiagonal Schur determinant, and a kernel-selection witness. It did not rerun the existing paper suites or Lean, implement the proposed general toolkit, prove the sharp Offset remainder, prove Catalan irrationality, or derive cosmological calibration.

The following complete small script reproduces the new elementary checks. It requires Python and SymPy 1.14.0; it does not require GitHub.

```python
import sympy as s

r, t, x, alpha, beta = s.symbols('r t x alpha beta', real=True)
cayley = lambda z: (z - 1) / (z + 1)
odds = lambda u: (1 + u) / (1 - u)
assert s.factor(cayley(odds(r)) - r) == 0
assert s.factor(cayley(odds(r)*odds(t)) - (r+t)/(1+r*t)) == 0
assert s.diff(alpha - beta/x, x) == beta/x**2
q, w = s.Rational(1, 5), s.Rational(3, 10)
assert (q+w)/(1+q*w) == s.Rational(25, 53)

M = s.Matrix([[3, 1, 0], [1, 4, 2], [0, 2, 5]])
pivots = [M[0, 0]]
for j in range(1, 3):
    pivots.append(s.factor(M[j,j] - M[j,j-1]*M[j-1,j]/pivots[-1]))
assert s.prod(pivots) == M.det() == 43

A = s.Matrix([[1, 1, 0], [0, 1, 1]])
b = s.Matrix([[1, 0, 0]])
N = s.Matrix.hstack(*A.nullspace())
P = N*(N.T*N).inv()*N.T
c = P*b.T/(b*P*b.T)[0]
assert A*c == s.zeros(2, 1) and (b*c)[0] == 1
print('All exact checks passed.')
print('Schur pivots:', pivots)
print('Retained-output witness:', list(c))
```

## 11. Sources and coverage

The source recovery located the complete 90-card archive, extracted all its card text, indexed the titles and historical grades, inspected the earlier 84-bridge plain text, and read the relevant updated derivations. This is a synthesis of the recovered record; it is not an audit of every proof in every version.

- **The Operator-First Atlas:** `atlas_cards.zip`, containing B1–B90, and `Operator-First_Atlas_plain_text.txt`. Historical grade words are retained in the index below, not freshly endorsed.
- **The Atlas Applied to Catalan:** `Atlas_Catalan_Working_Note.md`, 6 September 2026. Exact asymptotics, kernel selection, frame correction, trajectory cost and the rejected strong finite B81 decomposition.
- **What Transport Keeps**, research edition 3, 6 September 2026: `What_Transport_Keeps(2).pdf`, especially pp. 1–16. Gram selection, dual pairing, curvature, exact projective-circle census and interface elimination. Its grade C means cited, unlike the Atlas's C for conjecture.
- **Smith chart, boundary elimination, and projector geometry:** `SMITH-BOUNDARY-01_proof.md`, 5 September 2026. Exact Schur/Cayley algebra, source assumptions and optical response domain.
- **Gravity**, `gravity_final_v3_dark (5).html`, clock section and its stated genericity, nullity and hard-eigenvalue hypotheses. These qualifications govern the use of B90 here.
- **Sofic–Torsion–Atlas Working Note**, 23 August 2026: lifting, legal moves, regularized log determinants and explicitly proposed stability gates. No soficity resolution is inferred.
- **Earth–Moon / Atlas project update**, 25 August 2026: structural branching guidance and exact obstruction certificates. Historical candidate status is not presented as today's status.
- **[The Offset Belongs to the Boundary, newest edition](https://doi.org/10.5281/zenodo.22555919):** local v31 manuscript, all-size transfer, finite determinant reduction, method notes and proof ledger. The current written endpoint proof supersedes older statements calling that endpoint open.

Established mathematical context: the [Ohio State Smith-chart derivation](https://ximera.osu.edu/electromagnetics/electromagnetics/smithChart/digInSmithChartDerivationImpedanceAdmittance) gives the impedance Cayley coordinate; [Barriuso et al.](https://arxiv.org/abs/physics/0305040) analyze fractional linear transformations for lossless multilayers; [Dusson, Sigal and Stamm](https://arxiv.org/abs/2105.02058) develop Feshbach–Schur perturbation methods. These support the classical-tool attribution, not an identification between the programme's different observables.

## 12. Historical card index

The following index preserves the recovered card titles and their printed grades for future navigation. Titles sometimes state stronger claims than their hypotheses or later corrections support. In particular B37's area-count assumption is not adopted by Offset; B75 needs an actual numerator cancellation; the strong finite B81 decomposition was rejected in the updated Catalan calculation; B90 is governed by the explicit zero-order and genericity conditions above. No card acquires a fresh proof grade from inclusion in this index.

| Card | Printed historical grade | Title |
|:--|:--|:--|
| B1 | theorem | Curvature cannot exceed what the metric affords. |
| B2 | theorem | Normality is exactly commutation. |
| B3 | measured | Rigidity diverges as the fourth power. |
| B4 | conjecture | One metric, or five coincidences. |
| B5 | reading | Without a boundary there is no list to count. |
| B6 | theorem | Entropy is membership ambiguity, counted. |
| B7 | theorem | Unit-circle roots are where the integer may step. |
| B8 | measured | A spectral question becomes a lattice question. |
| B9 | theorem | Around a defect, the winding is what survives. |
| B10 | measured | Memory is stored in the moduli space. |
| B11 | theorem | Volume is a sum of dilogarithms. |
| B12 | theorem | Entropy production is exported misalignment. |
| B13 | measured | Going around swaps the pair; twice restores it. |
| B14 | reading | The budget is written on horizons. |
| B15 | measured | More does not buy proportionally more. |
| B16 | theorem | A direction costs one channel. |
| B17 | measured | Overflow builds the wall it overflows. |
| B18 | theorem | A capped capacity forces full dimension. |
| B19 | theorem | The wall stiffens as fast as it is stressed. |
| B20 | theorem | Some questions are closed to their own instrument. |
| B21 | conjecture | The census is the third face. |
| B22 | theorem | Leakage out of a channel is the capacity. |
| B23 | measured | The bound breaks at any non-Hermiticity. |
| B24 | measured | The gaps cancel in the ledger. |
| B25 | theorem | The gaps belong to the susceptibility. |
| B26 | theorem | Coalescence alone is not enough. |
| B27 | theorem | Turning costs, and the geometry says how much. |
| B28 | theorem | It does not need pure states. |
| B29 | theorem | The coefficients meet the classical ones. |
| B30 | theorem | Refraction is kinematics, not force. |
| B31 | theorem | Change has only one place to go. |
| B32 | theorem | The two-band case sits hard against the bound. |
| B33 | measured | It returns a measured topological number. |
| B34 | derived | A shape space carries a state-space metric. |
| B35 | measured | Phase crosses what amplitude cannot. |
| B36 | theorem | Three mechanisms arrive at one place. |
| B37 | theorem | A finite count makes it finite. |
| B38 | theorem | Stress relaxes without touching the spectrum. |
| B39 | theorem | Past the critical angle nothing gets through. |
| B40 | measured | A prediction placed on the resolution floor. |
| B41 | measured | A wave born at a defective collision. |
| B42 | theorem | Interlacing keeps the interior real. |
| B43 | theorem | The last metric choice is removed. |
| B44 | theorem | Five is the smallest that keeps the sectors. |
| B45 | theorem | Curvature over a provably flat connection. |
| B46 | theorem | The failure to close is the mechanism. |
| B47 | measured | The same operator rebuilds the choreography. |
| B48 | derived | The seam is a Schur complement. |
| B49 | conjecture | One locus, three names. |
| B50 | measured | Which factor stops the arc sets the class. |
| B51 | theorem | The whole classification is one comparison. |
| B52 | measured | The endpoint decides, not the size. |
| B53 | conjecture | Two curves, one source. |
| B54 | measured | Two ways for the bound to fail. |
| B55 | theorem | Where the geometry fails is a wall of its own. |
| B56 | theorem | A curve and a point do not meet. |
| B57 | theorem | Zero length, and still moving. |
| B58 | conjecture | A collective cone exceeds its parts. |
| B59 | reading | Two cones, deliberately not identified. |
| B60 | theorem | Saturation flags a hidden rank-one structure. |
| B61 | theorem | Size and mass cannot scale the same way. |
| B62 | conjecture | The station travels twice. |
| B63 | reading | A rescaling can only be seen as a running. |
| B64 | theorem | One operator, five names. |
| B65 | theorem | Two diagnostics, not two views. |
| B66 | theorem | The wall is branched, and squareness is why. |
| B67 | theorem | A record that is a group element. |
| B68 | theorem | Paired spectrum is where the integers come from. |
| B69 | measured | A gap predicts a rate, and picks the route. |
| B70 | theorem | Two null-space questions, and confusing them costs a programme. |
| B71 | measured | Distance is blind to orientation; holonomy is not. |
| B72 | theorem | The gap is a stiffness. |
| B73 | theorem | An exponent derived, not fitted. |
| B74 | theorem | A degenerate stratum repels. |
| B75 | theorem | The middle of an ordered spectrum cancels. |
| B76 | conjecture | A degenerate point is a count in hiding. |
| B77 | conjecture | The dictionary's extremal limit is a packing number. |
| B78 | theorem | One contour, any function, no eigenvectors. |
| B79 | theorem | When the vector is unavailable, take the phase. |
| B80 | measured | The running is measured from two sides. |
| B81 | theorem | The transport is flat; the bundle keeps the curvature. |
| B82 | derived | The recessive constant crosses the collision. |
| B83 | measured | The frame is part of the instrument. |
| B84 | theorem | Two sectors say what, one says why. |
| B85 | theorem | The real part of a rank-one complex form is never definite. |
| B86 | theorem | The pairing that pins the geometry shut degenerates on the divisor. |
| B87 | theorem | Protected degeneracies are quadratic and trivial; broken ones are conical. |
| B88 | theorem | Shape space is a crystal: uniaxial when protected, biaxial when not. |
| B89 | theorem | Reciprocity breaks at first order; conductance can only see it at second. |
| B90 | theorem | The clock exponent says whether a system is open. |
