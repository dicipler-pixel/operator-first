# Research goals: subspaces, boundaries, and electrical response

Source review dated 7 September 2026. Prepared from the nine newly supplied artifacts and the operator-first catalog. This is a research synthesis, not a new physical theory or a fresh compilation of the supplied proofs.

## The organizing goal

Develop and test an operator-first account of how admissible subspaces, their orientation relative to physical probes, and their coupling across boundaries determine observable response. Investigate when geometric or stress-like quantities emerge from that account, and when boundary measurements constrain the interior.

This is a concrete formulation of the proposed hypersurface organizing principle. The papers support several finite mathematical links. The stronger statement that electrical structure organizes every surface and interior remains the programme's hypothesis. Spatial boundaries, parameter-space degeneracy loci, spectral singularities, and null spacetime hypersurfaces must retain separate definitions until a map between them is established.

## Main goals and next discriminating steps

| Goal | Source foundation | Next decisive step |
|---|---|---|
| G1. Separate intrinsic coupling from cancellation | Light §4.9a: two-frequency divided response has the field metric's kernel in the fixed finite lossless model | Design a frequency/polarization measurement with calibrated errors; derive how damping and changing transition weights alter the certificate |
| G2. Determine what the instrument can identify | Light §4.9b: target response observable lies in the span of probe outer products, or admits an invisible perturbation | Specify the desired tensor component and produce either a reconstruction certificate or an explicit ambiguity before interpreting data |
| G3. Relate interior channels to boundary loading | Light abstract and boundary sections: projector cross-cut identity and Schur–Smith/Cayley response reduction | Hold spectral levels fixed while changing coupling orientation or contact geometry; compare directional boundary response |
| G4. Recover the baseline omitted by differences | Offset v31: regional empty/full log-odds and boundary determinant reduction | Compare fixed-dispersion states with different cuts; retain the absolute offset alongside level spacings and test gluing |
| G5. Identify what transport preserves | What Transport Keeps edition 3: dominant-projector selection, tied-growth controls, conserved dual pairings, finite readout bounds | Compare convergence of the projector with preservation of paired readouts; include tied-growth and rotating-line controls |
| G6. Derive the physical response and stress dictionary | Light §10.1; Transport §9; Gravity abstract and §9 | Declare operator, probe, units, physical coordinates and constitutive law; derive an action or conservation-based stress construction rather than identifying tensors by resemblance |
| G7. Extend finite directional capacity to physical scale | Light §10.2; Offset OP4, OP8, OP10 and R1 | Establish controlled continuum, genuinely coupled two-dimensional, and interacting extensions, with explicit thresholds and orders of limits |
| G8. Test a useful light/heat device | Light §10.3: emitter–field–medium dynamics and long-lived source architecture | Solve stable driven dynamics and compare useful optical output, input power and heat against a matched conventional cavity |

## The strongest new measurement connection

In Light's finite, ground-state, weak-field, lossless model, put y equal to squared photon energy and write R(y) for the symmetric polarizability. For fixed positive transition gaps and fixed dipole matrix elements, choose y1 < y2 without a transition pole anywhere in the closed interval. Then

\[
B_{12}=\frac{R(y_2)-R(y_1)}{y_2-y_1}
=\sum_m\beta_m g^{(m)},\qquad \beta_m>0,
\qquad \ker B_{12}=\ker g.
\]

A single tune-out can hide active transitions. Two exact scalar zeros for the same real direction in that interval certify zero coupling in this model. Finite measurement error yields a coupling bound, not exact darkness. Crossing a pole, signed residues, linewidth, or changing transition numerators invalidates the stated proof or requires a new one.

This directly sharpens the earlier question about spacing and open channels. A gap, a vanishing measured response, an uncoupled direction, and destructive interference need different tests. The two-frequency theorem distinguishes two of these mechanisms under explicit assumptions; it does not establish electrical conductance from polarizability alone.

The probe theorem supplies a second safeguard. For an unknown real symmetric response R and readings u_i^T R u_i, a target Tr(RF) is uniformly identifiable precisely when F lies in span{u_i u_i^T}. Otherwise an invisible symmetric perturbation changes the target without changing any recorded readings. Interior reconstruction therefore needs an observability argument, even with very accurate data.

## Arrangement carries information beyond spectral spacing

Transport's electronic-sheet example has H(theta) = Delta/2 (cos(theta) sigma_z + sin(theta) sigma_x), with a fixed dipole D = d sigma_z. Its levels remain +/- Delta/2 and its theta-projector metric remains 1/4, while the transition strength is d^2 sin^2(theta). Changing the physical orientation relative to the fixed probe changes loading despite unchanged levels.

Offset provides another version of this question. For the stated number-conserving Gaussian state and 0 < C_A < I,

\[
\tau_A=\operatorname{Tr}\log[(I-C_A)C_A^{-1}]
=\log\frac{P(N_A=0)}{P(N_A=|A|)}.
\]

The paper's fixed-dispersion family changes the boundary asymmetry while preserving bulk dispersion. Together these examples motivate a precise common question: which relational information is discarded when only eigenvalues, spacings, or trace-free quantities are retained? They do not make all those observables identical.

## Stress, gravity, and the hypersurface

Gravity v4 distinguishes the projector tangent form, a Hermitian proxy, and the contour record. A tangent form can change signature or lose rank while the spectral cluster stays isolated and its trace-log remains regular. The unrestricted complex-idempotent tangent space has neutral signature; positivity belongs to an appropriate self-adjoint slice.

Consequently, a metric wall is not automatically a spectral exceptional point or a physical horizon. A regular spacetime horizon has a nondegenerate spacetime metric even though its induced null-hypersurface metric is degenerate. The proposed physical correspondence needs a specified parameter-to-space map.

The user's premetric/emergent-stress preference is compatible with beginning from operator and conservation data. However, the current spectral-gradient Gram form and finite rank-one stress composition are not yet a derived physical stress-energy tensor. Transport explicitly reserves an action coupling the boundary operator to a physical metric. Offset's CC1 also requires units, scale, sign selection, conservation, and a variational or selection principle. No standard gravity or CMB fit is needed to establish the finite identities reviewed here.

## A focused next investigation

Start with one finite electronic/light-response system whose operator, probes and boundary couplings are explicit. Keep the bulk spectrum fixed while varying a physical coupling orientation. Record the full accessible response, not only a scalar spectral summary. Use the probe-span calculation to expose unmeasured directions, and the two-frequency test to distinguish cancellation from weak coupling. Include controlled failure cases outside the theorem's assumptions.

For a conductivity extension, introduce the actual current observable, contacts, occupations and dissipative dynamics; do not substitute an optical coefficient for conductance without that derivation. For a heat-engine extension, retain input energy, useful output, all losses and stability. These are proposed next tasks, not results supplied by the current documents.

When experimental records are introduced, preserve acquisition data, calibration, units, preprocessing and error bounds. Raw data are essential provenance, but accuracy still depends on the instrument model and uncertainty analysis. Synthetic examples and archived numerical fits must remain distinguishable from instrument readings.

## Source and proof-status reconciliation

- **Light edition-4 draft plus light_response_proofs:** the new two-frequency and probe-span statements have written proofs and supplied exact checks. The supplement explicitly claims no new Lean certification; the earlier 91-declaration inventory is unchanged. The catalog marks these additions as awaiting GitHub intake.
- **What Transport Keeps, follow-up edition 3:** the newly supplied package is the concrete newer supplement missing from the catalog's CMF intake. Its README distinguishes exact certificates, numerical tests and inherited challenge results. No new Lean certification is claimed. It should be reconciled with the older diagnostic repository, not treated as a duplicate of it.
- **Offset v31 reproduction:** OP5a is closed in written mathematics on its stated domain. OP5b, physical phase identification, remains open. Historical OP1–OP11 labels should be preserved, alongside F1 (remaining formal chain), R1 (sharp/uniform remainder), and CC1 (physical calibration).
- **offset_proofs:** the concrete boundary-matrix supplement reports 13 named statements in addition to 20 inherited LaurentBoundary statements. It addresses explicit similarity and entry-degree bounds; invariant-polynomial construction, faithful coefficient-chart hypotheses and Fourier/Hankel analysis remain outside that finite module. Its recorded direct compiler route and compatibility shim are disclosed. No fresh compilation was performed in this review.
- **Gravity v4:** reconcile the package's base formal module with the separate seven-statement overlap follow-up recorded under PR #9. The README explicitly retains a failed sign-change prediction in GEOWALL-ROT-01; an overall successful script exit is not evidence that every prediction passed.
- **GitHub catalog:** PR #10 was verified open, draft and unmerged at head 3fd7d5efb7a4e20c790d905c2a3e5a21bfb290ec. Its six projects and seven cards are a partial register, not a complete census of the author's work. Catalog validation checks links and consistency, not theorem correctness. Repository content was read; no branch was modified.

## Priority order

1. Reconcile the supplied Light release with its existing formal sources and new response supplement.
2. Build the finite response/observability study described above, including error bounds and failure controls.
3. Connect current, optical loading and heat on the same declared system.
4. Derive the physical rigidity/constitutive and stress maps.
5. Attempt continuum, interacting and cosmological extensions only with those maps and their limits stated.

The nuclear-knot proposal and universal electrical-hypersurface claim remain separate hypotheses. These new sources supply no nuclear mass-number stability theorem or demonstrated replacement for the Standard Model. Their immediate contribution is a sharper programme of measurable boundary response, retained information and explicit physical bridges.

## GitHub references

- [Master register](https://github.com/dicipler-pixel/operator-first/blob/3fd7d5efb7a4e20c790d905c2a3e5a21bfb290ec/catalog/README.md)
- [Atlas index](https://github.com/dicipler-pixel/operator-first/blob/3fd7d5efb7a4e20c790d905c2a3e5a21bfb290ec/atlas/README.md)
- [Draft PR #10](https://github.com/dicipler-pixel/operator-first/pull/10)

The accompanying source manifest records byte hashes of all nine new attachments. The GitHub snapshot file preserves retrieved catalog/project/card contents and source metadata. This review inspected manuscript passages and supplement scope records; it did not rerun every numerical archive or certify all written proofs.
